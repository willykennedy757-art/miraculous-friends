# Verificação — Mirafriends 2.3.0 Node.js

## O que foi testado

- `npm run check`: sintaxe do servidor, aplicativo e service worker.
- Inicialização pelo comando `npm start` e resposta `GET /api/health`.
- Cadastro e login por Miracode e senha.
- Consulta de conta por Miracode (sem busca por nome de usuário).
- Adição imediata de conta pública.
- Solicitação para conta privada e aceitação pelo destinatário.
- Feed público e feed de amigos.
- Conta privada forçando publicação com visibilidade `friends`.
- Upload de imagem e acesso autorizado à mídia.
- Bloqueio de mídia para sessão ausente e para não-amigos.
- `Cache-Control: private, no-store` para mídia protegida.
- Comentários e contagem de comentários não expostos a visitantes não-amigos.
- Rejeição de mutação com cabeçalho Origin de outra origem.
- Verificação estrutural do HTML: IDs únicos e referências locais existentes.

## Limites de validação

- Os testes de API foram executados em servidor local com banco temporário; não representam uma hospedagem pública de produção.
- O ambiente local usado para testes tem Node.js 22.16 e emite aviso experimental para `node:sqlite`. O projeto está configurado para Node.js 26 LTS ou superior.
- Não houve teste visual completo em navegador Android nem teste de dois celulares reais.
- Mensagens privadas, chamadas, grupos e Momentos ainda usam o mecanismo P2P/local da versão base; a conta online e o feed são hospedados.
