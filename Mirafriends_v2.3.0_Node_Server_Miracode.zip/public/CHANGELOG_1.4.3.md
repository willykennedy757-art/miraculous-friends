# Mirafriends 1.4.3 — Perguntas individuais dos Kwamis

- Adicionada uma seção dinâmica “Sobre o Miraculous da ...” no menu do Kwami.
- Incluídas 3 perguntas específicas para cada um dos 19 Kwamis (57 perguntas e respostas).
- Cada resposta explica conceito, poder ou uso/cuidados do Miraculous correspondente.
- Respostas usam a voz e personalidade do Kwami selecionado.
- Mantidas separadamente as perguntas gerais sobre o Mirafriends, inclusive emparelhamento P2P.
- A seção específica é ocultada quando o usuário escolhe um Miraculous personalizado sem ficha de lore.
- Nenhuma conexão externa ou serviço de IA é necessário para responder.
