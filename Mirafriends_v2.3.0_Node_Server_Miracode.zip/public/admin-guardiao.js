const ADMIN_PASSWORD_SALT = 'MF-ADM-SALT-2026-11-25::b7Kp';
const ADMIN_PASSWORD_HASH = 'e7be33d808210bdb4f339ac4c9313215b4bd90ec669cffbd03a1e0efeaff07b4';
const GUARDIAN_ACTIVE_KEY = 'mirafriends-guardian-active-v1';
const GUARDIAN_MEMORY_KEY = 'mirafriends-guardian-memory-v1';
const GUARDIAN_CHAT_KEY = 'mirafriends-guardian-chat-enabled-v1';
const GUARDIAN_POSITIONS_KEY = 'mirafriends-guardian-positions-v1';
const ADMIN_UNIVERSES_KEY = 'mirafriends-admin-universes-v1';
const FIVE_MAIN = ['ladybug','cat','butterfly','peacock','turtle'];

const esc = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

export function initAdminExperience(api) {
  const $ = (selector, root=document) => root.querySelector(selector);
  const $$ = (selector, root=document) => [...root.querySelectorAll(selector)];
  const auth = $('#mf-admin-auth'), authForm = $('#mf-admin-auth-form'), panel = $('#mf-admin-layer');
  const landing = $('#mf-admin-landing'), content = $('#mf-admin-content'), rail = $('#mf-admin-rail');
  let sessionActive = false, badAttempts = 0, lockUntil = 0, previewId = null, rainTimer = null;
  let activeTab = 'central';
  const guardianCatalog = () => api.miraculous.filter(m => !m.custom || Boolean(m.kwami?.name));
  let guardianActive = readArray(GUARDIAN_ACTIVE_KEY).filter(id => guardianCatalog().some(m => m.id === id));
  let guardianMemory = readArray(GUARDIAN_MEMORY_KEY).slice(-40);
  let guardianPositions = readObject(GUARDIAN_POSITIONS_KEY);
  let guardianChatEnabled = localStorage.getItem(GUARDIAN_CHAT_KEY) !== 'off';
  let guardianTick = null, dialogueTimer = null, guardianBubbleTimer = new Map(), guardianPaused = false;
  let lastInteraction = Date.now();

  function readArray(key) { try { const value=JSON.parse(localStorage.getItem(key)||'[]'); return Array.isArray(value)?value:[]; } catch { return []; } }
  function readObject(key) { try { const value=JSON.parse(localStorage.getItem(key)||'{}'); return value&&typeof value==='object'&&!Array.isArray(value)?value:{}; } catch { return {}; } }
  function saveGuardian() { try { localStorage.setItem(GUARDIAN_ACTIVE_KEY, JSON.stringify(guardianActive)); localStorage.setItem(GUARDIAN_MEMORY_KEY, JSON.stringify(guardianMemory.slice(-40))); localStorage.setItem(GUARDIAN_POSITIONS_KEY,JSON.stringify(guardianPositions)); } catch {} }
  function avatar(id) {
    const item=api.getMiraculous(id);
    if(item?.custom) return item.kwami?.avatarData || item.kwami?.avatar || item.iconData || './assets/logo.svg';
    return `./assets/kwamis/${encodeURIComponent(id)}.png`;
  }
  function kwamiInfo(id) {
    const item=api.getMiraculous(id);
    if(item?.custom && item.kwami?.name) return {name:item.kwami.name,personality:item.kwami.personality||'curioso e companheiro',greeting:item.kwami.greeting||`Olá! Sou ${item.kwami.name}.`,avatar:avatar(id),questions:item.kwami.questions||[]};
    return api.kwamiByMiraculous[id] || {name:item?.name||'Kwami',personality:'curioso e companheiro',greeting:'Olá! Vamos explorar o santuário?',avatar:avatar(id)};
  }
  function displayName(id) { return kwamiInfo(id).name || api.getMiraculous(id)?.name || id; }
  function sigil(id) { const item=api.getMiraculous(id);return item?.custom?(item.iconData||'./assets/logo.svg'):`./assets/sigils/${encodeURIComponent(id)}.png`; }
  function getUniverses(){return readArray(ADMIN_UNIVERSES_KEY);}
  function saveUniverses(items){localStorage.setItem(ADMIN_UNIVERSES_KEY,JSON.stringify(items.slice(-20)));}

  function hideSplash() {
    const splash=$('#mf-splash'); if(!splash || splash.classList.contains('leaving')) return;
    splash.classList.add('leaving'); setTimeout(()=>splash.remove(),700);
  }
  $('#mf-splash-enter')?.addEventListener('click',hideSplash);
  setTimeout(hideSplash,2600);

  async function passwordMatches(value) {
    const data = new TextEncoder().encode(`${ADMIN_PASSWORD_SALT}::${value}`);
    if (!globalThis.crypto?.subtle) return false;
    const digest = await crypto.subtle.digest('SHA-256', data);
    const actual = [...new Uint8Array(digest)].map(byte=>byte.toString(16).padStart(2,'0')).join('');
    return actual === ADMIN_PASSWORD_HASH;
  }
  function releaseAdminOrientation(){
    panel.classList.remove('mf-admin-rotate-fallback','mf-admin-portrait-mode');
  }
  function renderAdminQuickSelect(){
    const grid=$('#mf-admin-quick-select');if(!grid)return;
    grid.innerHTML=api.miraculous.map(item=>`<button class="mf-admin-matrix-tile ${api.state.profile.miraculousId===item.id?'active':''}" type="button" data-mf-select-id="${esc(item.id)}" aria-label="Selecionar ${esc(item.name)}" title="${esc(item.name)}"><img src="${esc(sigil(item.id))}" alt=""><span>${esc(item.name)}</span></button>`).join('');
    const count=$('.mf-matrix-count');if(count)count.textContent=`${api.miraculous.length} · REGISTROS`;
  }
  function toggleLandingPicker(forceOpen){
    const grid=$('#mf-admin-quick-select'),button=$('#mf-admin-change-miraculous');if(!grid||!button)return;
    const show=typeof forceOpen==='boolean'?forceOpen:grid.hidden;
    if(show)renderAdminQuickSelect();
    grid.hidden=!show;button.setAttribute('aria-expanded',String(show));
    if(show)grid.scrollIntoView?.({block:'nearest',behavior:'smooth'});
  }
  function openGate(){
    if(Date.now()<lockUntil){$('#mf-admin-auth-error').textContent='Acesso temporariamente bloqueado. Aguarde um pouco e tente novamente.';auth.hidden=false;return;}
    $('#mf-admin-password').value='';$('#mf-admin-auth-error').textContent='';auth.hidden=false;setTimeout(()=>$('#mf-admin-password')?.focus(),40);
  }
  function closeGate(){auth.hidden=true;authForm?.reset();}
  function openAdmin(){
    if(!sessionActive){openGate();return;}
    panel.hidden=false;document.documentElement.classList.add('mf-admin-session');document.body.classList.add('mf-admin-session');panel.classList.add('mf-admin-portrait-mode');
    $('#mf-guardian-overlay').hidden=true;
    landing.hidden=false;content.hidden=true;rail.hidden=true;panel.classList.remove('mf-admin-has-opened');
    const m=api.getMiraculous(api.state.profile.miraculousId);
    $('#mf-admin-current-identity').textContent=m?.name||'Sem Miraculous';
    toggleLandingPicker(false);renderAdminQuickSelect();
    setTimeout(()=>{$('#mf-admin-core')?.focus();},60);
  }
  function closeAdmin(){
    panel.hidden=true;sessionActive=false;closeGate();releaseAdminOrientation();
    document.documentElement.classList.remove('mf-admin-session');document.body.classList.remove('mf-admin-session');
    api.setTheme(api.state.profile.miraculousId);
    if(guardianActive.length)renderGuardianOverlay();else $('#mf-guardian-overlay').hidden=true;
  }
  $('#mf-admin-trigger')?.addEventListener('click',openGate);
  $('#mf-admin-auth-close')?.addEventListener('click',closeGate);
  auth?.addEventListener('click',event=>{if(event.target===auth)closeGate();});
  authForm?.addEventListener('submit',async event=>{
    event.preventDefault();
    const input=$('#mf-admin-password'), error=$('#mf-admin-auth-error'), button=authForm.querySelector('button[type="submit"]');
    const value=input.value;
    button.disabled=true;button.textContent='VERIFICANDO…';
    try {
      if(await passwordMatches(value)){
        sessionActive=true;badAttempts=0;closeGate();openAdmin();
        api.showToast('Central Secreta desbloqueada em modo retrato.');
      } else {
        badAttempts++;input.value='';error.textContent='Senha incorreta. Acesso não autorizado.';
        if(badAttempts>=5){lockUntil=Date.now()+45000;badAttempts=0;error.textContent='Muitas tentativas. Acesso bloqueado por 45 segundos.';}
      }
    } catch { error.textContent='Não foi possível validar a senha neste navegador. Abra o app em HTTPS ou em um WebView com Web Crypto.'; }
    finally {button.disabled=false;button.textContent='DESBLOQUEAR CENTRAL';}
  });
  $('#mf-admin-close')?.addEventListener('click',closeAdmin);
  $('#mf-admin-home')?.addEventListener('click',()=>{panel.classList.remove('mf-admin-has-opened');landing.hidden=false;content.hidden=true;rail.hidden=true;toggleLandingPicker(false);});
  $('#mf-admin-core')?.addEventListener('click',()=>openSecretTabs('central'));
  $('#mf-admin-open-core')?.addEventListener('click',()=>openSecretTabs('central'));
  $('#mf-admin-change-miraculous')?.addEventListener('click',()=>toggleLandingPicker());
  $('#mf-admin-rail')?.addEventListener('click',event=>{
    const button=event.target.closest('[data-mf-tab]'); if(!button)return;
    openSecretTabs(button.dataset.mfTab);
  });
  $('#mf-admin-content')?.addEventListener('click',handleAdminAction);
  $('#mf-admin-layer')?.addEventListener('click',event=>{
    if(event.target.closest('[data-mf-select-id]')){
      const id=event.target.closest('[data-mf-select-id]').dataset.mfSelectId;
      if(!api.getMiraculous(id))return;
      api.profileFromUser({...api.state.user,name:api.state.profile.name,about:api.state.profile.about,friendCode:api.state.profile.friendCode,miraculousId:id,avatarData:api.state.profile.avatarData});
      api.renderAll();api.updateKwamiPet();
      $('#mf-admin-current-identity').textContent=api.getMiraculous(id)?.name||id;
      renderAdminQuickSelect();toggleLandingPicker(false);
      api.showToast(`Miraculous deste aparelho alterado para ${api.getMiraculous(id)?.name||id}.`);
      if(activeTab==='central'&&!content.hidden)renderMiraculousPicker();
    }
  });
  document.addEventListener('keydown',event=>{if(event.key==='Escape'){if(!auth.hidden)closeGate();else if(!panel.hidden)closeAdmin();}});

  function openSecretTabs(tab='central'){
    if(!sessionActive)return;
    panel.classList.add('mf-admin-has-opened');landing.hidden=true;content.hidden=false;rail.hidden=false;renderTab(tab);
  }
  function tabHead(kicker,title,description){return `<div class="mf-admin-view-head"><div><span class="mf-admin-kicker">${esc(kicker)}</span><h2>${esc(title)}</h2><p>${esc(description)}</p></div></div>`;}
  function card(icon,title,description,tab){return `<button class="mf-admin-card" type="button" data-mf-tab="${esc(tab)}"><b>${icon}</b><strong>${esc(title)}</strong><small>${esc(description)}</small></button>`;}
  function renderTab(tab){
    if(!sessionActive)return;
    activeTab=tab;$$('[data-mf-tab]',rail).forEach(button=>button.classList.toggle('active',button.dataset.mfTab===tab));
    api.setTheme(api.state.profile.miraculousId);
    if(tab==='central'){
      content.innerHTML=`${tabHead('NÚCLEO CENTRAL','Comando Supremo','Acesso rápido a cada sistema secreto do Mirafriends.')}
        <div class="mf-admin-panel"><h3>Núcleo de comando</h3><p>O símbolo central abre todos os módulos. Escolha uma área para começar.</p><div class="mf-admin-actions-row"><button type="button" data-mf-action="change-miraculous">▦ Trocar Miraculous</button><button type="button" data-mf-action="open-guardian">🧚 Abrir Guardião</button><button type="button" data-mf-action="run-diagnostics">⌁ Diagnóstico rápido</button></div></div>
        <div class="mf-admin-card-grid">${card('✧','Laboratório dos Miraculous','Experimente temas, wallpapers e os dois elementos decorativos.','laboratorio')}${card('◉','Portal dos Universos','Crie ambientes locais de demonstração sem mexer nos perfis reais.','universos')}${card('☼','Conselho dos Kwamis','Consulte os companheiros e inicie conversas demonstrativas.','conselho')}${card('✦','Transformações','Pré-visualize transformações e efeitos por Miraculous.','transformacoes')}${card('⚡','Trapaças','Ative efeitos especiais e brincadeiras visuais locais.','trapaças')}${card('⬡','Protocolo Zero','Interrompa experiências e restaure a aparência segura.','emergencia')}</div>
        <div class="mf-admin-panel" style="margin-top:14px"><h3>Identidade do aparelho</h3><p>As mudanças de Miraculous feitas aqui alteram somente o perfil local deste dispositivo. Não trocam a identidade de outros portadores.</p><button type="button" class="mf-admin-action" data-mf-action="change-miraculous">ALTERAR MIRACULOUS DESTE APARELHO</button></div>`;
    } else if(tab==='laboratorio') renderLaboratory();
    else if(tab==='universos') renderUniverses();
    else if(tab==='conselho') renderCouncil();
    else if(tab==='transformacoes') renderTransformations();
    else if(tab==='trapaças') renderCheats();
    else if(tab==='sistema') renderDiagnostics();
    else if(tab==='guardiao') renderGuardian();
    else if(tab==='emergencia') renderEmergency();
  }
  function renderMiraculousPicker(){
    content.innerHTML=`${tabHead('CONTROLE DE IDENTIDADE','Trocar Miraculous','Escolha o símbolo que será usado pelo portador deste aparelho.')}
      <div class="mf-admin-panel"><h3>Catálogo de Miraculous</h3><p>A alteração atualiza o tema, o Kwami companheiro e o símbolo local. Os perfis dos contatos não são alterados.</p><div class="mf-admin-miraculous-grid">${api.miraculous.map(m=>`<button class="mf-admin-miraculous ${api.state.profile.miraculousId===m.id?'active':''}" type="button" data-mf-select-id="${esc(m.id)}"><img src="${esc(sigil(m.id))}" alt=""><span>${esc(m.name)}</span></button>`).join('')}</div><div class="mf-admin-actions-row"><button type="button" data-mf-tab="central">VOLTAR AO COMANDO</button></div></div>`;
  }
  function showMiraculousPicker(){if(!sessionActive)return;openSecretTabs('central');renderMiraculousPicker();}
  function renderLaboratory(){
    content.innerHTML=`${tabHead('TESTE VISUAL','Laboratório dos Miraculous','Pré-visualize cada tema, wallpaper e os dois elementos decorativos sem trocar sua identidade permanentemente.')}
      <div class="mf-admin-panel"><h3>Seleção de tema</h3><div class="mf-admin-miraculous-grid">${api.miraculous.map(m=>`<button class="mf-admin-miraculous ${previewId===m.id?'active':''}" type="button" data-mf-preview-theme="${esc(m.id)}"><img src="${esc(sigil(m.id))}" alt=""><span>${esc(m.name)}</span></button>`).join('')}</div><div class="mf-admin-actions-row"><button type="button" data-mf-action="restore-theme">Restaurar tema atual</button></div><p class="mf-admin-status" id="mf-lab-status">A prévia altera apenas esta sessão administrativa.</p></div>
      <div class="mf-admin-panel"><h3>Elementos do tema selecionado</h3><p>Wallpaper e mini ícones são carregados do pacote local de imagens.</p><div class="mf-admin-lab-assets" id="mf-lab-assets"></div></div>`;
    updateLabAssets(previewId||api.state.profile.miraculousId||'ladybug');
  }
  function updateLabAssets(id){
    const root=$('#mf-lab-assets');if(!root)return;
    const theme=api.miraculous.find(m=>m.id===id&&!m.custom);
    if(theme){
      const path=`./assets/themes/${encodeURIComponent(id)}`;
      root.innerHTML=`<div class="mf-lab-wallpaper" style="background-image:url('${path}/wallpaper.jpg')"><span>WALLPAPER · ${esc(theme.name)}</span></div><div class="mf-lab-icons"><img src="${path}/decoration-1.jpg" alt="Ícone decorativo 1"><img src="${path}/decoration-2.jpg" alt="Ícone decorativo 2"></div>`;
    }else{
      const symbol=sigil(id);
      root.innerHTML=`<div class="mf-lab-wallpaper" style="background-image:linear-gradient(135deg,rgba(4,12,28,.55),rgba(4,12,28,.88)),url('${symbol}')"><span>MIRACULOUS PERSONALIZADO · ${esc(api.getMiraculous(id)?.name||id)}</span></div><div class="mf-lab-icons"><img src="${symbol}" alt="Símbolo personalizado 1"><img src="${symbol}" alt="Símbolo personalizado 2"></div>`;
    }
  }
  function renderUniverses(){
    const universes=getUniverses();
    content.innerHTML=`${tabHead('SIMULAÇÃO LOCAL','Portal dos Universos','Crie cenários de teste isolados para experimentar identidades sem modificar pessoas reais.')}
      <div class="mf-admin-panel"><h3>Gerador de universo demonstrativo</h3><p>Os universos criados aqui são etiquetas de laboratório guardadas só neste aparelho. Não criam contas, contatos ou portadores remotos.</p><div class="mf-admin-actions-row"><button type="button" data-mf-action="create-universe">＋ Criar universo de teste</button><button type="button" data-mf-action="duplicate-universe">⧉ Duplicar cenário selecionado</button></div></div>
      <div class="mf-admin-panel"><h3>Universos de demonstração</h3><div class="mf-admin-universe-list">${universes.length?universes.map((u,i)=>`<div class="mf-admin-diagnostic"><span><strong>${esc(u.name)}</strong><br><small>${esc(new Date(u.createdAt).toLocaleString('pt-BR'))}</small></span><button class="mf-admin-action" data-mf-delete-universe="${i}" type="button">Excluir</button></div>`).join(''):'<p>Nenhum universo de demonstração criado.</p>'}</div></div>`;
  }
  function renderCouncil(){
    content.innerHTML=`${tabHead('REUNIÃO DOS COMPANHEIROS','Conselho dos Kwamis','Consulte os Kwamis oficiais e personalizados e gere uma conversa demonstrativa com personalidades diferentes.')}
      <div class="mf-admin-panel"><h3>Conselho completo</h3><div class="mf-admin-miraculous-grid">${guardianCatalog().map(m=>`<button class="mf-admin-miraculous" type="button" data-mf-council-kwami="${esc(m.id)}"><img src="${esc(avatar(m.id))}" alt=""><span>${esc(kwamiInfo(m.id).name)}</span></button>`).join('')}</div><div class="mf-admin-actions-row"><button type="button" data-mf-action="council-chat">Iniciar conversa entre Kwamis</button><button type="button" data-mf-action="council-guardiao">Abrir Guardião completo</button></div><div class="mf-admin-status" id="mf-council-output" aria-live="polite">Escolha um Kwami para conhecer sua personalidade.</div></div>`;
  }
  function renderTransformations(){
    content.innerHTML=`${tabHead('CÂMARA DE TRANSFORMAÇÃO','Transformações','Pré-visualize a identidade de cada Miraculous, suas cores e os efeitos visuais. Nenhuma mudança de conta é feita nesta aba.')}
      <div class="mf-admin-panel"><h3>Escolha um Miraculous para a prévia</h3><div class="mf-admin-miraculous-grid">${api.miraculous.map(m=>`<button class="mf-admin-miraculous" type="button" data-mf-preview-theme="${esc(m.id)}"><img src="${esc(sigil(m.id))}" alt=""><span>${esc(m.name)}</span></button>`).join('')}</div><div class="mf-admin-actions-row"><button type="button" data-mf-action="restore-theme">Encerrar prévia</button><button type="button" data-mf-action="transformation-flash">Executar efeito simples</button></div><div class="mf-admin-status" id="mf-transform-status">A prévia termina ao sair da Central Secreta ou restaurar o tema.</div></div>`;
  }
  function renderCheats(){
    content.innerHTML=`${tabHead('FERRAMENTAS EXPERIMENTAIS','Trapaças e surpresas','Efeitos de brincadeira que só alteram a apresentação deste aparelho.')}
      <div class="mf-admin-card-grid">${cheatCard('☄','Chuva de Kwamis','Solta imagens dos Kwamis pela tela.','kwami-rain')}${cheatCard('◈','Universo invertido','Aplica uma variação cromática temporária.','inverse')}${cheatCard('⚡','Modo Caos','Anima painéis e o núcleo administrativo.','chaos')}${cheatCard('✧','Portal surpresa','Abre uma mensagem secreta do Mirafriends.','secret-portal')}${cheatCard('🎨','Todos os temas','Abre a prévia de todos os 19 temas.','all-themes')}${cheatCard('🧚','Convocar Conselho','Abre a sala dos Kwamis.','council-guardiao')}</div>
      <div class="mf-admin-panel" style="margin-top:14px"><h3>Estado das experiências</h3><p id="mf-cheat-status" class="mf-admin-status">Nenhuma experiência visual ativa.</p><div class="mf-admin-actions-row"><button type="button" data-mf-action="stop-effects">Desativar todos os efeitos</button></div></div>`;
  }
  function cheatCard(icon,title,description,action){return `<button class="mf-admin-card" type="button" data-mf-action="${esc(action)}"><b>${icon}</b><strong>${esc(title)}</strong><small>${esc(description)}</small></button>`;}
  function renderDiagnostics(){
    const checks=runDiagnostics();
    content.innerHTML=`${tabHead('ANÁLISE LOCAL','Visão do Sistema','Verificações disponíveis no próprio aparelho. Isso não simula teste real com outro dispositivo.')}
      <div class="mf-admin-panel"><h3>Diagnóstico da central</h3><div class="mf-admin-diagnostics">${checks.map(c=>`<div class="mf-admin-diagnostic"><span>${esc(c.label)}</span><b class="${c.ok?'':'warn'}">${esc(c.value)}</b></div>`).join('')}</div><div class="mf-admin-actions-row"><button type="button" data-mf-action="run-diagnostics">Atualizar diagnóstico</button><button type="button" data-mf-action="export-diagnostics">Exportar relatório</button></div><p class="mf-admin-status" id="mf-diagnostic-note">A conectividade ponta a ponta só pode ser confirmada quando outro aparelho participa do teste.</p></div>`;
  }
  function runDiagnostics(){
    const storage=(()=>{try{return localStorage?`${(new Blob(Object.keys(localStorage).map(k=>localStorage.getItem(k)||'')).size/1024).toFixed(0)} KB usados`:'Indisponível';}catch{return 'Indisponível';}})();
    const quota=!!navigator.storage?.estimate;
    return [
      {label:'Perfil local',ok:!!api.state.profile?.uid||!!api.state.profile?.name,value:api.state.profile?.name||'Não definido'},
      {label:'WebRTC',ok:!!window.RTCPeerConnection,value:window.RTCPeerConnection?'Disponível':'Indisponível'},
      {label:'Canal de dados',ok:!!window.RTCDataChannel,value:window.RTCDataChannel?'Disponível':'Indisponível'},
      {label:'Câmera e microfone',ok:!!navigator.mediaDevices?.getUserMedia,value:navigator.mediaDevices?.getUserMedia?'API disponível':'Sem API'},
      {label:'Armazenamento local',ok:!!window.localStorage,value:storage},
      {label:'Estimativa de espaço',ok:quota,value:quota?'API disponível':'Não suportada'},
      {label:'Kwamis oficiais no pacote',ok:api.miraculous.filter(m=>!m.custom).length===19,value:`${api.miraculous.filter(m=>!m.custom).length} / 19`},
      {label:'Kwamis personalizados',ok:api.miraculous.filter(m=>m.custom&&m.kwami?.name).length>=0,value:String(api.miraculous.filter(m=>m.custom&&m.kwami?.name).length)},
      {label:'Canal de sinalização',ok:false,value:'Não configurado'}
    ];
  }
  function renderEmergency(){
    content.innerHTML=`${tabHead('PROTOCOLO ZERO','Protocolo de Emergência','Interrompe efeitos de laboratório e restaura a aparência do aparelho sem apagar mensagens, contatos, fotos ou backups.')}
      <div class="mf-admin-panel mf-emergency-panel"><h3>PROTOCOLO ZERO · RESTAURAÇÃO VISUAL</h3><p>Use em caso de efeitos sobrepostos, tema de teste preso ou animações experimentais que não encerraram.</p><div class="mf-admin-actions-row"><button class="mf-admin-action danger" type="button" data-mf-action="emergency-reset">ATIVAR PROTOCOLO ZERO</button><button type="button" data-mf-action="guardian-pause">Pausar Kwamis do Guardião</button></div><p class="mf-admin-status" id="mf-emergency-status">Sistema em espera. Seus dados pessoais não serão apagados por este protocolo.</p></div>
      <div class="mf-admin-panel"><h3>Recuperação segura</h3><p>Restaurar tema do Miraculous atual, parar chuva de Kwamis, remover filtros de laboratório e devolver o mascote principal à posição padrão.</p><button type="button" class="mf-admin-action" data-mf-action="emergency-reset">RESTAURAR INTERFACE</button><button type="button" class="mf-admin-action" data-mf-action="admin-lock">BLOQUEAR SESSÃO ADM</button></div>`;
  }
  function handleAdminAction(event){
    const target=event.target.closest('[data-mf-action],[data-mf-preview-theme],[data-mf-delete-universe],[data-mf-council-kwami],[data-mf-tab]');if(!target)return;
    if(target.dataset.mfTab){openSecretTabs(target.dataset.mfTab);return;}
    if(target.dataset.mfPreviewTheme){previewTheme(target.dataset.mfPreviewTheme);return;}
    if(target.dataset.mfCouncilKwami){const id=target.dataset.mfCouncilKwami;showKwamiInfo(id);return;}
    if(target.dataset.mfDeleteUniverse!==undefined){const items=getUniverses();items.splice(Number(target.dataset.mfDeleteUniverse),1);saveUniverses(items);renderUniverses();return;}
    const action=target.dataset.mfAction;
    switch(action){
      case 'change-miraculous': showMiraculousPicker();break;
      case 'open-guardian': case 'council-guardiao': openSecretTabs('guardiao');break;
      case 'run-diagnostics': renderDiagnostics();break;
      case 'create-universe': createUniverse(false);break;
      case 'duplicate-universe': createUniverse(true);break;
      case 'council-chat': startCouncilChat();break;
      case 'kwami-rain': startKwamiRain();break;
      case 'inverse': document.body.classList.toggle('mf-inverse-mode');updateCheatStatus();break;
      case 'chaos': document.body.classList.toggle('mf-chaos-mode');updateCheatStatus();break;
      case 'secret-portal': showSecretPortal();break;
      case 'all-themes': renderTab('laboratorio');break;
      case 'stop-effects': stopVisualEffects();break;
      case 'restore-theme': previewId=null;api.setTheme(api.state.profile.miraculousId);renderTab(activeTab);break;
      case 'transformation-flash': transformationFlash();break;
      case 'export-diagnostics': exportDiagnostics();break;
      case 'emergency-reset': emergencyReset();break;
      case 'guardian-pause': pauseGuardian();break;
      case 'admin-lock': closeAdmin();api.showToast('Sessão administrativa encerrada. A senha será exigida novamente.');break;
    }
  }
  function previewTheme(id){
    previewId=id;api.setTheme(id);
    const status=$('#mf-lab-status')||$('#mf-transform-status');if(status)status.textContent=`Prévia ativa: ${api.getMiraculous(id)?.name||id}. A identidade real continua sendo ${api.getMiraculous(api.state.profile.miraculousId)?.name||'não definida'}.`;
    updateLabAssets(id);$$('[data-mf-preview-theme]').forEach(button=>button.classList.toggle('active',button.dataset.mfPreviewTheme===id));
  }
  function createUniverse(duplicate){
    const items=getUniverses();const base=duplicate&&items.length?items[items.length-1]:null;const id=`lab-${Date.now().toString(36)}`;
    items.push({id,name:`${base?'Cópia de ':''}Universo de teste ${items.length+1}`,createdAt:Date.now(),miraculousId:base?.miraculousId||api.state.profile.miraculousId||'ladybug',mode:'simulation'});saveUniverses(items);renderUniverses();
  }
  function showKwamiInfo(id){
    const info=kwamiInfo(id),output=$('#mf-council-output');if(!output)return;
    output.innerHTML=`<strong>${esc(info.name)}</strong> · ${esc(info.personality)}<br>${esc(info.greeting||'Olá!')}`;
  }
  function startCouncilChat(){
    const ids=guardianCatalog().slice(0,4).map(m=>m.id);if(ids.length<2)return;
    const a=kwamiInfo(ids[0]),b=kwamiInfo(ids[1]),c=kwamiInfo(ids[2]);const output=$('#mf-council-output');if(!output)return;
    output.innerHTML=`<strong>${esc(a.name)}:</strong> Vamos explorar uma ideia nova?<br><strong>${esc(b.name)}:</strong> Desde que seja uma aventura tranquila!<br><strong>${esc(c.name)}:</strong> Eu posso inventar uma brincadeira.`;
    saveMemory(`${a.name}, ${b.name} e ${c.name} participaram de uma conversa demonstrativa no Conselho.`);
  }
  function transformationFlash(){
    const layer=document.createElement('div');layer.className='mf-transformation-flash';document.body.append(layer);setTimeout(()=>layer.remove(),850);
    const status=$('#mf-transform-status');if(status)status.textContent='Efeito visual de transformação executado nesta sessão.';
  }
  function showSecretPortal(){
    const message=document.createElement('div');message.className='mf-secret-portal';message.innerHTML='<div><span>PORTAL ABERTO</span><strong>O próximo universo começa com uma escolha.</strong><p>O segredo do Mirafriends é que cada portador pode criar sua própria história.</p><button type="button">FECHAR</button></div>';document.body.append(message);message.querySelector('button').addEventListener('click',()=>message.remove());
  }
  function startKwamiRain(){
    let root=$('#mf-kwami-rain');if(root)root.remove();root=document.createElement('div');root.id='mf-kwami-rain';root.className='mf-kwami-rain';document.body.append(root);
    const ids=guardianCatalog().map(m=>m.id);
    for(let i=0;i<25;i++){const img=document.createElement('img');img.className='mf-rain-kwami';img.src=avatar(ids[i%ids.length]);img.alt='';img.style.left=`${Math.random()*94}%`;img.style.animationDelay=`${Math.random()*1.8}s`;img.style.animationDuration=`${3.6+Math.random()*2}s`;root.append(img);}
    clearTimeout(rainTimer);rainTimer=setTimeout(()=>root.remove(),7600);updateCheatStatus('Chuva de Kwamis ativa por alguns segundos.');
  }
  function updateCheatStatus(message){const el=$('#mf-cheat-status');if(el)el.textContent=message||`Modo Caos: ${document.body.classList.contains('mf-chaos-mode')?'ativo':'desligado'} · Universo invertido: ${document.body.classList.contains('mf-inverse-mode')?'ativo':'desligado'}.`;
  }
  function stopVisualEffects(){
    document.body.classList.remove('mf-inverse-mode','mf-chaos-mode');clearTimeout(rainTimer);$('#mf-kwami-rain')?.remove();previewId=null;api.setTheme(api.state.profile.miraculousId);updateCheatStatus('Todos os efeitos experimentais foram encerrados.');
  }
  function emergencyReset(){
    stopVisualEffects();document.querySelectorAll('.mf-transformation-flash,.mf-secret-portal').forEach(node=>node.remove());
    api.state.kwamiTransformed=false;document.documentElement.classList.remove('kwami-transformed');api.updateKwamiTransformControls?.();api.setTheme(api.state.profile.miraculousId);
    const pet=$('#kwami-pet');if(pet){pet.style.left='auto';pet.style.right='12px';pet.style.top='auto';pet.style.bottom='112px';localStorage.removeItem('mirafriends-kwami-pet-position-v2');}
    const status=$('#mf-emergency-status');if(status)status.textContent='Protocolo Zero concluído. Tema padrão restaurado; nenhum dado pessoal foi apagado.';
    api.showToast('Protocolo Zero: interface restaurada.');
  }
  function exportDiagnostics(){
    const payload={app:'Mirafriends',generatedAt:new Date().toISOString(),checks:runDiagnostics(),notes:'Diagnóstico local. Não verifica conexão com outro aparelho.'};
    const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='mirafriends-diagnostico-local.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }

  /* GUARDIÃO — santuário + mascotes autônomos sobre as páginas */
  function renderGuardian(){
    content.innerHTML=`${tabHead('SANTUÁRIO SECRETO','Guardião','Libere os Kwamis, acompanhe suas brincadeiras e converse com eles. A mesma turma pode aparecer por cima das páginas do Mirafriends quando você sair da central.')}
      <div class="mf-admin-panel"><div class="mf-admin-actions-row"><button type="button" data-mf-action="guardian-release-all">LIBERTAR TODOS</button><button type="button" data-mf-action="guardian-recall-all">RECOLHER TODOS</button><button type="button" data-mf-action="guardian-toggle-overlay">${guardianActive.length?'MODO TELA DO APP':'LIBERAR NA TELA DO APP'}</button><button type="button" data-mf-action="guardian-pause">${guardianPaused?'RETOMAR MOVIMENTO':'PAUSAR MOVIMENTO'}</button><button type="button" data-mf-action="guardian-chat-toggle">CONVERSAS ESPONTÂNEAS: ${guardianChatEnabled?'ON':'OFF'}</button><button type="button" data-mf-action="guardian-reset-positions">RESTAURAR POSIÇÕES</button></div><p class="mf-admin-status">${guardianActive.length} Kwami(s) libertado(s) · arraste para mover · toque para ouvir uma fala.</p></div>
      <div class="mf-admin-world" id="mf-guardian-world" aria-label="Santuário dos Kwamis"></div>
      <div class="mf-admin-panel"><h3>Escolher companheiros</h3><p>Toque em um Kwami para libertá-lo ou recolhê-lo. Cada um mantém sua personalidade própria.</p><div class="mf-guardian-roster">${guardianCatalog().map(m=>`<button type="button" class="mf-guardian-choice ${guardianActive.includes(m.id)?'active':''}" data-guardian-toggle="${esc(m.id)}"><img src="${esc(avatar(m.id))}" alt=""><span>${esc(displayName(m.id))}</span></button>`).join('')}</div></div>
      <div class="mf-admin-panel"><h3>Memória do Santuário</h3><p>Registra localmente as conversas e brincadeiras demonstrativas anteriores neste aparelho.</p><div class="mf-guardian-memory" id="mf-guardian-memory">${guardianMemory.length?guardianMemory.slice(-12).reverse().map(item=>`<div>• ${esc(item.text)}</div>`).join(''):'Ainda não há lembranças. Liberte dois Kwamis para começar.'}</div><div class="mf-admin-actions-row"><button type="button" data-mf-action="guardian-clear-memory">Limpar memória local</button><button type="button" data-mf-action="guardian-talk">Começar uma conversa</button></div></div>`;
    renderGuardianWorld($('#mf-guardian-world'));
    if(guardianActive.length&&!guardianPaused)startGuardianEngine();else stopGuardianEngine();
  }
  function renderGuardianWorld(container){
    if(!container)return;container.innerHTML='';
    if(!guardianActive.length){container.innerHTML='<div class="mf-guardian-empty"><strong>O santuário está em silêncio.</strong><span>Escolha os Kwamis abaixo e toque em LIBERTAR TODOS para começar.</span></div>';return;}
    guardianActive.forEach((id,index)=>container.append(createGuardianSprite(id,index)));
  }
  function createGuardianSprite(id,index){
    const sprite=document.createElement('div');sprite.className='mf-guardian-sprite';sprite.dataset.guardianId=id;
    if(!guardianPositions[id])guardianPositions[id]={x:14+(index%5)*17,y:27+Math.floor(index/5)*16,vx:(Math.random()-.5)*.16,vy:(Math.random()-.5)*.12};
    const bubble=document.createElement('div');bubble.className='mf-guardian-bubble';bubble.dataset.bubble='';
    const img=document.createElement('img');img.src=avatar(id);img.alt=displayName(id);img.draggable=false;
    const name=document.createElement('strong');name.textContent=displayName(id);
    sprite.append(bubble,img,name);positionSprite(sprite,id);
    let pointer=null;
    sprite.addEventListener('pointerdown',event=>{if(event.button!==undefined&&event.button!==0)return;const rect=sprite.parentElement.getBoundingClientRect();pointer={id:event.pointerId,startX:event.clientX,startY:event.clientY,rect,moved:false};sprite.setPointerCapture?.(event.pointerId);sprite.classList.add('dragging');event.stopPropagation();});
    sprite.addEventListener('pointermove',event=>{if(!pointer||pointer.id!==event.pointerId)return;const dx=event.clientX-pointer.startX,dy=event.clientY-pointer.startY;if(Math.hypot(dx,dy)>4)pointer.moved=true;if(pointer.moved){const pos=guardianPositions[id];pos.x=Math.max(6,Math.min(94,pos.x+dx/pointer.rect.width*100));pos.y=Math.max(13,Math.min(91,pos.y+dy/pointer.rect.height*100));pointer.startX=event.clientX;pointer.startY=event.clientY;positionSprite(sprite,id);}event.stopPropagation();});
    sprite.addEventListener('pointerup',event=>{if(!pointer||pointer.id!==event.pointerId)return;const moved=pointer.moved;pointer=null;sprite.classList.remove('dragging');if(moved)saveGuardian();else sayKwami(id,'tap');event.stopPropagation();});
    sprite.addEventListener('pointercancel',()=>{pointer=null;sprite.classList.remove('dragging');});
    sprite.addEventListener('click',event=>event.stopPropagation());
    return sprite;
  }
  function positionSprite(sprite,id){const pos=guardianPositions[id];if(!pos)return;sprite.style.left=`${pos.x}%`;sprite.style.top=`${pos.y}%`;sprite.style.transform=`translate(-50%,-50%) scaleX(${pos.vx<0?-1:1})`;const bubble=sprite.querySelector('[data-bubble]');if(bubble)bubble.style.transform=`translateX(-50%) scaleX(${pos.vx<0?-1:1})`;}
  function renderGuardianOverlay(){
    const root=$('#mf-guardian-overlay');if(!root)return;
    if(!guardianActive.length){root.hidden=true;root.innerHTML='';return;}
    root.hidden=false;root.innerHTML='';guardianActive.forEach((id,index)=>root.append(createGuardianSprite(id,index)));
    if(guardianTick===null)startGuardianEngine();
  }
  function renderAllGuardianTargets(){
    if(!panel.hidden&&activeTab==='guardiao'){renderGuardianWorld($('#mf-guardian-world'));}
    if(panel.hidden)renderGuardianOverlay();else $('#mf-guardian-overlay').hidden=true;
  }
  function releaseKwami(id){if(!guardianActive.includes(id)){guardianActive.push(id);const n=guardianActive.length;guardianPositions[id]={x:10+Math.random()*80,y:20+Math.random()*65,vx:(Math.random()-.5)*.16,vy:(Math.random()-.5)*.13};saveGuardian();}renderAllGuardianTargets();updateGuardianRoster();}
  function recallKwami(id){guardianActive=guardianActive.filter(value=>value!==id);delete guardianPositions[id];saveGuardian();renderAllGuardianTargets();updateGuardianRoster();}
  function updateGuardianRoster(){
    $$('.mf-guardian-choice').forEach(button=>{const active=guardianActive.includes(button.dataset.guardianToggle);button.classList.toggle('active',active);});
    const status=$('.mf-admin-panel .mf-admin-status',content);if(status)status.textContent=`${guardianActive.length} Kwami(s) libertado(s) · arraste para mover · toque para ouvir uma fala.`;
  }
  function releaseAll(){guardianCatalog().forEach(m=>{if(!guardianActive.includes(m.id)){guardianActive.push(m.id);guardianPositions[m.id]={x:7+Math.random()*86,y:15+Math.random()*74,vx:(Math.random()-.5)*.15,vy:(Math.random()-.5)*.12};}});saveGuardian();renderAllGuardianTargets();updateGuardianRoster();startGuardianEngine();}
  function recallAll(){guardianActive=[];guardianPositions={};saveGuardian();renderAllGuardianTargets();updateGuardianRoster();stopGuardianEngine();}
  function startGuardianEngine(){
    if(guardianPaused||guardianTick!==null)return;
    guardianTick=setInterval(()=>{
      if(!guardianActive.length)return;
      const containers=[$('#mf-guardian-world'),panel.hidden?null:$('#mf-admin-world-inline'),panel.hidden?$('#mf-guardian-overlay'):null].filter(Boolean);
      const now=Date.now();
      for(const id of guardianActive){const pos=guardianPositions[id];if(!pos)continue;if(pos.targetUntil&&now<pos.targetUntil){pos.x+=(pos.targetX-pos.x)*.035;pos.y+=(pos.targetY-pos.y)*.035;}else{delete pos.targetUntil;delete pos.targetX;delete pos.targetY;pos.x+=pos.vx;pos.y+=pos.vy;if(pos.x<7||pos.x>93)pos.vx*=-1;if(pos.y<16||pos.y>90)pos.vy*=-1;if(Math.random()<.008){pos.vx=(Math.random()-.5)*.18;pos.vy=(Math.random()-.5)*.13;}}
        containers.forEach(container=>{const sprite=container.querySelector(`[data-guardian-id="${CSS.escape(id)}"]`);if(sprite)positionSprite(sprite,id);});
      }
    },90);
    clearTimeout(dialogueTimer);scheduleDialogue();
  }
  function stopGuardianEngine(){if(guardianTick!==null)clearInterval(guardianTick);guardianTick=null;clearTimeout(dialogueTimer);}
  function pauseGuardian(){guardianPaused=!guardianPaused;if(guardianPaused)stopGuardianEngine();else if(guardianActive.length)startGuardianEngine();if(activeTab==='guardiao'&&!content.hidden)renderGuardian();api.showToast(guardianPaused?'Movimento dos Kwamis pausado.':'Movimento dos Kwamis retomado.');}
  function scheduleDialogue(){
    clearTimeout(dialogueTimer);if(!guardianChatEnabled||guardianActive.length<2||guardianTick===null)return;
    dialogueTimer=setTimeout(()=>{if(guardianActive.length>=2&&guardianTick!==null){const shuffled=[...guardianActive].sort(()=>Math.random()-.5);const a=shuffled[0],b=shuffled[1];runPairDialogue(a,b);}scheduleDialogue();},9000+Math.random()*8000);
  }
  function bubbleFor(id,text,container){
    const targets=container?[container]:[$('#mf-guardian-world'),$('#mf-guardian-overlay')].filter(Boolean);
    targets.forEach(root=>{const sprite=root.querySelector(`[data-guardian-id="${CSS.escape(id)}"]`);const bubble=sprite?.querySelector('[data-bubble]');if(!bubble)return;bubble.textContent=text;bubble.classList.add('visible');const key=`${root.id||'sanctuary'}:${id}`;clearTimeout(guardianBubbleTimer.get(key));guardianBubbleTimer.set(key,setTimeout(()=>bubble.classList.remove('visible'),3600));});
  }
  function runPairDialogue(a,b){
    const nameA=displayName(a),nameB=displayName(b);
    const first=['Você viu que lugar incrível?','Vamos descobrir o que tem ali!','Quer brincar comigo?','Tive uma ideia para hoje!'];
    const second=['Claro! Vamos juntos.','Só não vale bagunçar tudo!','Eu conheço um caminho divertido.','Adorei a ideia!'];
    const previous=guardianMemory.find(item=>item.text.includes(nameA)&&item.text.includes(nameB));
    const lineA=previous?'Lembra da nossa última brincadeira?':first[Math.floor(Math.random()*first.length)];
    const lineB=previous?'Claro! Vamos repetir, mas com uma ideia nova!':second[Math.floor(Math.random()*second.length)];
    const pa=guardianPositions[a],pb=guardianPositions[b];
    if(pa&&pb){const mx=(pa.x+pb.x)/2,my=(pa.y+pb.y)/2;pa.targetX=Math.max(8,mx-5);pa.targetY=my;pb.targetX=Math.min(92,mx+5);pb.targetY=my;pa.targetUntil=pb.targetUntil=Date.now()+5200;}
    [a,b].forEach(id=>[$('#mf-guardian-world'),$('#mf-guardian-overlay')].filter(Boolean).forEach(root=>root.querySelector(`[data-guardian-id="${CSS.escape(id)}"]`)?.classList.add('playing')));
    bubbleFor(a,lineA);setTimeout(()=>bubbleFor(b,lineB),1900);
    setTimeout(()=>[a,b].forEach(id=>[$('#mf-guardian-world'),$('#mf-guardian-overlay')].filter(Boolean).forEach(root=>root.querySelector(`[data-guardian-id="${CSS.escape(id)}"]`)?.classList.remove('playing'))),5400);
    saveMemory(`${nameA} e ${nameB} conversaram e brincaram juntos no Santuário.`);
    refreshGuardianMemory();
  }
  function sayKwami(id,reason='tap'){
    const info=kwamiInfo(id);const line=reason==='tap'?(info.greeting||`${info.name} está feliz por você ter vindo ao santuário.`):`${info.name} está explorando o santuário.`;
    bubbleFor(id,line);saveMemory(`${info.name}: ${line}`);refreshGuardianMemory();
  }
  function saveMemory(text){guardianMemory.push({text,at:Date.now()});guardianMemory=guardianMemory.slice(-40);saveGuardian();}
  function refreshGuardianMemory(){const root=$('#mf-guardian-memory');if(root)root.innerHTML=guardianMemory.slice(-12).reverse().map(item=>`<div>• ${esc(item.text)}</div>`).join('');}
  function updateGuardianClickDelegation(event){
    const toggle=event.target.closest('[data-guardian-toggle]');if(toggle){const id=toggle.dataset.guardianToggle;guardianActive.includes(id)?recallKwami(id):releaseKwami(id);return true;}
    return false;
  }
  content?.addEventListener('click',event=>{
    if(updateGuardianClickDelegation(event))return;
    const action=event.target.closest('[data-mf-action]')?.dataset.mfAction;
    if(action==='guardian-release-all')releaseAll();
    else if(action==='guardian-recall-all')recallAll();
    else if(action==='guardian-toggle-overlay'){if(guardianActive.length){closeAdmin();api.showToast('Os Kwamis foram liberados sobre as telas do aplicativo.');}else api.showToast('Primeiro liberte pelo menos um Kwami.');}
    else if(action==='guardian-pause')pauseGuardian();
    else if(action==='guardian-chat-toggle'){guardianChatEnabled=!guardianChatEnabled;try{localStorage.setItem(GUARDIAN_CHAT_KEY,guardianChatEnabled?'on':'off');}catch{};if(guardianChatEnabled)scheduleDialogue();else clearTimeout(dialogueTimer);renderGuardian();}
    else if(action==='guardian-reset-positions'){guardianActive.forEach((id,index)=>{guardianPositions[id]={x:14+(index%5)*17,y:27+Math.floor(index/5)*16,vx:(Math.random()-.5)*.16,vy:(Math.random()-.5)*.12};});renderGuardian();api.showToast('Posições dos Kwamis restauradas.');}
    else if(action==='guardian-talk'){if(guardianActive.length<2)api.showToast('Liberte pelo menos dois Kwamis para conversarem.');else runPairDialogue(guardianActive[0],guardianActive[1]);}
    else if(action==='guardian-clear-memory'){guardianMemory=[];saveGuardian();refreshGuardianMemory();}
  });

  window.addEventListener('resize',()=>{
    Object.keys(guardianPositions).forEach(id=>{const pos=guardianPositions[id];pos.x=Math.max(7,Math.min(93,pos.x));pos.y=Math.max(15,Math.min(90,pos.y));});
  });
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&guardianTick!==null){stopGuardianEngine();}else if(!document.hidden&&guardianActive.length)startGuardianEngine();});

  // O painel de acesso pode ser aberto pela tecla de atalho local Ctrl+Shift+M, além do botão da barra superior.
  document.addEventListener('keydown',event=>{if(event.ctrlKey&&event.shiftKey&&event.key.toLowerCase()==='m'){event.preventDefault();openGate();}});
  if(guardianActive.length) renderGuardianOverlay();
}
