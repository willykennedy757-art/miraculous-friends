import { initAdminExperience } from './admin-guardiao.js';
import { initMiraGames } from './miragames.js';
const baseMiraculous = [
  {id:'ladybug',name:'Joaninha',color:'#E9A0A8',rgb:'233,160,168',subtitle:'Criação'},
  {id:'cat',name:'Gato',color:'#A9D7B7',rgb:'169,215,183',subtitle:'Destruição'},
  {id:'butterfly',name:'Borboleta',color:'#C4AFE8',rgb:'196,175,232',subtitle:'Transmissão'},
  {id:'peacock',name:'Pavão',color:'#9CD7CD',rgb:'156,215,205',subtitle:'Emoção'},
  {id:'turtle',name:'Tartaruga',color:'#A9DEC8',rgb:'169,222,200',subtitle:'Proteção'},
  {id:'fox',name:'Raposa',color:'#F0B47F',rgb:'240,180,127',subtitle:'Ilusão'},
  {id:'bee',name:'Abelha',color:'#E9D68D',rgb:'233,214,141',subtitle:'Ação'},
  {id:'mouse',name:'Rato',color:'#E4B7D1',rgb:'228,183,209',subtitle:'Multiplicação'},
  {id:'ox',name:'Boi',color:'#D0BCA2',rgb:'208,188,162',subtitle:'Determinação'},
  {id:'tiger',name:'Tigre',color:'#EDB29A',rgb:'237,178,154',subtitle:'Exaltação'},
  {id:'rabbit',name:'Coelho',color:'#B5DDEC',rgb:'181,221,236',subtitle:'Evolução'},
  {id:'dragon',name:'Dragão',color:'#A2D7DE',rgb:'162,215,222',subtitle:'Perfeição'},
  {id:'snake',name:'Serpente',color:'#BCD9A5',rgb:'188,217,165',subtitle:'Intuição'},
  {id:'horse',name:'Cavalo',color:'#C7BBEB',rgb:'199,187,235',subtitle:'Migração'},
  {id:'goat',name:'Cabra',color:'#DDD2BF',rgb:'221,210,191',subtitle:'Paixão'},
  {id:'monkey',name:'Macaco',color:'#DEB78F',rgb:'222,183,143',subtitle:'Zombaria'},
  {id:'rooster',name:'Galo',color:'#EAD197',rgb:'234,209,151',subtitle:'Pretensão'},
  {id:'dog',name:'Cão',color:'#E0C0A9',rgb:'224,192,169',subtitle:'Adoração'},
  {id:'pig',name:'Porco',color:'#EABBCB',rgb:'234,187,203',subtitle:'Júbilo'}
];
let miraculous = [...baseMiraculous];
const THEME_ASSET_IDS = new Set(baseMiraculous.map(item=>item.id));

// Kwamis oficiais: cada Miraculous carrega o PNG correspondente em assets/kwamis/.
const KWAMI_BY_MIRACULOUS = {
  ladybug:{name:'Tikki',glyph:'🐞',color:'#E9A0A8',personality:'gentil, otimista e encorajadora',greeting:'Olá! Que bom ter você por aqui. Vamos resolver isso com calma e criatividade?',power:'Criação',powerDetail:'O Miraculous da Joaninha está ligado à criação. Seu poder mais conhecido é o Lucky Charm, que cria um objeto útil para resolver uma situação.'},
  cat:{name:'Plagg',glyph:'🐈‍⬛',color:'#A9D7B7',personality:'irreverente, sarcástico, brincalhão e leal',greeting:'Sou Plagg. Espero que sua pergunta seja interessante. Ou que envolva queijo. De preferência os dois.',power:'Destruição',powerDetail:'O Miraculous do Gato representa a destruição. Seu poder característico é o Cataclysm, que permite desintegrar ou deteriorar aquilo que toca.'},
  fox:{name:'Trixx',glyph:'🦊',color:'#F0B47F',personality:'esperto, criativo, brincalhão e observador',greeting:'Trixx na área! Uma boa ilusão começa com uma ideia ainda melhor. Qual é o mistério?',power:'Ilusão',powerDetail:'O Miraculous da Raposa representa a ilusão. Seu poder é Mirage, que cria ilusões para confundir ou distrair.'},
  bee:{name:'Pollen',glyph:'🐝',color:'#E9D68D',personality:'educada, elegante, disciplinada e determinada',greeting:'Olá. Pollen está pronta para ajudar com precisão e elegância.',power:'Ação',powerDetail:'O Miraculous da Abelha representa a ação. Seu poder é Venom, que pode imobilizar temporariamente um alvo.'},
  turtle:{name:'Wayzz',glyph:'🐢',color:'#A9DEC8',personality:'calmo, sábio, paciente e protetor',greeting:'Respire. Vamos observar a situação antes de escolher o próximo passo.',power:'Proteção',powerDetail:'O Miraculous da Tartaruga representa a proteção. Seu poder defensivo é Shell-ter, que cria uma barreira protetora.'},
  butterfly:{name:'Nooroo',glyph:'🦋',color:'#C4AFE8',personality:'gentil, sensível, atencioso e ponderado',greeting:'Olá, portador. Estou aqui para ajudar, com cuidado e atenção.',power:'Transmissão',powerDetail:'O Miraculous da Borboleta representa a transmissão. Seu poder permite transmitir energia e habilidades por meio de borboletas mágicas.'},
  peacock:{name:'Duusu',glyph:'🦚',color:'#9CD7CD',personality:'expressivo, emotivo, artístico e imaginativo',greeting:'Oi! Que conversa interessante! Vamos explorar essa ideia juntos?',power:'Emoção',powerDetail:'O Miraculous do Pavão representa a emoção. Seu poder permite criar sentimonstros a partir de emoções concentradas em amoks.'},
  snake:{name:'Sass',glyph:'🐍',color:'#BCD9A5',personality:'sereno, reflexivo, estratégico e paciente',greeting:'Vamos pensar com cuidado. Às vezes, a melhor resposta aparece depois de observar novamente.',power:'Intuição',powerDetail:'O Miraculous da Serpente representa a intuição. Seu poder, Second Chance, permite retornar a um ponto marcado no tempo.'},
  horse:{name:'Kaalki',glyph:'🐎',color:'#C7BBEB',personality:'confiante, elegante, prática e objetiva',greeting:'Kaalki chegou. Vamos encontrar o caminho mais eficiente.',power:'Migração',powerDetail:'O Miraculous do Cavalo representa a migração. Seu poder, Voyage, abre um portal para outro lugar.'},
  mouse:{name:'Mullo',glyph:'🐭',color:'#E4B7D1',personality:'curioso, veloz, animado e cheio de ideias',greeting:'Opa! Uma pergunta? Adoro perguntas! Vamos descobrir!',power:'Multiplicação',powerDetail:'O Miraculous do Rato representa a multiplicação. Seu poder, Multitude, permite dividir o portador em pequenas cópias.'},
  dog:{name:'Barkk',glyph:'🐶',color:'#E0C0A9',personality:'leal, alegre, atencioso e companheiro',greeting:'Oi! Estou aqui com você. O que vamos procurar hoje?',power:'Adoração',powerDetail:'O Miraculous do Cão representa a adoração. Seu poder, Fetch, permite recuperar um objeto marcado.'},
  tiger:{name:'Roaar',glyph:'🐯',color:'#EDB29A',personality:'corajoso, intenso, direto e entusiasmado',greeting:'Roaar está pronto! Vamos encarar essa dúvida de frente!',power:'Exaltação',powerDetail:'O Miraculous do Tigre representa a exaltação. Seu poder, Clout, concentra força em um golpe poderoso.'},
  rabbit:{name:'Fluff',glyph:'🐰',color:'#B5DDEC',personality:'enérgico, curioso, rápido e fascinado pelo tempo',greeting:'Olá! Temos muitas possibilidades pela frente. Por onde começamos?',power:'Evolução',powerDetail:'O Miraculous do Coelho representa a evolução. Seu poder, Burrow, permite viajar pelo tempo através de um espaço temporal.'},
  dragon:{name:'Longg',glyph:'🐉',color:'#A2D7DE',personality:'sábio, disciplinado, equilibrado e respeitoso',greeting:'Que a serenidade acompanhe nossa conversa. Estou pronto para orientar.',power:'Perfeição',powerDetail:'O Miraculous do Dragão representa a perfeição. Seus poderes elementais estão ligados à água, ao vento e ao relâmpago.'},
  goat:{name:'Ziggy',glyph:'🐐',color:'#DDD2BF',personality:'criativo, curioso, imaginativo e artístico',greeting:'Olá! Uma ideia pode virar algo extraordinário. O que deseja criar?',power:'Paixão',powerDetail:'O Miraculous da Cabra representa a paixão. Seu poder, Genesis, permite criar um objeto específico.'},
  monkey:{name:'Xuppu',glyph:'🐒',color:'#DEB78F',personality:'travesso, irreverente, engraçado e imprevisível',greeting:'Hehe! Xuppu apareceu. Vamos acabar com o tédio dessa dúvida!',power:'Zombaria',powerDetail:'O Miraculous do Macaco representa a zombaria. Seu poder, Uproar, cria um objeto que atrapalha temporariamente o poder de outro.'},
  rooster:{name:'Orikko',glyph:'🐓',color:'#EAD197',personality:'confiante, teatral, expressivo e orgulhoso',greeting:'Orikko em cena! Faça sua pergunta e prepare-se para uma resposta marcante.',power:'Pretensão',powerDetail:'O Miraculous do Galo representa a pretensão. Seu poder, Sublimation, concede uma habilidade escolhida dentro das regras do Miraculous.'},
  ox:{name:'Stompp',glyph:'🐂',color:'#D0BCA2',personality:'firme, determinado, direto e confiável',greeting:'Estou aqui. Vamos manter o foco e resolver isso passo a passo.',power:'Determinação',powerDetail:'O Miraculous do Boi representa a determinação. Seu poder, Resistance, concede resistência a poderes sobrenaturais.'},
  pig:{name:'Daizzi',glyph:'🐷',color:'#EABBCB',personality:'gentil, alegre, empático e acolhedor',greeting:'Olá! Espero que nossa conversa traga um pouco de alegria. Como posso ajudar?',power:'Júbilo',powerDetail:'O Miraculous do Porco representa o júbilo. Seu poder, Gift, mostra ao alvo uma visão de seu desejo mais profundo.'}
};

// Frases de transformação para os Miraculous do catálogo. Para uma frase de retorno
// que não está confirmada nas referências consultadas, o botão usa o texto neutro.
const KWAMI_TRANSFORMATION_PHRASES = {
  ladybug:{on:'Tikki, Spots On!',off:'Spots Off!'},
  cat:{on:'Plagg, energia da destruição!',off:'Destransformar'},
  fox:{on:'Trixx, ilusão em ação!',off:'Ilusão encerrada!'},
  bee:{on:'Pollen, ação ativada!',off:'Ação encerrada!'},
  turtle:{on:'Wayzz, proteção ativa!',off:'Proteção encerrada!'},
  butterfly:{on:'Nooroo, asas despertas!',off:'Asas em repouso!'},
  peacock:{on:'Duusu, emoção revelada!',off:'Emoção recolhida!'},
  snake:{on:'Sass, tempo em movimento!',off:'Tempo estabilizado!'},
  horse:{on:'Kaalki, portal aberto!',off:'Portal fechado!'},
  mouse:{on:'Mullo, multiplicar!',off:'Multiplicação encerrada!'},
  dog:{on:'Barkk, busca iniciada!',off:'Busca encerrada!'},
  tiger:{on:'Roaar, força liberada!',off:'Força recolhida!'},
  rabbit:{on:'Fluff, caminho temporal!',off:'Tempo estabilizado!'},
  dragon:{on:'Longg, elementos despertos!',off:'Tempestade acalmada!'},
  goat:{on:'Ziggy, criatividade ativa!',off:'Criação em repouso!'},
  monkey:{on:'Xuppu, diversão em ação!',off:'Diversão encerrada!'},
  rooster:{on:'Orikko, habilidade escolhida!',off:'Habilidade recolhida!'},
  ox:{on:'Stompp, determinação ativa!',off:'Determinação encerrada!'},
  pig:{on:'Daizzi, alegria desperta!',off:'Alegria em repouso!'}
};
const KWAMI_TRANSFORMATION_COLORS = {
  ladybug:'#E32643',cat:'#34323D',fox:'#E98527',bee:'#D5A915',turtle:'#238A68',
  butterfly:'#7750B8',peacock:'#168E8A',snake:'#5D982F',horse:'#7856C8',mouse:'#C65A9D',
  dog:'#A76C43',tiger:'#DA6037',rabbit:'#2698C7',dragon:'#168B9D',goat:'#A58A63',
  monkey:'#B96A2E',rooster:'#B68B19',ox:'#806548',pig:'#D86F98'
};
const APPEARANCE_PREFERENCES_KEY='mirafriends-appearance-preferences-v1';
const TRANSFORMATION_TONE_PALETTES={
  ladybug:['#E32643','#C2183A','#F05269','#8F102C'],cat:['#2F9D62','#42C77A','#176E45','#86E4A5'],
  butterfly:['#6572E8','#8C62D8','#4E5AB5','#B18BFF'],peacock:['#168F9B','#21B7B1','#176D7C','#74DDD1'],
  turtle:['#3C966A','#6CCB8D','#246A4B','#A1DEA8'],fox:['#E17C33','#F09B43','#B95A24','#FFC06E'],
  bee:['#E0B32A','#F2CC45','#B98A16','#FFE68A'],mouse:['#D56AAB','#B84991','#F18EC3','#8F3E80'],
  ox:['#9B7048','#B78B5B','#725035','#D0AE7B'],tiger:['#D46E2C','#F09245','#A94222','#FFC080'],
  rabbit:['#3D9EC0','#61C6E8','#247B9C','#9CEBFF'],dragon:['#3D8EBD','#46B99C','#2F5CB5','#92C8EF'],
  snake:['#6B9A43','#91BB55','#426C2D','#C1DB85'],horse:['#7E6BC1','#A48BE3','#5C4C98','#D0C2FF'],
  goat:['#A58A58','#C5AB72','#7F683F','#E8D4A2'],monkey:['#C47A39','#E8A64A','#895027','#FFD08B'],
  rooster:['#C89A28','#E0B63D','#A75D35','#F4D27B'],dog:['#AA784F','#CB9B69','#805637','#E5C19A'],
  pig:['#D46A94','#EE91B2','#A94F79','#FFC5D8']
};
function readAppearancePreferences(){
  const defaults={photoVisibility:62,transformScope:'soft',tones:{}};
  try{const value=JSON.parse(localStorage.getItem(APPEARANCE_PREFERENCES_KEY)||'{}');return{...defaults,...(value&&typeof value==='object'?value:{}),tones:value?.tones&&typeof value.tones==='object'?value.tones:{}};}catch{return defaults;}
}
let appearancePreferences=readAppearancePreferences();
function saveAppearancePreferences(){try{localStorage.setItem(APPEARANCE_PREFERENCES_KEY,JSON.stringify(appearancePreferences));}catch{}}
function applyPhotoVisibility(){
  const amount=Math.max(0,Math.min(100,Number(appearancePreferences.photoVisibility??62)))/100;
  document.documentElement.style.setProperty('--mf-photo-visibility',String(amount));
  document.documentElement.style.setProperty('--mf-photo-opacity',String(.06+amount*.52));
  document.documentElement.style.setProperty('--mf-photo-darkness',String(.92-amount*.72));
}
function mixHex(hex,target,ratio){
  const clean=String(hex||'#888888').replace('#','');if(!/^[0-9a-f]{6}$/i.test(clean))return '#888888';
  const a=[0,2,4].map(i=>parseInt(clean.slice(i,i+2),16)),b=[0,2,4].map(i=>parseInt(target.slice(i,i+2),16));
  return '#'+a.map((v,i)=>Math.round(v+(b[i]-v)*ratio).toString(16).padStart(2,'0')).join('');
}
function tonesForMiraculous(id){
  if(TRANSFORMATION_TONE_PALETTES[id])return TRANSFORMATION_TONE_PALETTES[id];
  const m=getMiraculous(id);const base=m?.color||'#8A72B8';return[base,mixHex(base,'#FFFFFF',.26),mixHex(base,'#000000',.25),mixHex(base,'#FFFFFF',.48)];
}
function preferredTransformationTone(id){return appearancePreferences.tones?.[id]||tonesForMiraculous(id)[0]||KWAMI_TRANSFORMATION_COLORS[id]||getMiraculous(id)?.color||'#8159C9';}

// Perguntas exclusivas: cada Kwami explica o conceito e as regras do próprio Miraculous.
const KWAMI_MIRACULOUS_FAQ = {
  "ladybug": [
    {
      "label": "Por que o conceito da Joaninha é Criação?",
      "answer": "O conceito da Joaninha é a Criação: transformar uma situação difícil em uma possibilidade de solução. O Miraculous da Joaninha está ligado a criar algo que ajude o portador a resolver o desafio."
    },
    {
      "label": "O que o Lucky Charm realmente cria?",
      "answer": "O Lucky Charm cria um objeto especial relacionado ao problema que o portador enfrenta. Ele não entrega uma explicação pronta: o portador precisa observar o cenário, entender como o objeto pode ser usado e montar uma solução."
    },
    {
      "label": "O que acontece depois do Lucky Charm?",
      "answer": "Depois que a solução é encontrada, o poder de restauração associado à Joaninha, conhecido como Miraculous Ladybug, pode reparar os danos causados durante o conflito. Criação e restauração são partes diferentes do conjunto de poderes da Joaninha."
    }
  ],
  "cat": [
    {
      "label": "Por que o conceito do Gato é Destruição?",
      "answer": "O conceito do Gato é a Destruição. Ele representa a força de desfazer, deteriorar ou encerrar algo. É o contraponto da Criação de Tikki."
    },
    {
      "label": "Como funciona o Cataclysm?",
      "answer": "O Cataclysm concentra o poder destrutivo do Miraculous do Gato no toque do portador. Aquilo que recebe o contato pode se deteriorar ou ser destruído. Por isso, mirar e controlar o toque é essencial."
    },
    {
      "label": "O Cataclysm serve para qualquer situação?",
      "answer": "Não é uma ferramenta para resolver tudo. O Cataclysm é um poder destrutivo e pode causar danos sérios ao alvo e ao ambiente. Um bom portador avalia o que precisa ser atingido e evita contatos acidentais."
    }
  ],
  "fox": [
    {
      "label": "O que a Ilusão representa no Miraculous da Raposa?",
      "answer": "A Raposa representa a Ilusão: alterar aquilo que outras pessoas percebem. Trixx usa criatividade e estratégia para criar distrações e confundir quem está observando."
    },
    {
      "label": "Como funciona o Mirage?",
      "answer": "Mirage cria uma ilusão que parece real para quem a percebe. Ela pode representar pessoas, objetos ou cenários e servir para distrair, esconder uma ação ou conduzir alguém a uma conclusão errada."
    },
    {
      "label": "Uma ilusão do Mirage é um objeto de verdade?",
      "answer": "Não. O Mirage engana os sentidos, mas não transforma a ilusão em um objeto físico. Ela pode parecer convincente, porém não deve ser tratada como algo capaz de oferecer apoio ou bloqueio material."
    }
  ],
  "bee": [
    {
      "label": "O que significa Ação no Miraculous da Abelha?",
      "answer": "O conceito da Abelha é Ação: agir de forma precisa no momento certo. Pollen valoriza disciplina, foco e uma decisão bem executada."
    },
    {
      "label": "Como funciona o Venom?",
      "answer": "Venom é o poder de imobilização do Miraculous da Abelha. Ao atingir o alvo com o ferrão do traje, o portador pode paralisá-lo temporariamente, interrompendo seus movimentos."
    },
    {
      "label": "Por que o Venom exige precisão?",
      "answer": "Porque o efeito é direcionado ao alvo atingido. O portador precisa escolher com cuidado quando e em quem usar a imobilização, especialmente quando há outras pessoas por perto."
    }
  ],
  "turtle": [
    {
      "label": "Por que a Tartaruga representa Proteção?",
      "answer": "A Tartaruga representa Proteção. Wayzz está ligado à defesa, à segurança e à criação de um espaço onde outras pessoas possam ficar protegidas."
    },
    {
      "label": "O que o Shell-ter faz?",
      "answer": "Shell-ter cria uma barreira protetora de energia. O portador pode usá-la para se defender e proteger quem estiver dentro da área coberta."
    },
    {
      "label": "O Shell-ter serve para atacar?",
      "answer": "A função principal do Shell-ter é defensiva. Ele cria proteção em vez de causar dano. Um bom uso é posicionar a barreira para proteger pessoas ou ganhar tempo para organizar a próxima ação."
    }
  ],
  "butterfly": [
    {
      "label": "O que significa Transmissão no Miraculous da Borboleta?",
      "answer": "O conceito da Borboleta é Transmissão. Nooroo está ligado a enviar poder e estabelecer uma conexão mágica com outra pessoa por meio de uma borboleta especial."
    },
    {
      "label": "Como funciona o poder da Borboleta?",
      "answer": "O poder permite transmitir uma capacidade a uma pessoa escolhida por meio de uma borboleta mágica. Na série, essa transmissão é associada às akumatizações e ao fortalecimento de alguém para agir com um poder especial."
    },
    {
      "label": "Nooroo escolhe sozinho como a pessoa usa o poder?",
      "answer": "A transmissão concede uma habilidade, mas a pessoa que a recebe participa das decisões e pode usar o poder de acordo com seus objetivos. Por isso, a escolha de quem recebe a transmissão é uma responsabilidade importante."
    }
  ],
  "peacock": [
    {
      "label": "O que o Pavão representa?",
      "answer": "O Miraculous do Pavão representa a Emoção. Duusu está ligado à expressão de sentimentos e à criação de uma manifestação que ganha forma a partir de uma emoção."
    },
    {
      "label": "O que é um sentimonstro?",
      "answer": "É uma criatura criada por meio do poder do Pavão. Um amok é associado a um objeto e permite dar forma a uma manifestação ligada à emoção que originou a criação."
    },
    {
      "label": "O que é o amok?",
      "answer": "O amok é a energia mágica usada pelo poder do Pavão e fica ligado a um objeto que funciona como seu receptáculo. Esse vínculo é importante para a existência e o controle da criação."
    }
  ],
  "snake": [
    {
      "label": "Por que a Serpente representa Intuição?",
      "answer": "A Serpente representa Intuição: observar, aprender com o que aconteceu e escolher melhor na próxima tentativa. Sass combina paciência com pensamento estratégico."
    },
    {
      "label": "Como funciona o Second Chance?",
      "answer": "Second Chance permite ao portador marcar um ponto no tempo e retornar a ele depois. Assim, pode rever uma situação, manter o que aprendeu e tentar uma abordagem diferente."
    },
    {
      "label": "O que torna o Second Chance estratégico?",
      "answer": "O ponto de retorno precisa ser escolhido com cuidado. Marcar um momento útil antes de uma decisão importante dá ao portador uma referência para reavaliar o que aconteceu e tentar outra solução."
    }
  ],
  "horse": [
    {
      "label": "O que significa Migração no Miraculous do Cavalo?",
      "answer": "O Cavalo representa Migração e deslocamento. Kaalki está ligada a encontrar caminhos e conectar lugares que estão distantes."
    },
    {
      "label": "Como funciona o Voyage?",
      "answer": "Voyage abre um portal que permite atravessar de um lugar para outro. O portador escolhe o destino e usa a passagem para transportar a si mesmo ou outras pessoas, conforme a situação."
    },
    {
      "label": "Voyage é igual a correr muito rápido?",
      "answer": "Não. Voyage não aumenta a velocidade de corrida: ele cria uma passagem espacial. A vantagem é encurtar a distância entre dois locais, em vez de percorrê-la fisicamente."
    }
  ],
  "mouse": [
    {
      "label": "Por que o Rato representa Multiplicação?",
      "answer": "O Rato representa Multiplicação. Mullo está ligado à capacidade de dividir o portador em várias cópias menores para agir em mais de um lugar."
    },
    {
      "label": "Como funciona o Multitude?",
      "answer": "Multitude permite que o portador se multiplique em várias versões pequenas de si mesmo. Isso pode ajudar a explorar áreas, alcançar pontos diferentes ou realizar tarefas em paralelo."
    },
    {
      "label": "As cópias do Multitude são pessoas diferentes?",
      "answer": "São cópias do próprio portador criadas pelo poder do Rato, não novos portadores independentes. A ideia é multiplicar a presença e a capacidade de atuação do mesmo usuário."
    }
  ],
  "ox": [
    {
      "label": "O que representa o Miraculous do Boi?",
      "answer": "O Boi representa Determinação. Stompp está ligado à firmeza e à capacidade de não ceder diante de poderes que tentam impedir o portador."
    },
    {
      "label": "Como funciona o Resistance?",
      "answer": "Resistance concede resistência contra efeitos de poderes especiais. É uma defesa voltada a impedir que habilidades sobrenaturais controlem ou afetem o portador como fariam normalmente."
    },
    {
      "label": "Resistance significa invulnerabilidade total?",
      "answer": "Não é correto entender o poder como proteção absoluta contra qualquer coisa. O foco de Resistance é resistir a poderes especiais; isso não deve ser confundido com ser imune a todo impacto ou perigo físico."
    }
  ],
  "tiger": [
    {
      "label": "O que significa Exaltação no Miraculous do Tigre?",
      "answer": "O Tigre representa Exaltação, uma energia intensa e concentrada. Roaar incentiva coragem, presença e força aplicada no momento decisivo."
    },
    {
      "label": "Como funciona o Clout?",
      "answer": "Clout concentra a força do portador em um golpe extremamente poderoso. É uma manifestação de impacto físico, diferente de poderes que criam ilusões ou barreiras."
    },
    {
      "label": "Qual é o melhor uso do Clout?",
      "answer": "Clout deve ser usado com controle e propósito. Como concentra muita força em um único golpe, o portador precisa considerar o alvo e o ambiente para não causar danos indesejados."
    }
  ],
  "rabbit": [
    {
      "label": "Por que o Coelho representa Evolução?",
      "answer": "O Coelho representa Evolução e está ligado ao tempo. Fluff permite que o portador observe diferentes momentos e compreenda como passado, presente e futuro se conectam."
    },
    {
      "label": "Como funciona o Burrow?",
      "answer": "Burrow abre uma passagem temporal que permite viajar entre diferentes momentos. O portador entra no espaço conhecido como burrow para observar ou alcançar outro ponto no tempo."
    },
    {
      "label": "Burrow é um portal para qualquer lugar do espaço?",
      "answer": "O foco de Burrow é a viagem temporal, não a migração entre lugares comuns. Para atravessar distâncias espaciais, o conceito do Miraculous do Cavalo é o mais relacionado a esse tipo de deslocamento."
    }
  ],
  "dragon": [
    {
      "label": "O que significa Perfeição no Miraculous do Dragão?",
      "answer": "O Dragão representa Perfeição e se manifesta por meio de forças elementais da natureza. Longg ensina equilíbrio e adaptação entre diferentes formas de poder."
    },
    {
      "label": "Quais são os elementos do Longg?",
      "answer": "O poder elemental do Dragão está associado ao vento, à água e ao relâmpago. Essas formas oferecem maneiras diferentes de se mover e agir de acordo com a situação."
    },
    {
      "label": "O que muda entre as formas elementais?",
      "answer": "Cada forma expressa um elemento: vento, água ou relâmpago. O portador escolhe a forma adequada ao desafio, em vez de tratar as três como um único efeito indistinto."
    }
  ],
  "goat": [
    {
      "label": "O que representa o Miraculous da Cabra?",
      "answer": "A Cabra representa Paixão. Ziggy está ligada à criatividade, à imaginação e à persistência para transformar uma ideia em algo concreto."
    },
    {
      "label": "Como funciona o Genesis?",
      "answer": "Genesis permite criar um objeto específico imaginado pelo portador. A habilidade transforma uma ideia em um objeto útil para a situação."
    },
    {
      "label": "Genesis pode criar qualquer coisa sem limite?",
      "answer": "Genesis é uma criação de objeto, não uma autorização para fazer qualquer coisa sem regra. O portador precisa definir o que deseja criar e pensar em como esse objeto realmente ajuda na tarefa."
    }
  ],
  "monkey": [
    {
      "label": "O que significa Zombaria no Miraculous do Macaco?",
      "answer": "O Macaco representa Zombaria e imprevisibilidade. Xuppu gosta de quebrar o ritmo de quem depende demais de um plano perfeito."
    },
    {
      "label": "Como funciona o Uproar?",
      "answer": "Uproar cria um objeto com efeito de interferir nos poderes especiais de outra pessoa. Isso pode atrapalhar a habilidade de um adversário e mudar o rumo de uma disputa."
    },
    {
      "label": "Uproar destrói o poder do adversário para sempre?",
      "answer": "Não. Uproar é uma interferência temporária, não a remoção permanente do poder de alguém. Seu valor está em criar uma oportunidade enquanto a habilidade do outro está atrapalhada."
    }
  ],
  "rooster": [
    {
      "label": "O que significa Pretensão no Miraculous do Galo?",
      "answer": "O Galo representa Pretensão. Orikko está ligado à expressão de uma habilidade escolhida pelo portador, dentro das regras específicas do Miraculous."
    },
    {
      "label": "Como funciona o Sublimation?",
      "answer": "Sublimation permite escolher uma habilidade especial para o portador. A escolha precisa respeitar as regras do Miraculous e não deve ser tratada como acesso irrestrito a todos os poderes existentes."
    },
    {
      "label": "Posso escolher qualquer poder de outro Miraculous?",
      "answer": "Não. Sublimation tem limites próprios e não funciona como uma cópia livre de qualquer poder de outro Kwami. A habilidade escolhida precisa estar dentro das condições permitidas para o Galo."
    }
  ],
  "dog": [
    {
      "label": "O que significa Adoração no Miraculous do Cão?",
      "answer": "O Cão representa Adoração e lealdade. Barkk está ligada a encontrar, recuperar e trazer de volta aquilo que foi marcado."
    },
    {
      "label": "Como funciona o Fetch?",
      "answer": "Fetch usa a bola do Miraculous para marcar um objeto. Depois, o portador pode usar o poder para recuperar o objeto marcado, fazendo-o voltar até si."
    },
    {
      "label": "Fetch encontra qualquer objeto sem marcar?",
      "answer": "O poder está ligado ao objeto que foi marcado pela bola. Por isso, identificar e tocar o item desejado com a bola é parte importante do processo."
    }
  ],
  "pig": [
    {
      "label": "O que representa o Miraculous do Porco?",
      "answer": "O Porco representa Júbilo. Daizzi está ligada à alegria e à capacidade de revelar aquilo que desperta felicidade profunda em alguém."
    },
    {
      "label": "Como funciona o Gift?",
      "answer": "Gift apresenta ao alvo uma visão relacionada ao seu desejo mais profundo. A experiência é emocional e simbólica: mostra o que a pessoa mais deseja, em vez de simplesmente entregar esse desejo no mundo real."
    },
    {
      "label": "O Gift realiza o desejo mostrado?",
      "answer": "Não necessariamente. Gift revela uma visão do desejo da pessoa e provoca uma experiência emocional. A visão não equivale a conceder materialmente aquilo que foi desejado."
    }
  ]
};

function currentKwami(){
  const id=state.profile.miraculousId;
  const info=KWAMI_BY_MIRACULOUS[id];
  if(info)return {...info,miraculousId:id,miraculousName:getMiraculous(id)?.name||'Miraculous',avatar:`./assets/kwamis/${id}.png`};
  const m=getMiraculous(id);
  return {name:m?.kwami?.name||'Kwami companheiro',glyph:'✦',color:m?.color||'#b28cff',personality:m?.kwami?.personality||'curioso, gentil e prestativo',greeting:m?.kwami?.greeting||'Olá! Sou seu Kwami companheiro. Podemos descobrir o que este Miraculous pode fazer.',power:m?.subtitle||'Poder personalizado',powerDetail:m?.description||'Este Miraculous foi personalizado no catálogo do Mirafriends.',miraculousId:id,miraculousName:m?.name||'Miraculous personalizado',avatar:'./assets/logo.svg',customQuestions:m?.kwami?.questions||[],transformationOn:m?.kwami?.transformationOn||'',transformationOff:m?.kwami?.transformationOff||''};
}

const $ = (selector, root=document) => root.querySelector(selector);
const $$ = (selector, root=document) => [...root.querySelectorAll(selector)];
const state = {
  user:null, profile:{name:'Portador',miraculousId:null,friendCode:''},
  networkUser:null, serverPosts:[], networkFriends:[], networkIncomingRequests:[], networkOutgoingRequests:[],
  contacts:[], owners:{}, messages:[], activeContact:null, activeFriendshipId:null,
  chatPeer:null, callRotation:0, selectedCallMiraculousId:null, wheelPointer:null, wheelMoved:false, mediaObjectUrls:[],
  activeIncomingCall:null, activeOutgoingCalls:[], selectedCallIds:[], multiCallMode:false, customMiraculous:[],
  vibrationTimer:null, voiceVibrationTimer:null, mediaRecorder:null, audioChunks:[], voiceCall:null, assistantOpen:false, kwamiTransformed:false, flushingOutbox:false,
  selectedCallContactUid:null, groups:[], activeGroupId:null, moments:[], posts:[], cameraStream:null, cameraFacingMode:'environment', albumItems:[], albumObjectUrls:[], selectedAlbumId:null, mediaPickerMode:false, replyTarget:null, blockedContacts:[], mutedTypingTimer:null, lastTypingSignal:0, soundEnabled:localStorage.getItem('mirafriends-ui-sounds-v1')!=='off', stickerObjectUrls:[]
};
let localDbPromise=null;
let toastTimer;
const HOLDER_STORAGE_KEY = 'mirafriends-holder-records-v1';
let holderRecords = loadHolderRecords();
let selectedHolderMiraculousId = null;
let holderPhotoDraft = null;
let holderEditorReturnPage = 'holder-grid';
let WHEEL_STEP = 360 / miraculous.length;

const P2P_PROFILE_KEY='mirafriends-p2p-profile-v1';
const P2P_CONTACTS_KEY='mirafriends-p2p-contacts-v1';
const P2P_CUSTOM_KEY='mirafriends-p2p-custom-miraculous-v1';
const P2P_TURN_STORAGE_KEY='mirafriends-p2p-turn-servers-v1';
const HOLDER_CUSTOM_SLOTS_KEY='mirafriends-holder-custom-slots-v1';
const P2P_STUN_SERVERS=[
  {urls:['stun:stun.l.google.com:19302','stun:stun1.l.google.com:19302','stun:stun2.l.google.com:19302']},
  {urls:'stun:stun.cloudflare.com:3478'}
];
const P2P_CODE_VALID_MS=2*60*60*1000;
const p2pPeers=new Map();
const pendingP2PHandshakes=new Map();
let holderCustomSlots=loadHolderCustomSlots();
let selectedHolderNoteId=null;
let activeVoicePeer=null;
function randomLocalId(){return crypto.randomUUID?crypto.randomUUID():`${Date.now().toString(36)}${Math.random().toString(36).slice(2)}${Math.random().toString(36).slice(2)}`;}
function randomMiracode(){const words=new Uint32Array(2);crypto.getRandomValues(words);const value=((BigInt(words[0])<<32n)|BigInt(words[1])).toString(36).toUpperCase().padStart(13,'0');return `MIRA-${value.slice(-10)}`;}
function readLocalProfile(){try{return JSON.parse(localStorage.getItem(P2P_PROFILE_KEY)||'null')||null;}catch{return null;}}
function readLocalContacts(){try{const v=JSON.parse(localStorage.getItem(P2P_CONTACTS_KEY)||'[]');return Array.isArray(v)?v:[];}catch{return [];}}
function readLocalCustomMiraculous(){try{const v=JSON.parse(localStorage.getItem(P2P_CUSTOM_KEY)||'[]');return Array.isArray(v)?v:[];}catch{return [];}}
function readP2PTurnServers(){try{const v=JSON.parse(localStorage.getItem(P2P_TURN_STORAGE_KEY)||'[]');return Array.isArray(v)&&v.length?parseP2PTurnServers(JSON.stringify(v)):[];}catch{return [];}}
function parseP2PTurnServers(value){
  const parsed=JSON.parse(String(value||''));
  if(!Array.isArray(parsed)||!parsed.length||parsed.length>8)throw new Error('Cole uma lista JSON com 1 a 8 servidores TURN.');
  return parsed.map((server,index)=>{
    if(!server||typeof server!=='object'||Array.isArray(server))throw new Error(`Servidor TURN ${index+1} inválido.`);
    const urls=(Array.isArray(server.urls)?server.urls:[server.urls]).filter(Boolean).map(url=>String(url).trim());
    if(!urls.length||urls.length>6||urls.some(url=>!/^turns?:[^\s]+$/i.test(url)))throw new Error(`Servidor TURN ${index+1}: use uma URL turn: ou turns: válida.`);
    const username=String(server.username||'');
    const credential=String(server.credential||'');
    if(!username||!credential||username.length>512||credential.length>1024)throw new Error(`Servidor TURN ${index+1}: informe usuário e senha/credencial.`);
    return {urls:urls.length===1?urls[0]:urls,username,credential,credentialType:'password'};
  });
}
function getP2PIceServers(){return [...P2P_STUN_SERVERS,...readP2PTurnServers()];}
function initializeP2PTurnSettings(){
  const input=$('#p2p-turn-json');if(!input)return;
  const saved=readP2PTurnServers();if(saved.length){input.value=JSON.stringify(saved,null,2);$('#p2p-turn-status').textContent=`${saved.length} configuração(ões) TURN salva(s) neste aparelho. Configure as mesmas credenciais nos dois aparelhos.`;}
  else $('#p2p-turn-status').textContent='Nenhum TURN configurado. O app tentará conexão direta com STUN; algumas redes podem exigir um relay.';
}
function saveP2PTurnSettings(){
  try{
    const servers=parseP2PTurnServers($('#p2p-turn-json')?.value||'');
    localStorage.setItem(P2P_TURN_STORAGE_KEY,JSON.stringify(servers));
    $('#p2p-turn-status').textContent=`${servers.length} servidor(es) TURN salvo(s) somente neste aparelho. Cadastre as mesmas credenciais no outro aparelho.`;
    showToast('Configuração TURN salva neste aparelho.');
  }catch(error){$('#p2p-turn-status').textContent=error.message;showToast(error.message);}
}
function persistLocalState(){
  try{
    localStorage.setItem(P2P_PROFILE_KEY,JSON.stringify({uid:state.user?.uid||state.profile.uid,friendCode:state.profile.friendCode,name:state.profile.name,about:state.profile.about||'',miraculousId:state.profile.miraculousId,avatarData:state.profile.avatarData||null}));
    localStorage.setItem(P2P_CONTACTS_KEY,JSON.stringify(state.contacts));
    localStorage.setItem(P2P_CUSTOM_KEY,JSON.stringify(state.customMiraculous||[]));
    return true;
  }catch(error){showToast('O armazenamento local está cheio. Remova fotos ou exporte um backup.');return false;}
}
function makeLocalIdentity(){
  const old=readLocalProfile();
  return {uid:old?.uid||`local-${randomLocalId()}`,friendCode:old?.friendCode||randomMiracode(),name:old?.name||'Portador',about:String(old?.about||'').slice(0,120),miraculousId:old?.miraculousId||null,avatarData:old?.avatarData||null};
}
function loadHolderCustomSlots(){try{const v=JSON.parse(localStorage.getItem(HOLDER_CUSTOM_SLOTS_KEY)||'[]');return Array.isArray(v)?v.filter(s=>s&&typeof s.id==='string'&&s.id.startsWith('slot-')).slice(0,30):[];}catch{return [];}}
function saveHolderCustomSlots(){try{localStorage.setItem(HOLDER_CUSTOM_SLOTS_KEY,JSON.stringify(holderCustomSlots));return true;}catch{showToast('Não foi possível salvar os slots. O armazenamento pode estar cheio.');return false;}}
function getP2PFriendshipId(uid){return `p2p-${[String(state.user.uid),String(uid)].sort().join('-')}`;}
function myPeerCard(){return {uid:state.user.uid,code:state.profile.friendCode,name:state.profile.name,miraculousId:state.profile.miraculousId,avatarData:state.profile.avatarData||null};}
function setP2PStatus(text,online=false){setConnectionStatus(text,online);const status=$('#p2p-status');if(status)status.textContent=text;}
function base64UrlFromBytes(bytes){
  let binary='';
  for(let offset=0;offset<bytes.length;offset+=0x8000){
    binary+=String.fromCharCode(...bytes.subarray(offset,Math.min(offset+0x8000,bytes.length)));
  }
  return btoa(binary).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}
function bytesFromBase64Url(value){
  const encoded=String(value||'').replace(/-/g,'+').replace(/_/g,'/');
  const padded=encoded+'='.repeat((4-encoded.length%4)%4);
  const binary=atob(padded);
  return Uint8Array.from(binary,c=>c.charCodeAt(0));
}
async function encodeP2PCode(value){
  const bytes=new TextEncoder().encode(JSON.stringify(value));
  // Compacta a descrição SDP para reduzir o texto que precisa ser copiado/compartilhado.
  if('CompressionStream'in window){
    try{
      const compressed=await new Response(new Blob([bytes]).stream().pipeThrough(new CompressionStream('gzip'))).arrayBuffer();
      return `MIRAFRIENDS-P2P2.${base64UrlFromBytes(new Uint8Array(compressed))}`;
    }catch(error){console.warn('Compactação do código P2P indisponível; usando formato compatível.',error);}
  }
  return `MIRAFRIENDS-P2P1.${base64UrlFromBytes(bytes)}`;
}
async function decodeP2PCode(value){
  const text=String(value||'').replace(/\s+/g,'');
  if(text.length>160000)throw new Error('Código P2P muito grande. Confira se copiou apenas o convite/resposta.');
  const prefixV2='MIRAFRIENDS-P2P2.';
  const prefixV1='MIRAFRIENDS-P2P1.';
  let data;
  try{
    if(text.startsWith(prefixV2)){
      if(!('DecompressionStream'in window))throw new Error('Este navegador não consegue abrir códigos P2P compactados. Atualize o navegador.');
      const compressed=bytesFromBase64Url(text.slice(prefixV2.length));
      const json=await new Response(new Blob([compressed]).stream().pipeThrough(new DecompressionStream('gzip'))).text();
      data=JSON.parse(json);
    }else if(text.startsWith(prefixV1)){
      data=JSON.parse(new TextDecoder().decode(bytesFromBase64Url(text.slice(prefixV1.length))));
    }else throw new Error('Código inválido. Copie o bloco completo que começa com MIRAFRIENDS-P2P.');
  }catch(error){
    if(error?.message?.includes('códigos P2P compactados'))throw error;
    throw new Error('Não consegui ler este código. Copie novamente sem cortar o começo ou o final.');
  }
  if(data.v!==1||!data.handshakeId||!data.peer||typeof data.peer.uid!=='string'||!data.description?.type||!data.description?.sdp)throw new Error('Este convite está incompleto ou é de outra versão.');
  if(data.peer.uid.length>100||!data.peer.uid||typeof data.peer.name!=='string'||typeof data.peer.code!=='string')throw new Error('Identidade do convite inválida.');
  if(!Number.isFinite(data.createdAt)||Date.now()-data.createdAt>P2P_CODE_VALID_MS||data.createdAt>Date.now()+5*60*1000)throw new Error('Este código expirou (validade de 2 horas) ou tem horário inválido. Peça um novo convite.');
  if(!['offer','answer'].includes(data.type)||data.description.type!==data.type)throw new Error('Tipo de convite e descrição WebRTC não correspondem.');
  if(!/^[A-Za-z0-9_-]{8,100}$/.test(String(data.handshakeId))||String(data.peer.name||'').length>36||String(data.peer.code||'').length>16||String(data.description.sdp).length>130000)throw new Error('Dados do convite inválidos ou incompletos.');
  return data;
}
function waitForIceGathering(pc,timeout=18000){
  if(pc.iceGatheringState==='complete')return Promise.resolve(true);
  return new Promise(resolve=>{
    let done=false;let timer=null;let poll=null;
    const cleanup=()=>{pc.removeEventListener('icegatheringstatechange',check);pc.removeEventListener('icecandidate',onCandidate);if(timer)clearTimeout(timer);if(poll)clearInterval(poll);};
    const finish=complete=>{if(done)return;done=true;cleanup();resolve(Boolean(complete));};
    const check=()=>{if(pc.iceGatheringState==='complete')finish(true);else if(pc.signalingState==='closed')finish(false);};
    const onCandidate=event=>{if(!event.candidate)check();};
    pc.addEventListener('icegatheringstatechange',check);pc.addEventListener('icecandidate',onCandidate);
    poll=setInterval(check,120);timer=setTimeout(()=>finish(pc.iceGatheringState==='complete'),timeout);check();
  });
}
function countIceCandidates(description){
  const counts={host:0,srflx:0,relay:0,prflx:0};
  for(const line of String(description?.sdp||'').split(/\r?\n/)){
    if(!line.startsWith('a=candidate:'))continue;
    const match=line.match(/\styp\s+(host|srflx|relay|prflx)(?:\s|$)/i);if(match&&counts[match[1].toLowerCase()]!==undefined)counts[match[1].toLowerCase()]++;
  }
  return counts;
}
function iceSummaryText(result){
  const c=result.counts;
  if(!result.complete)return `A coleta de rede demorou; código criado com os caminhos encontrados até agora (públicos: ${c.srflx}, relay: ${c.relay}).`;
  if(c.relay)return `Relay TURN encontrado (${c.relay} candidato(s)); isso ajuda em redes mais restritivas.`;
  if(c.srflx)return `STUN encontrou ${c.srflx} caminho(s) público(s). A conexão à distância pode funcionar; firewalls/NATs restritivos ainda podem exigir TURN.`;
  return 'Não apareceu caminho público STUN/ TURN. O código foi criado, mas pode funcionar somente em redes compatíveis; verifique a internet ou configure TURN nos dois aparelhos.';
}
async function gatherIceForShare(pc,timeout=26000){
  const complete=await waitForIceGathering(pc,timeout);
  return {complete,counts:countIceCandidates(pc.localDescription)};
}
function localContactFromPeer(peer,friendshipId,universeIndex=0){
  return {uid:peer.uid,friendshipId,name:String(peer.name||'Portador').slice(0,36),about:String(peer.about||'').slice(0,120),code:String(peer.code||'PORTADOR').slice(0,16),miraculousId:peer.miraculousId||null,avatarData:peer.avatarData||null,transport:'webrtc',last:'P2P direto',universeIndex,addedAt:Date.now()};
}
function saveP2PContact(peer,friendshipId){
  if(!peer?.uid||peer.uid===state.user.uid)throw new Error('Não é possível conectar este aparelho a ele mesmo.');
  const index=state.contacts.findIndex(c=>c.uid===peer.uid);
  const previous=index>=0?state.contacts[index]:null;
  const sameMiraculous=peer.miraculousId?state.contacts.filter(c=>c.miraculousId===peer.miraculousId&&c.uid!==peer.uid):[];
  const universeIndex=Number.isInteger(previous?.universeIndex)?previous.universeIndex:sameMiraculous.length;
  const contact={...localContactFromPeer(peer,friendshipId,universeIndex),...(previous||{}),...localContactFromPeer(peer,friendshipId,universeIndex),addedAt:previous?.addedAt||Date.now()};
  if(index>=0)state.contacts[index]=contact;else state.contacts.push(contact);
  // Mantém um índice plural por Miraculous; nenhuma pessoa ocupa o símbolo sozinha.
  state.owners={};
  for(const c of state.contacts)if(c.miraculousId)(state.owners[c.miraculousId] ||= []).push(c.uid);
  persistLocalState();renderContacts();renderChats();renderCallCenter();renderGroupMemberPicker();return contact;
}
function setP2PConnectionState(peer){
  if(!peer)return;
  const connected=peer.pc?.connectionState==='connected'&&peer.channel?.readyState==='open';
  const label=connected?`P2P · ${peer.peerName||'PORTADOR'}`:'P2P · AGUARDANDO';
  if(state.chatPeer===peer||!state.chatPeer)setP2PStatus(label,connected);
}
function p2pPeerForContact(contact){return contact?p2pPeers.get(contact.friendshipId)||null:null;}
function sendP2PPacket(peer,packet){
  if(!peer?.channel||peer.channel.readyState!=='open')return false;
  try{peer.channel.send(JSON.stringify(packet));return true;}catch(error){console.warn('Falha ao enviar pacote P2P:',error);return false;}
}


function escapeHTML(value){return String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function newMessageId(){return crypto.randomUUID?crypto.randomUUID():([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g,c=>(c^crypto.getRandomValues(new Uint8Array(1))[0]&15>>c/4).toString(16));}
function getMiraculous(id){return miraculous.find(m=>m.id===id)||null;}
function sigilURL(id){const m=getMiraculous(id);return m?.iconData||`./assets/sigils/${m?.id||'pending'}.png`;}
function sigilImage(id,cls='',alt=''){
  return `<img class="${escapeHTML(cls)}" src="${sigilURL(id)}" alt="${escapeHTML(alt||'Emblema do Miraculous')}">`;
}
function setPendingImage(selector,id=null){const el=$(selector);if(el){el.src=sigilURL(id);el.alt=`Emblema do ${getMiraculous(id)?.name||'Miraculous'}`;}}
function showToast(message){const el=$('#toast');if(!el)return;el.textContent=message;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),3600);}
function setConnectionStatus(text,online=false){const el=$('#connection-status');if(el){el.textContent=text;el.classList.toggle('online',online);}}

function playUiSound(kind='tap'){
  if(!state.soundEnabled||!window.AudioContext)return;
  try{
    const ctx=playUiSound.context||(playUiSound.context=new AudioContext());
    if(ctx.state==='suspended')ctx.resume();
    const now=ctx.currentTime,osc=ctx.createOscillator(),gain=ctx.createGain();
    const notes={tap:520,send:720,receive:620,transform:880,success:760};
    osc.type='sine';osc.frequency.setValueAtTime(notes[kind]||520,now);
    osc.frequency.exponentialRampToValueAtTime((notes[kind]||520)*1.28,now+.085);
    gain.gain.setValueAtTime(.0001,now);gain.gain.exponentialRampToValueAtTime(.055,now+.012);gain.gain.exponentialRampToValueAtTime(.0001,now+.14);
    osc.connect(gain);gain.connect(ctx.destination);osc.start(now);osc.stop(now+.15);
  }catch(error){console.debug('Som da interface indisponível',error);}
}
function setUiSounds(enabled){state.soundEnabled=Boolean(enabled);localStorage.setItem('mirafriends-ui-sounds-v1',state.soundEnabled?'on':'off');const button=$('#toggle-ui-sounds');if(button)button.textContent=state.soundEnabled?'Sons da interface: ligados':'Sons da interface: desligados';if(state.soundEnabled)playUiSound('success');}
function playPageParticles(){document.documentElement.classList.add('ui-pulse');setTimeout(()=>document.documentElement.classList.remove('ui-pulse'),520);}

function hexToRgbTriplet(hex){
  const value=String(hex||'#C4AFE8').replace('#','');
  if(!/^[0-9a-f]{6}$/i.test(value))return '196,175,232';
  return `${parseInt(value.slice(0,2),16)},${parseInt(value.slice(2,4),16)},${parseInt(value.slice(4,6),16)}`;
}
function applyKwamiTransformationTheme(id){
  const m=getMiraculous(id)||{color:'#C4AFE8'};
  const color=preferredTransformationTone(id)||KWAMI_TRANSFORMATION_COLORS[id]||m.color||'#8159C9';
  document.documentElement.classList.toggle('kwami-transform-full',appearancePreferences.transformScope==='full');
  const ink=(id==='bee'||id==='horse'||id==='goat'||id==='rooster'||id==='ox')?'#251D2C':'#FFFFFF';
  document.documentElement.style.setProperty('--accent',color);
  document.documentElement.style.setProperty('--accent-rgb',hexToRgbTriplet(color));
  document.documentElement.style.setProperty('--accent-2',ink);
  document.documentElement.style.setProperty('--accent-ink',ink);
  document.documentElement.style.setProperty('--kwami-transform-color',color);
  document.documentElement.style.setProperty('--kwami-transform-rgb',hexToRgbTriplet(color));
  document.documentElement.style.setProperty('--kwami-transform-ink',ink);
  document.documentElement.style.setProperty('--bg',`color-mix(in srgb, ${color} 12%, #09090D)`);
  document.documentElement.style.setProperty('--panel',`color-mix(in srgb, ${color} 9%, #17131E)`);
  document.documentElement.style.setProperty('--panel-2',`color-mix(in srgb, ${color} 15%, #211B2B)`);
  document.documentElement.style.setProperty('--line',`color-mix(in srgb, ${color} 38%, rgba(255,255,255,.13))`);
  const meta=$('meta[name="theme-color"]');if(meta)meta.content=color;
}
function setTheme(id){
  applyPhotoVisibility();
  const m=getMiraculous(id)||{color:'#C4AFE8',rgb:'196,175,232'};
  const ink=({ladybug:'#9A5660',cat:'#4F8062',fox:'#98663D',bee:'#8F7739',turtle:'#4D806B',butterfly:'#735E98',peacock:'#477F77',snake:'#637E48',horse:'#6D6096',mouse:'#95617F',dog:'#89664E',tiger:'#9A604B',rabbit:'#4F8295',dragon:'#477E87',goat:'#81735D',monkey:'#89623C',rooster:'#8A733E',ox:'#80694F',pig:'#986475'})[id]||'#65546A';
  document.documentElement.dataset.miraculous=id||'neutral';
  document.documentElement.classList.toggle('kwami-transformed',Boolean(state.kwamiTransformed));
  document.documentElement.style.setProperty('--accent',m.color);
  document.documentElement.style.setProperty('--accent-rgb',m.custom?hexToRgbTriplet(m.color):(m.rgb||hexToRgbTriplet(m.color)));
  document.documentElement.style.setProperty('--accent-2',ink);
  document.documentElement.style.setProperty('--accent-ink',ink);
  document.documentElement.style.setProperty('--wallpaper-sigil',`url("${sigilURL(id)}")`);
  const themeRoot=THEME_ASSET_IDS.has(id)?`./assets/themes/${id}`:null;
  document.documentElement.style.setProperty('--theme-wallpaper',themeRoot?`url("${themeRoot}/wallpaper.jpg")`:`url("${sigilURL(id)}")`);
  document.documentElement.style.setProperty('--theme-icon-1',themeRoot?`url("${themeRoot}/decoration-1.jpg")`:`url("${sigilURL(id)}")`);
  document.documentElement.style.setProperty('--theme-icon-2',themeRoot?`url("${themeRoot}/decoration-2.jpg")`:`url("${sigilURL(id)}")`);
  if(state.kwamiTransformed&&state.profile.miraculousId)applyKwamiTransformationTheme(state.profile.miraculousId);
  else {document.documentElement.classList.remove('kwami-transformed','kwami-transform-full');for(const key of ['--kwami-transform-color','--kwami-transform-rgb','--kwami-transform-ink'])document.documentElement.style.removeProperty(key);const meta=$('meta[name="theme-color"]');if(meta)meta.content=m.color;document.documentElement.style.removeProperty('--bg');document.documentElement.style.removeProperty('--panel');document.documentElement.style.removeProperty('--panel-2');document.documentElement.style.removeProperty('--line');}
}
function profileFromUser(user){
  state.user={...user};
  state.profile={name:user.name||user.displayName||'Portador',about:String(user.about||'').slice(0,120),miraculousId:user.miraculousId||null,friendCode:user.friendCode||randomMiracode(),avatarData:user.avatarData||null,uid:user.uid};
  setTheme(state.profile.miraculousId);refreshProfileBits();updateKwamiPet();persistLocalState();
}
function runPageTransition(update){
  const reducedMotion=window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  if(!reducedMotion&&typeof document.startViewTransition==='function'){
    try{
      const transition=document.startViewTransition(()=>update());
      transition?.finished?.catch(()=>{});
      return;
    }catch(error){/* O fallback CSS mantém a navegação funcional em navegadores incompatíveis. */}
  }
  update();
}
function activatePage(page,navPage=page){
  document.body.classList.toggle('holder-grid-active',page==='holder-grid');
  playUiSound('tap');playPageParticles();runPageTransition(()=>{
    $$('.page').forEach(p=>p.classList.toggle('active',p.id===`page-${page}`));
    $$('.nav-item').forEach(b=>b.classList.toggle('active',navPage!==null&&b.dataset.page===navPage));
    window.scrollTo(0,0);
  });
}
let holderLandscapeLocked=false;
let holderLandscapeRequestPending=false;
let holderLandscapeFullscreen=false;
let holderLandscapeWanted=false;
function requestHolderLandscape(){
  holderLandscapeWanted=true;
  const root=document.documentElement;root.classList.add('holder-landscape-mode');
  if(holderLandscapeLocked||holderLandscapeRequestPending)return;
  const hint=$('#holder-orientation-hint');
  const orientation=window.screen?.orientation;
  const leaveAppFullscreen=()=>{
    if(holderLandscapeFullscreen&&document.fullscreenElement){document.exitFullscreen?.().catch?.(()=>{});}
    holderLandscapeFullscreen=false;
  };
  const showFallback=()=>{
    holderLandscapeRequestPending=false;
    leaveAppFullscreen();
    if(!holderLandscapeWanted)return;
    root.classList.add('holder-landscape-fallback');
    if(hint)hint.hidden=false;
    showToast('Gire o aparelho para a horizontal. A grade já está adaptada para paisagem.');
  };
  if(!orientation?.lock){showFallback();return;}
  holderLandscapeRequestPending=true;
  (async()=>{
    const standalone=window.matchMedia?.('(display-mode: standalone)').matches||navigator.standalone===true;
    // In a browser tab, request fullscreen from the navigation tap before locking.
    // Installed PWAs already have an app display context.
    if(!standalone&&!document.fullscreenElement&&document.documentElement.requestFullscreen){
      try{
        await document.documentElement.requestFullscreen({navigationUI:'hide'});
        if(!holderLandscapeWanted){holderLandscapeRequestPending=false;document.exitFullscreen?.().catch?.(()=>{});return;}
        holderLandscapeFullscreen=true;
      }catch{/* Continue with a direct orientation request. */}
    }
    await orientation.lock('landscape');
    if(!holderLandscapeWanted){holderLandscapeRequestPending=false;try{orientation.unlock?.();}catch{}leaveAppFullscreen();return;}
    holderLandscapeLocked=true;holderLandscapeRequestPending=false;
    root.classList.remove('holder-landscape-fallback');if(hint)hint.hidden=true;
  })().catch(()=>showFallback());
}
function retryHolderLandscape(){
  const root=document.documentElement;root.classList.remove('holder-landscape-fallback');
  holderLandscapeRequestPending=false;requestHolderLandscape();
}
function releaseHolderLandscape(){
  holderLandscapeWanted=false;
  const root=document.documentElement;root.classList.remove('holder-landscape-mode','holder-landscape-fallback');const hint=$('#holder-orientation-hint');if(hint)hint.hidden=true;
  if(holderLandscapeLocked||holderLandscapeRequestPending){try{window.screen?.orientation?.unlock?.();}catch{}holderLandscapeLocked=false;holderLandscapeRequestPending=false;}
  if(holderLandscapeFullscreen&&document.fullscreenElement){document.exitFullscreen?.().catch?.(()=>{});holderLandscapeFullscreen=false;}
}

function renderAppearanceSettings(){
  const page=$('#page-settings');if(!page)return;
  const picker=$('#transform-tone-miraculous');if(!picker)return;
  const options=miraculous.map(item=>`<option value="${escapeHTML(item.id)}">${escapeHTML(item.name)}</option>`).join('');
  const chosen=picker.value||state.profile.miraculousId||miraculous[0]?.id||'ladybug';
  if(picker.innerHTML!==options)picker.innerHTML=options;
  picker.value=miraculous.some(item=>item.id===chosen)?chosen:(state.profile.miraculousId||miraculous[0]?.id||'ladybug');
  const id=picker.value,m=getMiraculous(id),tones=tonesForMiraculous(id),selected=preferredTransformationTone(id);
  const title=$('#transform-tone-current');if(title)title.textContent=`${m?.name||'Miraculous'} · escolha um tom para a transformação`;
  const swatches=$('#transform-tone-swatches');if(swatches)swatches.innerHTML=tones.map((color,index)=>`<button type="button" class="transform-tone-swatch ${selected.toLowerCase()===color.toLowerCase()?'selected':''}" data-transform-tone="${escapeHTML(color)}" aria-label="Selecionar tom ${index+1}" title="${escapeHTML(color)}" style="--tone-color:${escapeHTML(color)}"><span></span><small>${['Principal','Claro','Profundo','Suave'][index]}</small></button>`).join('');
  const slider=$('#theme-photo-visibility');if(slider)slider.value=String(appearancePreferences.photoVisibility??62);
  const output=$('#theme-photo-visibility-value');if(output)output.textContent=`${Math.round(appearancePreferences.photoVisibility??62)}%`;
  $$('[data-transform-scope]').forEach(button=>{const active=button.dataset.transformScope===(appearancePreferences.transformScope||'soft');button.classList.toggle('selected',active);button.setAttribute('aria-pressed',String(active));});
}
function saveAndApplyAppearance(){saveAppearancePreferences();applyPhotoVisibility();if(state.kwamiTransformed)applyKwamiTransformationTheme(state.profile.miraculousId);}
$('#page-settings')?.addEventListener('input',event=>{
  if(event.target.id==='theme-photo-visibility'){appearancePreferences.photoVisibility=Math.max(0,Math.min(100,Number(event.target.value)||0));const output=$('#theme-photo-visibility-value');if(output)output.textContent=`${appearancePreferences.photoVisibility}%`;saveAndApplyAppearance();}
});
$('#page-settings')?.addEventListener('change',event=>{
  if(event.target.id==='transform-tone-miraculous')renderAppearanceSettings();
});
$('#page-settings')?.addEventListener('click',event=>{
  const tone=event.target.closest('[data-transform-tone]');
  if(tone){const id=$('#transform-tone-miraculous')?.value;if(!id)return;appearancePreferences.tones={...appearancePreferences.tones,[id]:tone.dataset.transformTone};saveAndApplyAppearance();renderAppearanceSettings();return;}
  const scope=event.target.closest('[data-transform-scope]');
  if(scope){appearancePreferences.transformScope=scope.dataset.transformScope==='full'?'full':'soft';saveAndApplyAppearance();renderAppearanceSettings();return;}
  if(event.target.closest('#appearance-reset')){appearancePreferences={photoVisibility:62,transformScope:'soft',tones:{}};saveAndApplyAppearance();renderAppearanceSettings();showToast('Aparência restaurada para os padrões.');}
});
function nav(page){
  document.body.classList.toggle('holder-grid-active',page==='holder-grid');
  // A transformação pertence ao portador e permanece ativa ao trocar de área.
  if(page!=='chat'&&state.assistantOpen)updateKwamiTransformControls();
  const holderPage=page==='holder-hub'||page==='holder-grid';
  if(holderPage)requestHolderLandscape();else releaseHolderLandscape();
  if(page!=='media')stopCamera();
  if(page!=='group-chat'){const dialogue=$('#group-kwami-dialogue');if(dialogue){dialogue.hidden=true;dialogue.innerHTML='';}}
  setTheme(state.profile.miraculousId);
  runPageTransition(()=>{
    $$('.page').forEach(p=>p.classList.toggle('active',p.id===`page-${page}`));
    $$('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.page===page));
    if(page==='home')renderHome();
    if(page==='contacts')renderContacts();
    if(page==='chats')renderChats();
    if(page==='calls')renderCallCenter();
    if(page==='miraculous')renderMiraculous();
    if(page==='profile')renderProfile();
    if(page==='holder-grid')renderHolderGrid();
    if(page==='groups')renderGroups();
    if(page==='moments')renderMoments();
    if(page==='posts')renderPosts();
    if(page==='media')renderAlbum();
    if(page==='settings')renderAppearanceSettings();
    window.scrollTo(0,0);
  });
}

function tile(m,selected=false){
  const locked=Boolean(state.profile.miraculousId);
  const status=selected?'Sua identidade':locked?'Identidade já escolhida':m.custom?'Personalizado':'Selecionar';
  const disabled=locked&&!selected;
  return `<button class="miraculous-tile ${selected?'selected':''}" data-select-miraculous="${escapeHTML(m.id)}" style="--contact-rgb:${escapeHTML(m.rgb)}" ${disabled?'disabled aria-disabled="true"':''}>${sigilImage(m.id,'tile-sigil',`Emblema do Miraculous ${m.name}`)}<span class="tile-name">${escapeHTML(m.name)}</span><span class="tile-status">${escapeHTML(status)}</span></button>`;
}
function renderSelection(){
  if(state.profile.miraculousId)return;
  $('#selection-grid').innerHTML=miraculous.map(m=>tile(m,false)).join('');
  $('#selection-custom-button').hidden=false;
  $('#selection-modal').hidden=false;
}
async function playMiraculousAwakening(id){
  const m=getMiraculous(id);const overlay=$('#miraculous-awakening');if(!m||!overlay)return;
  const image=$('#awakening-sigil');image.src=sigilURL(id);image.alt=`Símbolo do Miraculous ${m.name}`;
  $('#awakening-title').textContent=m.name.toLocaleUpperCase('pt-BR');
  overlay.style.setProperty('--awakening-color',m.color);
  overlay.style.setProperty('--awakening-rgb',m.rgb||hexToRgbTriplet(m.color));
  overlay.hidden=false;overlay.classList.remove('awakening-active');
  // Force style calculation so the nine-second wave sequence restarts consistently.
  void overlay.offsetWidth;requestAnimationFrame(()=>overlay.classList.add('awakening-active'));
  const reduced=window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  await new Promise(resolve=>setTimeout(resolve,reduced?9000:9000));
  overlay.classList.remove('awakening-active');overlay.classList.add('awakening-leaving');
  await new Promise(resolve=>setTimeout(resolve,420));overlay.classList.remove('awakening-leaving');overlay.hidden=true;
}
async function chooseMiraculous(id){
  if(state.profile.miraculousId){showToast('Seu Miraculous já está fixado neste aparelho.');return;}
  if(!getMiraculous(id)){showToast('Esse Miraculous não existe no catálogo local.');return;}
  const chosen=getMiraculous(id);
  profileFromUser({...state.user,name:state.profile.name,friendCode:state.profile.friendCode,miraculousId:id,avatarData:state.profile.avatarData});
  window.dispatchEvent(new Event('mirafriends:profile-updated'));
  $('#selection-modal').hidden=true;
  await playMiraculousAwakening(id);
  renderAll();nav('home');showToast(`${chosen.name} definido. Sua central está pronta.`);
}
async function showIdentityLoader(id){
  const m=getMiraculous(id);if(!m)return;const overlay=$('#identity-loader');setPendingImage('#identity-loader-icon',id);$('#identity-loader-name').textContent=m.name;overlay.hidden=false;
  requestAnimationFrame(()=>overlay.classList.add('visible'));
  await new Promise(resolve=>setTimeout(resolve,1550));overlay.classList.remove('visible');await new Promise(resolve=>setTimeout(resolve,380));overlay.hidden=true;
}
function openCustomCreator(){
  $('#custom-miraculous-modal').hidden=false;$('#custom-error').textContent='';
}
function closeCustomCreator(){ $('#custom-miraculous-modal').hidden=true; }
async function fileToDataUrl(file,maxBytes=400*1024){
  if(!file||!/^image\/(png|jpeg|webp)$/.test(file.type))throw new Error('Use uma imagem PNG, JPG ou WebP.');
  if(file.size>maxBytes)throw new Error(`A imagem precisa ter até ${Math.floor(maxBytes/1024)} KB.`);
  return await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.onerror=()=>reject(new Error('Não foi possível ler a imagem.'));reader.readAsDataURL(file);});
}

async function compressHolderPhoto(file){
  if(!file||!/^image\/(png|jpeg|webp)$/.test(file.type))throw new Error('Escolha uma foto PNG, JPG ou WebP.');
  const objectUrl=URL.createObjectURL(file);
  try{
    const image=await new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>resolve(img);img.onerror=()=>reject(new Error('Não foi possível abrir esta fotografia.'));img.src=objectUrl;});
    const maxSide=420,scale=Math.min(1,maxSide/Math.max(image.naturalWidth,image.naturalHeight));
    const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(image.naturalWidth*scale));canvas.height=Math.max(1,Math.round(image.naturalHeight*scale));
    const context=canvas.getContext('2d');if(!context)throw new Error('Este navegador não permite processar a fotografia.');
    context.fillStyle='#160c22';context.fillRect(0,0,canvas.width,canvas.height);context.drawImage(image,0,0,canvas.width,canvas.height);
    let blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/webp',0.72));
    if(!blob)blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/jpeg',0.68));
    if(blob.size>110*1024)blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/jpeg',0.52));
    if(!blob||blob.size>110*1024)throw new Error('A foto ainda ficou muito grande. Escolha uma imagem menor.');
    return await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.onerror=()=>reject(new Error('Não foi possível salvar a fotografia.'));reader.readAsDataURL(blob);});
  }finally{URL.revokeObjectURL(objectUrl);}
}

async function createCustomMiraculous(event){
  event?.preventDefault();const button=$('#save-custom-miraculous');button.disabled=true;$('#custom-error').textContent='';
  try{
    const file=$('#custom-icon-file').files?.[0];const iconData=await fileToDataUrl(file);
    const name=$('#custom-name').value.trim();const subtitle=$('#custom-subtitle').value.trim();
    if(name.length<2||subtitle.length<2)throw new Error('Informe um nome e um conceito.');
    const questions=[1,2,3].map(i=>({label:$('#custom-kwami-q'+i).value.trim(),answer:$('#custom-kwami-a'+i).value.trim()})).filter(q=>q.label&&q.answer);
    const kwamiName=$('#custom-kwami-name').value.trim(),kwamiPersonality=$('#custom-kwami-personality').value.trim(),kwamiGreeting=$('#custom-kwami-greeting').value.trim(),transformationOn=$('#custom-kwami-transform-on').value.trim(),transformationOff=$('#custom-kwami-transform-off').value.trim();
    if((kwamiName||kwamiPersonality||kwamiGreeting||transformationOn||transformationOff||questions.length)&&!kwamiName)throw new Error('Para cadastrar informações do Kwami, informe também o nome dele.');
    const item={id:`custom-${randomLocalId().slice(0,12)}`,name,subtitle,description:$('#custom-description').value.trim(),color:$('#custom-color').value,rgb:hexToRgbTriplet($('#custom-color').value),iconData,custom:true,kwami:kwamiName?{name:kwamiName,personality:kwamiPersonality||'curioso, gentil e prestativo',greeting:kwamiGreeting||`Olá! Sou ${kwamiName}. Vamos descobrir esse Miraculous juntos?`,transformationOn,transformationOff,questions}:null};
    state.customMiraculous.push(item);miraculous.push(item);persistLocalState();WHEEL_STEP=360/miraculous.length;$('#wheel-ring').dataset.built='';
    closeCustomCreator();$('#custom-miraculous-form').reset();$('#custom-icon-preview').src='';$('#custom-icon-preview').hidden=true;renderAll();showToast(`${name} adicionado somente à coleção deste aparelho.`);if(!state.profile.miraculousId)renderSelection();
  }catch(error){$('#custom-error').textContent=error.message||'Não foi possível criar esse Miraculous.';}
  finally{button.disabled=false;}
}
async function uploadProfilePhoto(file){
  try{const avatarData=await fileToDataUrl(file,400*1024);profileFromUser({...state.user,avatarData});renderProfile();showToast('Foto salva somente neste aparelho.');}
  catch(error){showToast(error.message);}
}
function refreshProfileBits(){
  const m=getMiraculous(state.profile.miraculousId);
  $('#home-name').textContent=state.profile.name||'Portador';
  $('#home-sigil').innerHTML=sigilImage(m?.id,'home-sigil-image','Emblema do seu Miraculous');
  setPendingImage('#top-avatar-sigil',state.profile.miraculousId);
}
function normalizeContactUniverses(contacts){
  const counters={};
  for(const contact of contacts||[]){
    const id=contact?.miraculousId;if(!id)continue;
    if(!Number.isInteger(contact.universeIndex)||contact.universeIndex<0)contact.universeIndex=counters[id]||0;
    counters[id]=Math.max(counters[id]||0,contact.universeIndex+1);
  }
  return contacts;
}
function rebuildMiraculousOwners(){
  state.owners={};
  for(const contact of state.contacts||[])if(contact.miraculousId)(state.owners[contact.miraculousId] ||= []).push(contact.uid);
}
function universeLabel(contact){
  const n=Math.max(0,Number(contact?.universeIndex)||0);
  return n===0?'Universo original':`Universo ${n}`;
}
function contactCard(c,showLast=false,showAvatar=false){
  const m=getMiraculous(c.miraculousId);
  const avatar=showAvatar&&c.avatarData?`<img class="contact-sigil conversation-photo" src="${c.avatarData}" alt="Foto de perfil de ${escapeHTML(c.name)}">`:sigilImage(c.miraculousId,'contact-sigil',`Emblema do Miraculous da ${m?.name||''}`);
  const universe=c.miraculousId?`<span class="universe-tag">${escapeHTML(universeLabel(c))}</span>`:'';
  return `<button class="contact-row" data-open-chat="${escapeHTML(c.uid)}" style="--contact-rgb:${m?.rgb||'178,140,255'}"><span class="contact-avatar">${avatar}</span><span class="contact-info"><strong>${escapeHTML(c.name)}</strong><small>${escapeHTML(m?.name||'Portador')}${showLast&&c.last?` · ${escapeHTML(c.last)}`:''}</small>${universe}</span><span class="contact-meta"><small class="contact-code">${escapeHTML(c.code||'AMIGO')}</small><span class="row-arrow">›</span></span></button>`;
}
function renderHome(){
  refreshProfileBits();
  updateKwamiPet();
  const recent=state.contacts.slice(0,3);
  $('#home-recent').innerHTML=recent.length?recent.map(c=>contactCard(c,true)).join(''):'<div class="empty-state"><p>Você ainda não emparelhou outros portadores.</p><button class="secondary-button" data-page="contacts">Conectar por P2P</button></div>';
  $('#simulate-incoming').disabled=false;
}

function loadHolderRecords(){
  try{const raw=localStorage.getItem(HOLDER_STORAGE_KEY);const parsed=raw?JSON.parse(raw):{};return parsed&&typeof parsed==='object'&&!Array.isArray(parsed)?parsed:{};}
  catch{return {};}
}
function saveHolderRecords(){
  try{localStorage.setItem(HOLDER_STORAGE_KEY,JSON.stringify(holderRecords));return true;}
  catch{showToast('Não foi possível salvar. Reduza o tamanho da fotografia.');return false;}
}
function renderHolderGrid(){
  const grid=$('#holder-grid');if(!grid)return;
  const official=miraculous.filter(m=>!m.custom);
  const slotMarkup=(id,label,icon,custom=false)=>{
    const record=holderRecords[id]||{};const safeName=record.name?escapeHTML(record.name):'Adicionar portador';
    const photo=record.photoData?`<img class="holder-slot-photo" src="${record.photoData}" alt="Foto de ${escapeHTML(record.name||'portador')}">`:'<span class="holder-slot-empty" aria-hidden="true">♙</span>';
    const symbol=custom?`<button type="button" class="holder-slot-symbol custom-symbol" data-holder-note="${escapeHTML(id)}" aria-label="Abrir nota do slot adicional">?</button>`:`<button type="button" class="holder-slot-symbol" data-holder-note="${escapeHTML(id)}" aria-label="Abrir nota do Miraculous ${escapeHTML(label)}">${sigilImage(id,'','Emblema de '+label)}</button>`;
    return `<div class="holder-slot ${record.name?'has-holder':''}" data-slot-id="${escapeHTML(id)}">${symbol}<button type="button" class="holder-slot-photo-trigger" data-holder-edit="${escapeHTML(id)}" aria-label="Abrir ficha do portador ${escapeHTML(label)}">${photo}</button><strong class="holder-slot-name">${safeName}</strong></div>`;
  };
  grid.innerHTML=official.map(m=>slotMarkup(m.id,m.name,sigilURL(m.id),false)).join('')+
    holderCustomSlots.map(slot=>slotMarkup(slot.id,slot.name||'Slot personalizado','?',true)).join('');
}
let holderEditorOpening=false;
async function openHolderEditor(id){
  if(holderEditorOpening)return;const m=getMiraculous(id);const custom=holderCustomSlots.find(s=>s.id===id);if(!m&&!custom)return;
  holderEditorOpening=true;selectedHolderMiraculousId=id;const record=holderRecords[id]||{};
  $('#holder-editor-title').textContent=record.name?'Editar portador':'Cadastrar portador';$('#holder-category').value=record.category||'🐾 Chat';
  $('#holder-name').value=record.name||'';$('#holder-hero').value=record.hero||'';$('#holder-miraculous').value=m?.name||'? · Slot adicional';
  $('#holder-kwami').value=record.kwami||KWAMI_BY_MIRACULOUS[id]?.name||'';$('#holder-power').value=record.power||KWAMI_BY_MIRACULOUS[id]?.power||'';
  holderPhotoDraft=record.photoData||null;$('#holder-photo-preview').src=holderPhotoDraft||(m?sigilURL(id):'assets/sigils/pending.png');
  $('#holder-editor-status').textContent=record.name?'Cadastro salvo. Você pode atualizar os dados.':'Escolha uma fotografia e preencha os dados do portador.';
  $('#holder-delete').hidden=!record.name&&!custom;$('#holder-photo-input').value='';
  if(m)try{await showIdentityLoader(id);}finally{holderEditorOpening=false;}else holderEditorOpening=false;
  if(selectedHolderMiraculousId===id)$('#holder-editor').hidden=false;
}
function closeHolderEditor(){ $('#holder-editor').hidden=true;holderPhotoDraft=null;selectedHolderMiraculousId=null; }
async function saveHolderEditor(event){
  event.preventDefault();const id=selectedHolderMiraculousId;if(!id)return;const name=$('#holder-name').value.trim();
  if(name.length<2){$('#holder-editor-status').textContent='Digite um nome com pelo menos 2 caracteres.';return;}
  const m=getMiraculous(id);const custom=holderCustomSlots.some(s=>s.id===id);
  const record={...(holderRecords[id]||{}),category:$('#holder-category').value,name,hero:$('#holder-hero').value.trim(),miraculousId:custom?'?':id,miraculousName:m?.name||'?',customSlot:custom,kwami:$('#holder-kwami').value.trim()||KWAMI_BY_MIRACULOUS[id]?.name||'',power:$('#holder-power').value.trim()||KWAMI_BY_MIRACULOUS[id]?.power||'',photoData:holderPhotoDraft||null,updatedAt:Date.now()};
  holderRecords[id]=record;if(!saveHolderRecords())return;renderHolderGrid();closeHolderEditor();showToast(`${name} foi salvo na grade de portadores.`);
}
function deleteHolderRecord(){
  const id=selectedHolderMiraculousId;if(!id||(!holderRecords[id]&&!holderCustomSlots.some(s=>s.id===id)))return;
  if(!confirm('Remover este cadastro e este slot, se for adicional?'))return;delete holderRecords[id];
  const index=holderCustomSlots.findIndex(s=>s.id===id);if(index>=0)holderCustomSlots.splice(index,1);
  saveHolderRecords();saveHolderCustomSlots();renderHolderGrid();closeHolderEditor();showToast('Cadastro removido.');
}
function openHolderGridWithRipple(){
  requestHolderLandscape();
  const button=$('#open-holder-grid');if(!button||button.classList.contains('launching'))return;
  const reduce=window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  if(reduce){nav('holder-grid');return;}
  button.classList.add('launching');
  const frame=button.closest('.holder-hud-frame');frame?.classList.add('holder-launching');
  if(navigator.vibrate)navigator.vibrate(18);
  setTimeout(()=>{button.classList.remove('launching');frame?.classList.remove('holder-launching');nav('holder-grid');},620);
}

function renderContacts(){
  const q=($('#contact-search')?.value||'').trim().toLowerCase();const filtered=state.contacts.filter(c=>`${c.name} ${getMiraculous(c.miraculousId)?.name||''} ${c.code||''}`.toLowerCase().includes(q));
  $('#contacts-list').innerHTML=filtered.map(c=>contactCard(c,false)).join('')||'<div class="empty-state"><p>Nenhum portador emparelhado. Crie um convite P2P e troque a resposta com outra pessoa.</p></div>';
  $('#contacts-count').textContent=String(state.contacts.length);$('#requests-count').textContent='0';$('#requests-list').innerHTML='<div class="empty-state compact-empty"><p>O modo P2P sem servidor não possui solicitações assíncronas.</p></div>';
  $('#contacts-empty-note').textContent='A lista mostra os portadores que já foram emparelhados diretamente com este aparelho.';
}
function kwamiContactCard(){
  if(!state.profile.miraculousId)return '';
  const kwami=currentKwami();
  return `<button class="contact-row kwami-contact-row" type="button" data-open-kwami-chat style="--contact-rgb:${hexToRgbTriplet(kwami.color)}"><span class="contact-avatar kwami-contact-avatar"><img class="kwami-contact-image" src="${escapeHTML(kwami.avatar)}" alt="${escapeHTML(kwami.name)}"><img class="kwami-contact-sigil" src="${escapeHTML(sigilURL(kwami.miraculousId))}" alt="Símbolo do Miraculous"></span><span class="contact-info"><strong>${escapeHTML(kwami.name)}</strong><small>Seu Kwami · ${escapeHTML(kwami.miraculousName)}</small></span><span class="contact-meta"><small class="contact-code">PESSOAL</small><span class="row-arrow">›</span></span></button>`;
}
function renderChats(){
  const kwami=kwamiContactCard();
  const contacts=state.contacts.map(c=>contactCard(c,true,true)).join('');
  $('#chats-list').innerHTML=(kwami+contacts)||'<div class="empty-state"><p>Suas conversas aparecem depois de emparelhar outro portador diretamente por P2P.</p></div>';
}
let kwamiFlightTimer=null;
let kwamiDisplayedId=null;
let kwamiLastPosition=null;
let kwamiDragState=null;
let kwamiSuppressClickUntil=0;
const KWAMI_POSITION_KEY='mirafriends-kwami-pet-position-v2';
function kwamiPetBounds(){
  const pet=$('#kwami-pet');const width=pet?.offsetWidth||94,height=pet?.offsetHeight||108;
  const nav=$('.bottom-nav');const navHeight=nav&&!nav.hidden?nav.getBoundingClientRect().height:0;
  return {minX:8,minY:Math.max(78,(document.querySelector('.topbar')?.getBoundingClientRect().bottom||64)+10),maxX:Math.max(8,innerWidth-width-8),maxY:Math.max(84,innerHeight-height-navHeight-12)};
}
function applyKwamiPetPosition(){
  const pet=$('#kwami-pet');if(!pet||!kwamiLastPosition)return;
  const b=kwamiPetBounds();kwamiLastPosition={x:Math.round(Math.max(b.minX,Math.min(b.maxX,kwamiLastPosition.x))),y:Math.round(Math.max(b.minY,Math.min(b.maxY,kwamiLastPosition.y)))};
  pet.style.left=`${kwamiLastPosition.x}px`;pet.style.top=`${kwamiLastPosition.y}px`;pet.style.right='auto';pet.style.bottom='auto';
}
function moveKwamiCompanion(){
  const pet=$('#kwami-pet');if(!pet||pet.hidden)return;
  if(!kwamiLastPosition){
    try{const saved=JSON.parse(localStorage.getItem(KWAMI_POSITION_KEY)||'null');if(saved&&Number.isFinite(saved.x)&&Number.isFinite(saved.y))kwamiLastPosition=saved;}catch{}
    if(!kwamiLastPosition){const b=kwamiPetBounds();kwamiLastPosition={x:b.maxX,y:Math.max(b.minY,b.maxY-8)};}
  }
  applyKwamiPetPosition();
}
function startKwamiFlight(){
  clearInterval(kwamiFlightTimer);kwamiFlightTimer=null;moveKwamiCompanion();
  if(window.matchMedia?.('(prefers-reduced-motion: reduce)').matches)return;
  kwamiFlightTimer=setInterval(()=>{
    const pet=$('#kwami-pet');if(!pet||pet.hidden||kwamiDragState||document.hidden)return;
    const b=kwamiPetBounds();const margin=18;
    kwamiLastPosition={
      x:Math.round(b.minX+margin+Math.random()*Math.max(1,b.maxX-b.minX-margin*2)),
      y:Math.round(b.minY+Math.random()*Math.max(1,b.maxY-b.minY))
    };
    applyKwamiPetPosition();
  },4300+Math.random()*1700);
}
function initKwamiPetDrag(){
  const pet=$('#kwami-pet');if(!pet||pet.dataset.dragReady==='1')return;pet.dataset.dragReady='1';
  pet.addEventListener('pointerdown',event=>{
    if(event.pointerType==='mouse'&&event.button!==0)return;
    const rect=pet.getBoundingClientRect();kwamiDragState={pointerId:event.pointerId,startX:event.clientX,startY:event.clientY,originX:rect.left,originY:rect.top,moved:false};
    clearInterval(kwamiFlightTimer);kwamiFlightTimer=null;pet.classList.add('drag-pressed');pet.classList.add('is-dragging');try{pet.setPointerCapture(event.pointerId);}catch{}
  });
  pet.addEventListener('pointermove',event=>{
    if(!kwamiDragState||kwamiDragState.pointerId!==event.pointerId)return;
    const dx=event.clientX-kwamiDragState.startX,dy=event.clientY-kwamiDragState.startY;
    if(!kwamiDragState.moved&&Math.hypot(dx,dy)<5)return;
    kwamiDragState.moved=true;pet.classList.add('dragging');kwamiLastPosition={x:kwamiDragState.originX+dx,y:kwamiDragState.originY+dy};applyKwamiPetPosition();event.preventDefault();
  });
  const finish=event=>{
    if(!kwamiDragState||kwamiDragState.pointerId!==event.pointerId)return;
    const moved=kwamiDragState.moved;kwamiDragState=null;pet.classList.remove('drag-pressed','dragging','is-dragging');
    if(moved){kwamiSuppressClickUntil=Date.now()+450;try{localStorage.setItem(KWAMI_POSITION_KEY,JSON.stringify(kwamiLastPosition));}catch{}}
    startKwamiFlight();
  };
  pet.addEventListener('pointerup',finish);pet.addEventListener('pointercancel',finish);
  pet.addEventListener('click',event=>{if(Date.now()<kwamiSuppressClickUntil){event.preventDefault();event.stopImmediatePropagation();}},true);
}
function updateKwamiPet(){
  const pet=$('#kwami-pet');if(!pet)return;
  if(!state.profile.miraculousId){pet.hidden=true;clearInterval(kwamiFlightTimer);kwamiFlightTimer=null;kwamiDisplayedId=null;return;}
  const kwami=currentKwami();
  const changed=kwamiDisplayedId!==kwami.miraculousId;
  pet.hidden=false;pet.style.setProperty('--kwami-color',kwami.color||'var(--accent)');
  pet.setAttribute('aria-label',`Abrir perguntas para ${kwami.name}`);pet.title=`Pergunte algo a ${kwami.name}`;
  const image=$('#kwami-pet-image');
  if(image&&changed){image.src=kwami.avatar;image.alt=kwami.name;image.onerror=()=>{image.src='./assets/logo.svg';};}
  $('#kwami-pet-name').textContent=kwami.name;
  if(changed)kwamiDisplayedId=kwami.miraculousId;
  if(changed||!kwamiFlightTimer)startKwamiFlight();
}
initKwamiPetDrag();
window.addEventListener('resize',()=>moveKwamiCompanion());
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&state.profile.miraculousId)startKwamiFlight();});
window.matchMedia?.('(prefers-reduced-motion: reduce)').addEventListener?.('change',event=>{if(event.matches){clearInterval(kwamiFlightTimer);kwamiFlightTimer=null;}else if(state.profile.miraculousId)startKwamiFlight();});
const KWAMI_CHAT_STORAGE_PREFIX='mirafriends-kwami-chat-v1:';
function loadKwamiMessages(miraculousId){
  try{const value=JSON.parse(localStorage.getItem(`${KWAMI_CHAT_STORAGE_PREFIX}${miraculousId}`)||'[]');return Array.isArray(value)?value.filter(m=>m&&typeof m.text==='string').slice(-200):[];}catch{return [];}
}
function saveKwamiMessages(){
  const id=state.profile.miraculousId;if(!id)return;
  try{localStorage.setItem(`${KWAMI_CHAT_STORAGE_PREFIX}${id}`,JSON.stringify(state.messages.slice(-200)));}
  catch(error){console.warn('Histórico local do Kwami:',error);showToast('Não foi possível salvar todo o histórico do Kwami neste aparelho.');}
}
function openKwamiChat(){
  if(!state.profile.miraculousId){showToast('Escolha seu Miraculous para receber seu Kwami.');nav('miraculous');return;}
  const kwami=currentKwami();closeKwamiMenu();closeChatPeer();
  state.assistantOpen=true;state.activeContact=null;state.activeFriendshipId=null;state.messages=loadKwamiMessages(kwami.miraculousId);
  setTheme(state.profile.miraculousId);
  $('#chat-contact-name').textContent=kwami.name;$('#chat-contact-miraculous').textContent=`Seu Kwami · ${kwami.miraculousName} · contato local`;
  $('#chat-avatar').innerHTML=`<span class="kwami-chat-avatar" aria-label="${escapeHTML(kwami.name)}"><img src="${escapeHTML(kwami.avatar)}" alt="${escapeHTML(kwami.name)}"></span>`;
  $('#start-voice-call').hidden=true;$('#start-video-call').hidden=true;$('#kwami-chat-transform').hidden=false;$('#bot-help-panel').hidden=false;$('#composer-tools').hidden=true;
  $('#kwami-panel-title').textContent=`Converse com ${kwami.name}`;
  $('#kwami-panel-caption').textContent=`${kwami.name} conhece o Miraculous da ${kwami.miraculousName}. Esta conversa é pessoal e fica salva somente neste aparelho.`;
  updateKwamiSuggestion(kwami);
  if(!state.messages.length){state.messages=[{id:newMessageId(),senderUid:`kwami-${kwami.miraculousId}`,isKwami:true,text:kwami.greeting,createdAt:Date.now()}];saveKwamiMessages();}
  updateKwamiTransformControls();activatePage('chat','chats');renderMessages();
}

function appHelpReply(question){
  const q=String(question||'').toLowerCase();
  if(/curiosidade|curiosidades/.test(q)){const facts=['O Miracode começa com MIRA- e serve para conferir a identidade durante o emparelhamento.','Sem um registro central, duas pessoas podem escolher o mesmo Miraculous em aparelhos diferentes.','O tema visual muda de acordo com o Miraculous escolhido.','A foto de perfil é exibida nas conversas; na Central de Portadores você pode cadastrar uma foto diferente para cada Miraculous.','A Central de Chamadas envia alertas P2P; as ligações de voz são feitas dentro da conversa.'];return `Curiosidade ✨ ${facts[Math.floor(Math.random()*facts.length)]}`;}
  const answers=[
    [/conect.*(celular|aparelho|dispositivo)|emparelh|outro dispositivo|dois aparelhos|conectar.*p2p|aceit.*convite|conclu.*emparelh/,`Para conectar dois aparelhos: 1) abra o Mirafriends por HTTPS nos dois e mantenha as páginas abertas; 2) no aparelho A, abra Portadores e toque em “Criar meu convite”; compartilhe o bloco completo; 3) no aparelho B, cole o bloco no campo único “Código recebido” e toque em “Processar código automaticamente”; o aplicativo reconhece o convite e gera a resposta; 4) B compartilha a resposta; 5) A cola a resposta no mesmo campo e toca em “Processar código automaticamente” novamente; 6) aguardem aparecer “Conectado”. O código vale por 2 horas. “Verificar minha rede” conta os candidatos STUN/TURN locais, mas não garante conexão com o outro aparelho. STUN pode ajudar redes diferentes; redes restritivas podem exigir TURN configurado nos dois aparelhos. O Miracode serve para conferir a identidade, não para localizar pessoas.`],
    [/c[oó]digo|encontr|miracode|meu c[oó]digo/,`Seu Miracode fica em Perfil, na seção “Seu código de amizade”. Toque em “Copiar meu código” para compartilhar. Ele identifica você, mas não é senha e não encontra pessoas sozinho.`],
    [/grade|central de portadores|cadastro de portador/,`Abra “Grade de portadores” na tela inicial. Na primeira tela, toque no grande núcleo circular; as ondas levam à grade. Toque no símbolo para editar a nota daquele Miraculous ou na fotografia para abrir a ficha do portador. O botão “Adicionar slot” cria espaços extras com o símbolo ?. As informações ficam salvas somente neste aparelho.`],
    [/mensag|conversa|chat|envi.*(foto|áudio|audio|arquivo)/,`Depois de emparelhar dois aparelhos pela troca de convite P2P, abra Mensagens e entre na conversa do contato. Você pode enviar texto, fotos e áudios pelo canal WebRTC direto. O histórico e a fila de envio ficam no aparelho. Uma mensagem pendente só é entregue quando os dois aparelhos estiverem online e emparelhados novamente.`],
    [/chamad|liga|voz|microfone/,`Para fazer uma chamada de voz: primeiro emparelhe os aparelhos pela troca de convite e resposta P2P; depois abra Mensagens, entre na conversa do contato e toque no ícone de telefone. Autorize o microfone quando o navegador pedir. O outro portador precisa estar online, com o canal P2P ativo, e aceitar a chamada. Mantenham o Mirafriends aberto durante a ligação.`],
    [/backup|salv|transfer|outro aparelho|migrar/,`Para transferir sua identidade e seus dados, abra Perfil e toque em “Baixar backup local”. Guarde o arquivo JSON. No outro aparelho, abra o Mirafriends e use “Restaurar backup” na mesma área. Depois, emparelhe novamente seus contatos, pois uma conexão P2P ativa não é transferida no backup.`],
    [/miraculous|escolh|símbolo|simbolo/,`Na área “Meu Miraculous”, você vê sua identidade. A escolha fica salva neste aparelho. Sem um registro central, não há como impedir que outra pessoa escolha o mesmo símbolo.`],
    [/perfil|foto|nome/,`Abra Perfil para alterar seu nome e escolher uma foto. A foto de perfil é mostrada nas conversas; a Central de Portadores tem cadastros separados por Miraculous.`],
    [/adicion|amigo|amizade|portador/,`Para conectar alguém, abra Portadores e crie um convite P2P. Envie o texto para a outra pessoa por um canal privado. Ela cola o convite, gera uma resposta e envia de volta. Você cola a resposta para concluir. O Miracode ajuda a conferir a identidade, mas não encontra pessoas sozinho.`],
    [/p2p|conex[aã]o direta|peer/,`Mirafriends Connect usa WebRTC diretamente. Sem servidor de sinalização, os portadores trocam manualmente um convite e uma resposta pela área Portadores. STUN público ajuda a atravessar NAT; algumas redes ainda exigem TURN e podem não conectar sem ele.`],
    [/alerta|urg[eê]ncia|vibr/,`Os alertas da Central de Chamadas são enviados diretamente aos contatos com canal P2P ativo. Vibração depende do navegador, das permissões e das configurações do Android. Com o aplicativo fechado, não há garantia de alerta ou vibração.`],
    [/senha|entrar|conta|cadastro|usu[aá]rio/,`O Mirafriends cria uma identidade local automaticamente. Em Perfil, exporte um backup para transferir seus dados para outro aparelho e restaure esse arquivo lá. O Miracode não é senha nem mecanismo de autenticação.`]
  ];
  const found=answers.find(([re])=>re.test(q));
  if(found)return found[1];
  return 'Ainda não encontrei uma resposta específica. Posso explicar meu Miraculous, meu poder, os Miracodes, amizades, mensagens, chamadas ou a Central de Portadores.';
}
function normalizeKwamiQuestionText(value){
  return String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9\s]/g,' ').replace(/\s+/g,' ').trim();
}
function matchKwamiPersonalQuestion(kwami,question){
  const entries=kwami.customQuestions?.length?kwami.customQuestions:(KWAMI_MIRACULOUS_FAQ[kwami.miraculousId]||[]);
  const query=normalizeKwamiQuestionText(question);
  if(!query||!entries.length)return null;
  const stop=new Set(['como','qual','quais','porque','por','para','sobre','voce','seu','sua','meu','minha','isso','esse','essa','funciona','pode','fazer','faz','tem','the','uma','com','que','dos','das','nos','nas']);
  let best=null,bestScore=0;
  for(const entry of entries){
    const label=normalizeKwamiQuestionText(entry.label);
    if(!label)continue;
    if(query===label||query.includes(label)||label.includes(query))return entry;
    const tokens=[...new Set(label.split(' ').filter(word=>word.length>=3&&!stop.has(word)))];
    if(!tokens.length)continue;
    const hits=tokens.filter(word=>query.includes(word)).length;
    const score=hits/tokens.length;
    if(score>bestScore){bestScore=score;best=entry;}
  }
  return bestScore>=.66?best:null;
}
function assistantReply(question){
  const kwami=currentKwami();const q=String(question||'').toLowerCase();
  if(/^(oi|olá|ola|e aí|eai|bom dia|boa tarde|boa noite)[!.? ]*$/.test(q.trim()))return kwami.greeting;
  const personalAnswer=matchKwamiPersonalQuestion(kwami,question);
  if(personalAnswer?.answer)return `${kwamiVoicePrefix(kwami)}${personalAnswer.answer}`;
  if(/(qual|quem|como).*(seu nome|voc[eê]|kwami)|quem (e|é) voc[eê]|seu nome/.test(q))return `${kwami.name} falando! Sou o Kwami associado ao Miraculous ${kwami.miraculousName}. Minha personalidade é ${kwami.personality}.`;
  if(/personalidade|como voc[eê] é|como voc[eê] e/.test(q))return `Eu sou ${kwami.personality}. E não, isso não significa que vou concordar com tudo que você disser. 😉`;
  if(/curiosidade|curiosidades|me conta.*fato|me conte.*fato|me fala.*sobre/.test(q)&&!/app|mirafriends/.test(q))return `${kwami.name} conta: ${kwami.powerDetail}`;
  if(/poder|habilidade|cataclysm|lucky charm|mirage|venom|shell.?ter|second chance|voyage|burrow|genesis|uproar|sublimation|fetch|gift|multitude|resistance|clout/.test(q))return `${kwami.name} aqui. Meu Miraculous está ligado a ${kwami.power}. ${kwami.powerDetail}`;
  if(/seu miraculous|seu miraculoso|qual.*miraculous|qual.*joia|qual.*s[ií]mbolo|curiosidade.*(miraculous|poder)|me conte.*(sobre|miraculous)|explique.*(miraculous|poder)|como funciona.*(miraculous|poder)/.test(q))return `${kwami.name} explica: acompanho o Miraculous da ${kwami.miraculousName}, ligado ao conceito de ${kwami.power}. ${kwami.powerDetail}`;
  const answer=appHelpReply(question);
  const prefixes={cat:'Hmph. Plagg explica: ',ladybug:'Tikki vai explicar com carinho: ',fox:'Trixx tem um truque útil: ',turtle:'Wayzz sugere calma: ',bee:'Pollen, com precisão: ',monkey:'Xuppu tem uma ideia travessa: ',pig:'Daizzi responde com alegria: ',butterfly:'Nooroo explica com delicadeza: ',peacock:'Duusu sente que esta é uma ótima pergunta: ',snake:'Sass observa: ',horse:'Kaalki indica o caminho direto: ',mouse:'Mullo descobriu rapidinho: ',dog:'Barkk está aqui para ajudar: ',tiger:'Roaar responde sem hesitar: ',rabbit:'Fluff veio do futuro com uma resposta: ',dragon:'Longg responde com serenidade: ',goat:'Ziggy teve uma ideia: ',rooster:'Orikko anuncia: ',ox:'Stompp vai direto ao ponto: '};
  return `${prefixes[kwami.miraculousId]||`${kwami.name}: `}${answer}`;
}
function sendAssistantMessage(question){
  const text=String(question||'').trim();if(!text||!state.assistantOpen)return;
  const kwami=currentKwami();
  state.messages.push({id:newMessageId(),senderUid:state.user?.uid||'local-user',isKwami:false,text,createdAt:Date.now()});
  state.messages.push({id:newMessageId(),senderUid:`kwami-${kwami.miraculousId}`,isKwami:true,text:assistantReply(text),createdAt:Date.now()+1});
  state.messages=state.messages.slice(-200);saveKwamiMessages();renderMessages();
}


function kwamiVoicePrefix(kwami){
  const prefixes={cat:'Hmph. Plagg explica: ',ladybug:'Tikki conta com carinho: ',fox:'Trixx revela: ',turtle:'Wayzz explica com calma: ',bee:'Pollen responde com precisão: ',monkey:'Xuppu dá uma resposta travessa: ',pig:'Daizzi responde com alegria: ',butterfly:'Nooroo explica com cuidado: ',peacock:'Duusu compartilha: ',snake:'Sass observa: ',horse:'Kaalki esclarece: ',mouse:'Mullo descobriu: ',dog:'Barkk explica: ',tiger:'Roaar responde com energia: ',rabbit:'Fluff veio do tempo com esta resposta: ',dragon:'Longg explica com serenidade: ',goat:'Ziggy imaginou e respondeu: ',rooster:'Orikko anuncia: ',ox:'Stompp vai direto ao ponto: '};
  return prefixes[kwami.miraculousId]||`${kwami.name}: `;
}
function renderKwamiMiraculousQuestions(kwami){
  const list=$('#kwami-specific-questions');if(!list)return;
  const entries=kwami.customQuestions?.length?kwami.customQuestions:(KWAMI_MIRACULOUS_FAQ[kwami.miraculousId]||[]);
  list.innerHTML=entries.map((entry,index)=>`<button type="button" data-kwami-faq="${index}">${escapeHTML(entry.label)}</button>`).join('');
  $('#kwami-specific-title').textContent=`SOBRE O MIRACULOUS DA ${String(kwami.miraculousName||'').toLocaleUpperCase('pt-BR')}`;
  $('#kwami-specific-section').hidden=entries.length===0;
}
function answerKwamiLore(index){
  const kwami=currentKwami();
  const entries=kwami.customQuestions?.length?kwami.customQuestions:(KWAMI_MIRACULOUS_FAQ[kwami.miraculousId]||[]);const entry=entries[index];
  if(!entry)return;
  $('#kwami-menu-answer-text').textContent=`${kwamiVoicePrefix(kwami)}${entry.answer}`;
  $('#kwami-menu-answer').hidden=false;
  $('#kwami-menu-connect').hidden=true;
  $('#kwami-menu-answer').scrollIntoView({block:'nearest',behavior:'smooth'});
}

function getKwamiTransformationPhrases(kwami=currentKwami()){
  return KWAMI_TRANSFORMATION_PHRASES[kwami.miraculousId]||{on:kwami.transformationOn||`${kwami.name}, transformar!`,off:kwami.transformationOff||'Destransformar'};
}
function updateKwamiTransformControls(){
  const kwami=state.profile.miraculousId?currentKwami():null;
  const phrases=kwami?getKwamiTransformationPhrases(kwami):{on:'Transformar',off:'Destransformar'};
  const label=state.kwamiTransformed?phrases.off:phrases.on;
  const menuButton=$('#kwami-menu-transform');if(menuButton){menuButton.textContent=`✨ ${label}`;menuButton.setAttribute('aria-pressed',String(state.kwamiTransformed));}
  const panelButton=$('#kwami-panel-transform');if(panelButton){panelButton.textContent=label;panelButton.setAttribute('aria-pressed',String(state.kwamiTransformed));}
  const chatButton=$('#kwami-chat-transform');if(chatButton){chatButton.hidden=!state.assistantOpen;chatButton.textContent=state.kwamiTransformed?label:phrases.on;chatButton.setAttribute('aria-pressed',String(state.kwamiTransformed));}
  const dock=$('#kwami-transform-dock');if(dock){dock.hidden=!state.kwamiTransformed;$('#kwami-transform-dock-text').textContent=label;const image=$('#kwami-transform-dock-sigil');if(image&&kwami){image.src=sigilURL(kwami.miraculousId);image.alt=`Miraculous ${kwami.miraculousName}`;}}
  const answerSigil=$('#kwami-menu-answer-sigil');if(answerSigil&&kwami){answerSigil.src=sigilURL(kwami.miraculousId);answerSigil.alt=`Símbolo do Miraculous da ${kwami.miraculousName}`;}
}
function toggleKwamiTransformation(){
  if(!state.profile.miraculousId){showToast('Escolha um Miraculous antes de transformar.');return;}
  const kwami=currentKwami();const phrases=getKwamiTransformationPhrases(kwami);state.kwamiTransformed=!state.kwamiTransformed;
  document.documentElement.classList.toggle('kwami-transformed',state.kwamiTransformed);
  if(state.kwamiTransformed)applyKwamiTransformationTheme(kwami.miraculousId);else setTheme(state.profile.miraculousId);
  const flash=$('#kwami-transform-flash');if(flash){flash.classList.remove('active');void flash.offsetWidth;flash.classList.add('active');setTimeout(()=>flash.classList.remove('active'),720);}
  updateKwamiTransformControls();playUiSound('transform');playPageParticles();showToast(state.kwamiTransformed?phrases.on:phrases.off);
}

function getKwamiSuggestion(kwami=currentKwami()){
  const personality=String(kwami?.personality||'').toLowerCase();
  if(/curios|criativ|imagin|artístic/.test(personality))return 'Escolha uma coisa que você gostaria de aprender hoje e anote a primeira pergunta que vier à mente.';
  if(/calm|sábio|sabio|seren|paciente|ponderad/.test(personality))return 'Antes de começar uma tarefa, respire com calma e organize os dois primeiros passos.';
  if(/protet|leal|atencios|gentil|acolhedor/.test(personality))return 'Que tal mandar uma mensagem para um amigo e perguntar como ele está?';
  if(/sarc|irrever|travess|brincalh/.test(personality))return 'Experimente resolver uma tarefa de um jeito diferente — uma pausa criativa também ajuda.';
  if(/determin|diret|objetiv|disciplin/.test(personality))return 'Escolha uma prioridade e conclua uma pequena etapa antes de passar à próxima.';
  return 'Separe um tempinho para algo de que você gosta e compartilhe uma novidade com seus amigos.';
}
function updateKwamiSuggestion(kwami=currentKwami()){
  if(!kwami)return;const suggestion=getKwamiSuggestion(kwami);
  const chat=$('#kwami-chat-suggestion');if(chat)chat.textContent=suggestion;
  const menu=$('#kwami-menu-suggestion');if(menu)menu.textContent=suggestion;
}
function openKwamiMenu(){
  if(!state.profile.miraculousId){showToast('Escolha seu Miraculous para receber seu Kwami.');nav('miraculous');return;}
  const kwami=currentKwami();
  const modal=$('#kwami-help-modal');if(!modal)return;
  $('#kwami-menu-name').textContent=kwami.name;
  $('#kwami-menu-miraculous').textContent=`Seu companheiro · Miraculous da ${kwami.miraculousName}`;
  $('#kwami-menu-image').src=kwami.avatar;$('#kwami-menu-image').alt=kwami.name;
  $('#kwami-menu-greeting').textContent=kwami.greeting;
  updateKwamiSuggestion(kwami);renderKwamiMiraculousQuestions(kwami);
  modal.style.setProperty('--kwami-menu-accent',kwami.color||'var(--accent)');
  $('#kwami-menu-answer').hidden=true;$('#kwami-menu-connect').hidden=true;
  $('#kwami-menu-answer-text').textContent='';updateKwamiTransformControls();
  modal.hidden=false;$('#kwami-menu-close').focus();
}
function closeKwamiMenu(){const modal=$('#kwami-help-modal');if(modal)modal.hidden=true;}
function resetKwamiMenuQuestions(){
  $('#kwami-menu-answer').hidden=true;$('#kwami-menu-connect').hidden=true;$('#kwami-menu-answer-text').textContent='';
  $('.kwami-menu-questions')?.scrollIntoView({block:'nearest',behavior:'smooth'});
}
function answerKwamiPreset(question){
  const answer=assistantReply(question);
  $('#kwami-menu-answer-text').textContent=answer;
  $('#kwami-menu-answer').hidden=false;
  const isConnection=/conect|emparelh|dispositivo|aparelho|celular|p2p/i.test(question);
  $('#kwami-menu-connect').hidden=!isConnection;
  $('#kwami-menu-answer').scrollIntoView({block:'nearest',behavior:'smooth'});
}

function renderMiraculous(){
  const m=getMiraculous(state.profile.miraculousId);
  $('#chosen-card').innerHTML=m?`<div class="chosen-sigil">${sigilImage(m.id,'chosen-sigil-image',`Emblema do Miraculous ${m.name}`)}</div><div><span class="eyebrow">SUA IDENTIDADE FIXA</span><h2>${escapeHTML(m.name)}</h2><p>${escapeHTML(m.subtitle)} · Tema ativo neste perfil</p></div>`:'<div class="chosen-sigil"></div><div><span class="eyebrow">AINDA NÃO ESCOLHIDO</span><h2>Escolha seu Miraculous</h2><p>Seu tema visual será aplicado ao aplicativo.</p></div>';
  $('#miraculous-grid').innerHTML=miraculous.map(x=>tile(x,x.id===state.profile.miraculousId)).join()+'<button class="miraculous-tile add-custom-tile" data-open-custom><span class="custom-plus">＋</span><span class="tile-name">Criar personalizado</span><span class="tile-status">Adicionar novo símbolo</span></button>';
}
function renderProfile(){
  const m=getMiraculous(state.profile.miraculousId);const about=$('#profile-about');if(about)about.value=state.profile.about||'';setPendingImage('#profile-sigil',state.profile.miraculousId);
  $('#profile-display-name').textContent=state.profile.name||'Portador';$('#profile-miraculous-name').textContent=m?`Portador do Miraculous da ${m.name}`:'Nenhum Miraculous selecionado';
  $('#display-name').value=state.profile.name||'';$('#profile-photo-input').disabled=false;$('#save-profile').disabled=false;
  $('#my-friend-code').textContent=state.profile.friendCode||'MIRA-000000';$('#reset-demo').hidden=true;
  $('#enable-notifications').textContent='Ativar notificações locais';$('#enable-notifications').disabled=false;const sounds=$('#toggle-ui-sounds');if(sounds)sounds.textContent=state.soundEnabled?'Sons da interface: ligados':'Sons da interface: desligados';
  $('#profile-mode-note').textContent=state.networkUser?'Conta online: amizades por Miracode e publicações com fotos/vídeos são sincronizadas pelo servidor Mirafriends. Chamadas e mensagens P2P desta beta ainda exigem emparelhamento direto.':'Modo local: conecte uma conta online em Portadores para sincronizar amizades, publicações, fotos e vídeos no servidor.';
}
function renderAll(){renderHome();renderContacts();renderChats();renderMiraculous();renderProfile();renderCallCenter();renderPosts();}

// Carrossel circular: os itens giram como o seletor holográfico da referência.
function selectedIndexFromRotation(rotation){return ((Math.round(-rotation/WHEEL_STEP)%miraculous.length)+miraculous.length)%miraculous.length;}
function buildWheel(){
  WHEEL_STEP=360/miraculous.length;const ring=$('#wheel-ring');ring.innerHTML='';
  miraculous.forEach((m,index)=>{
    const button=document.createElement('button');button.type='button';button.className='wheel-item';button.dataset.callMiraculous=m.id;
    button.style.setProperty('--wheel-angle',`${index*WHEEL_STEP}deg`);button.setAttribute('aria-label',`Selecionar o Miraculous da ${m.name}`);
    button.innerHTML=sigilImage(m.id,'wheel-sigil',`Emblema do Miraculous ${m.name}`);ring.append(button);
  });
  ring.dataset.built='true';
}
function setCallRotation(rotation,animate=true){
  state.callRotation=rotation;
  const ring=$('#wheel-ring');ring.style.transition=animate?'transform 650ms cubic-bezier(.18,.78,.2,1)':'none';
  ring.style.transform=`translateZ(-1px) rotateY(${rotation}deg)`;
  const index=selectedIndexFromRotation(rotation);state.selectedCallMiraculousId=miraculous[index].id;
  const matches=state.contacts.filter(contact=>contact.miraculousId===state.selectedCallMiraculousId).sort((a,b)=>(a.universeIndex||0)-(b.universeIndex||0));
  if(!matches.some(contact=>contact.uid===state.selectedCallContactUid))state.selectedCallContactUid=matches[0]?.uid||null;
  $$('.wheel-item').forEach((button,i)=>{const selected=i===index;button.classList.toggle('selected',selected);button.setAttribute('aria-pressed',String(selected));});
  updateCallTarget();
}
function snapToCallIndex(index){const safe=((index%miraculous.length)+miraculous.length)%miraculous.length;setCallRotation(-safe*WHEEL_STEP,true);}
function toggleMultiCallMode(){
  state.multiCallMode=!state.multiCallMode;state.selectedCallIds=state.multiCallMode?[state.selectedCallContactUid].filter(Boolean):[];
  $('#call-wheel').classList.toggle('multi-active',state.multiCallMode);$('#multi-call-hint').textContent=state.multiCallMode?'Modo múltiplo ativo · toque nos emblemas para incluir ou retirar':'Toque duas vezes no emblema central para selecionar vários';
  $('#multi-call-button').textContent=state.multiCallMode?'Concluir seleção múltipla':'Selecionar vários';updateCallTarget();
}
function renderCallPortersForMiraculous(){
  const list=$('#call-porters-list');if(!list)return;
  const contacts=state.contacts.filter(contact=>contact.miraculousId===state.selectedCallMiraculousId).sort((a,b)=>(a.universeIndex||0)-(b.universeIndex||0));
  if(!contacts.length){list.innerHTML='<div class="empty-state">Nenhum portador deste Miraculous foi adicionado ainda.</div>';return;}
  list.innerHTML=contacts.map(contact=>{
    const peer=p2pPeerForContact(contact),online=peer?.channel?.readyState==='open';
    const selected=state.multiCallMode?state.selectedCallIds.includes(contact.uid):state.selectedCallContactUid===contact.uid;
    return `<button type="button" class="call-porter-option ${selected?'selected':''}" data-call-contact="${escapeHTML(contact.uid)}" aria-pressed="${selected}"><span class="call-porter-sigil">${sigilImage(contact.miraculousId,'','')}</span><span class="call-porter-copy"><strong>${escapeHTML(contact.name)}</strong><small>${escapeHTML(universeLabel(contact))} · ${online?'Conectado':'Offline'}</small></span><span class="call-porter-check">${selected?'✓':online?'○':'—'}</span></button>`;
  }).join('');
}
function toggleCallSelection(uid){
  const contact=state.contacts.find(item=>item.uid===uid);if(!contact)return;
  if(!state.multiCallMode){state.selectedCallContactUid=uid;updateCallTarget();return;}
  const index=state.selectedCallIds.indexOf(uid);if(index>=0)state.selectedCallIds.splice(index,1);else state.selectedCallIds.push(uid);
  updateCallTarget();
}
function updateCallTarget(){
  const selected=getMiraculous(state.selectedCallMiraculousId);if(!selected)return;
  if(!state.multiCallMode){
    const first=state.contacts.filter(c=>c.miraculousId===selected.id).sort((a,b)=>(a.universeIndex||0)-(b.universeIndex||0))[0];
    if(!state.selectedCallContactUid||!state.contacts.some(c=>c.uid===state.selectedCallContactUid&&c.miraculousId===selected.id))state.selectedCallContactUid=first?.uid||null;
  }
  setPendingImage('#wheel-center-sigil',selected.id);$('#wheel-center-name').textContent=selected.name;setPendingImage('#call-target-sigil',selected.id);
  renderCallPortersForMiraculous();
  const selectedContacts=(state.multiCallMode?state.selectedCallIds:[state.selectedCallContactUid]).map(uid=>state.contacts.find(c=>c.uid===uid)).filter(Boolean);
  const readyContacts=selectedContacts.filter(contact=>p2pPeerForContact(contact)?.channel?.readyState==='open');
  $$('.wheel-item').forEach(button=>button.classList.toggle('queued',state.multiCallMode&&selectedContacts.some(c=>c.miraculousId===button.dataset.callMiraculous)));
  const nameEl=$('#call-target-name'),detailEl=$('#call-target-detail'),statusEl=$('#call-target-status'),button=$('#send-call-button');
  if(state.multiCallMode){
    $('#target-eyebrow').textContent='SELEÇÃO DE PORTADORES';nameEl.textContent=`${selectedContacts.length} portador(es) selecionado(s)`;
    detailEl.textContent=selectedContacts.map(c=>`${c.name} · ${universeLabel(c)}`).join(' | ')||'Toque nos nomes acima para selecionar quem deseja chamar.';
    statusEl.textContent=readyContacts.length?`${readyContacts.length} conectado(s) para receber o alerta`:'Nenhum selecionado está conectado agora';statusEl.className=`target-status ${readyContacts.length?'available':'unavailable'}`;
    button.disabled=!readyContacts.length||state.activeOutgoingCalls.length>0;button.textContent=state.activeOutgoingCalls.length?'Alertas em andamento':`Chamar ${readyContacts.length} portador(es)`;return;
  }
  const contact=state.contacts.find(c=>c.uid===state.selectedCallContactUid);
  if(!contact){$('#target-eyebrow').textContent='SEM PORTADOR REGISTRADO';nameEl.textContent=`Miraculous ${selected.name}`;detailEl.textContent='Adicione portadores deste Miraculous em Portadores.';statusEl.textContent='Nenhum contato';statusEl.className='target-status unavailable';button.disabled=true;button.textContent='Sem portador';return;}
  const online=p2pPeerForContact(contact)?.channel?.readyState==='open';
  $('#target-eyebrow').textContent=universeLabel(contact).toUpperCase();nameEl.textContent=contact.name;detailEl.textContent=`${selected.name} · ${universeLabel(contact)} · ${contact.code||'sem Miracode'}`;
  statusEl.textContent=online?'Conectado · pronto para chamar':'Salvo, mas sem conexão P2P ativa';statusEl.className=`target-status ${online?'available':'offline'}`;
  button.disabled=!online||state.activeOutgoingCalls.length>0;button.textContent=state.activeOutgoingCalls.length?'Alertas em andamento':`Chamar ${contact.name}`;
}
function renderCallCenter(){
  if($('#wheel-ring').dataset.built!=='true'||$('#wheel-ring').children.length!==miraculous.length)buildWheel();
  let desired=state.selectedCallMiraculousId?miraculous.findIndex(m=>m.id===state.selectedCallMiraculousId):-1;
  if(desired<0||state.selectedCallMiraculousId===state.profile.miraculousId)desired=state.profile.miraculousId===miraculous[0].id?1:0;
  if(!state.selectedCallMiraculousId||state.selectedCallMiraculousId===state.profile.miraculousId){state.selectedCallMiraculousId=miraculous[desired].id;state.callRotation=-desired*WHEEL_STEP;}
  setCallRotation(state.callRotation,false);
  $('#call-mode-note').textContent='Escolha o símbolo e depois o nome do portador. Se houver várias pessoas com o mesmo Miraculous, cada uma aparece com sua etiqueta de universo.';
}

function startWheelDrag(event){if(event.target.closest('button'))return;state.wheelPointer={x:event.clientX,rotation:state.callRotation,moved:0,pointerId:event.pointerId};$('#call-wheel').setPointerCapture?.(event.pointerId);}
function moveWheelDrag(event){if(!state.wheelPointer||state.wheelPointer.pointerId!==event.pointerId)return;const dx=event.clientX-state.wheelPointer.x;state.wheelPointer.moved=Math.max(state.wheelPointer.moved,Math.abs(dx));if(state.wheelPointer.moved>4)setCallRotation(state.wheelPointer.rotation+dx*.72,false);}
function endWheelDrag(event){if(!state.wheelPointer||state.wheelPointer.pointerId!==event.pointerId)return;const moved=state.wheelPointer.moved;state.wheelPointer=null;if(moved>8){state.wheelMoved=true;snapToCallIndex(selectedIndexFromRotation(state.callRotation));setTimeout(()=>state.wheelMoved=false,180);}}

async function refreshBootstrap(){
  state.contacts=readLocalContacts();state.customMiraculous=readLocalCustomMiraculous();
  miraculous.splice(0,miraculous.length,...baseMiraculous,...state.customMiraculous);normalizeContactUniverses(state.contacts);rebuildMiraculousOwners();
  WHEEL_STEP=360/miraculous.length;$('#wheel-ring').dataset.built='';renderAll();
  if(!state.profile.miraculousId)renderSelection();else $('#selection-modal').hidden=true;
}
async function addFriendByCode(rawCode){
  const code=String(rawCode||'').trim();if(code){showToast('O Miracode identifica o portador, mas não localiza pessoas sozinho. Use o convite P2P abaixo para emparelhar os aparelhos.');$('#friend-code').value='';}
}
async function copyFriendCode(){
  try{await navigator.clipboard.writeText(state.profile.friendCode);showToast('Código copiado.');}
  catch{showToast(`Seu código é ${state.profile.friendCode}.`);}
}
async function updateDisplayName(){
  const displayName=$('#display-name').value.trim().slice(0,24)||'Portador';if(displayName.length<2){showToast('Digite um nome com pelo menos 2 caracteres.');return;}
  profileFromUser({...state.user,name:displayName,about:$('#profile-about')?.value.trim().slice(0,120)||''});renderAll();window.dispatchEvent(new Event('mirafriends:profile-updated'));showToast(state.networkUser?'Perfil atualizado na Rede Mirafriends.':'Nome atualizado neste aparelho.');
}

function closeChatPeer(){state.chatPeer=null;}
function blobToDataUrl(blob){
  return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.onerror=()=>reject(new Error('Não foi possível preparar a mídia.'));reader.readAsDataURL(blob);});
}
function attachChatDataChannel(peer,channel){
  if(!peer||!channel)return;peer.channel=channel;channel.binaryType='arraybuffer';channel.bufferedAmountLowThreshold=256*1024;
  channel.onopen=()=>{setP2PConnectionState(peer);renderCallCenter();renderGroupMemberPicker();renderGroups();if(state.chatPeer===peer)showToast(`Conexão direta com ${peer.peerName} estabelecida.`);flushPendingMessages().catch(()=>{});};
  channel.onclose=()=>{peer.channel=null;setP2PConnectionState(peer);renderCallCenter();renderGroupMemberPicker();renderGroups();};channel.onerror=()=>{peer.channel=null;setP2PConnectionState(peer);renderCallCenter();renderGroupMemberPicker();renderGroups();};
  channel.onmessage=async event=>{
    if(typeof event.data!=='string'){
      const transfer=peer.incomingMediaTransfer;if(!transfer)return;
      const chunk=event.data instanceof ArrayBuffer?event.data:await event.data.arrayBuffer();transfer.received+=chunk.byteLength;
      if(transfer.received>2*1024*1024){peer.incomingMediaTransfer=null;showToast('Anexo P2P excedeu o limite de 2 MB.');return;}transfer.chunks.push(chunk);return;
    }
    let packet;try{packet=JSON.parse(event.data);}catch{return;}
    if(state.blockedContacts?.includes(peer.peerUid))return;
    if(packet?.kind==='text'&&packet.message&&packet.message.friendshipId===peer.friendshipId&&packet.message.senderUid===peer.peerUid&&typeof packet.message.text==='string'&&packet.message.text.length<=1000&&/^[A-Za-z0-9_-]{16,64}$/.test(packet.message.id||'')){
      appendMessageOnce(packet.message);sendP2PPacket(peer,{kind:'delivered',id:packet.message.id});return;
    }
    if(packet?.kind==='delivered'&&typeof packet.id==='string'){
      let saved=null;
      for(let attempt=0;attempt<3&&!saved;attempt++){
        const all=await idbStoreAction('messages','readonly',store=>store.getAll()).catch(()=>[]);
        saved=(all||[]).find(m=>m.id===packet.id&&m.senderUid===state.user.uid);
        if(!saved&&attempt<2)await new Promise(resolve=>setTimeout(resolve,120));
      }
      if(saved){saved.delivered=true;await cacheMessage(saved);if(state.activeFriendshipId===saved.friendshipId){const i=state.messages.findIndex(m=>m.id===saved.id);if(i>=0){state.messages[i]={...state.messages[i],delivered:true};renderMessages();}}}return;
    }
    if(packet?.kind==='moment-media-start'){
      const moment=packet.moment;const mimeType=String(packet.mimeType||'');const safe=/^image\/(?:webp|jpeg|png)$|^video\/(?:mp4|webm|quicktime)$/i.test(mimeType);
      if(!moment||moment.authorUid!==peer.peerUid||!moment.id||!safe||!Number.isFinite(packet.size)||packet.size<1||packet.size>2*1024*1024)return;
      peer.incomingMediaTransfer={kind:'moment',message:moment,mimeType,size:packet.size,chunks:[],received:0};return;
    }
    if(packet?.kind==='media-start'){
      const message=packet.message;const mimeType=String(packet.mimeType||'');
      const safeMime=['image','sticker'].includes(message?.type)?/^image\/(?:png|jpeg|webp)$/i.test(mimeType):message?.type==='audio'?/^audio\/(?:webm|ogg|mp4|mpeg|wav|aac|3gpp)(?:;[a-z0-9=._-]+)*$/i.test(mimeType):message?.type==='video'?/^video\/(?:mp4|webm|quicktime)$/i.test(mimeType):message?.type==='file'?/^(?:application\/(?:pdf|zip|vnd\.openxmlformats-officedocument\.[a-z.]+)|text\/plain)$/i.test(mimeType):false;
      if(!message||message.senderUid!==peer.peerUid||message.friendshipId!==peer.friendshipId||!/^[A-Za-z0-9_-]{16,64}$/.test(message.id||'')||!['image','sticker','audio','video','file'].includes(message.type)||!safeMime||!Number.isFinite(packet.size)||packet.size<1||packet.size>2*1024*1024)return;
      peer.incomingMediaTransfer={message,mimeType,size:packet.size,chunks:[],received:0};return;
    }
    if(packet?.kind==='media-end'){
      const transfer=peer.incomingMediaTransfer;peer.incomingMediaTransfer=null;if(!transfer||transfer.message.id!==packet.id||transfer.received!==transfer.size)return;
      try{const blob=new Blob(transfer.chunks,{type:transfer.mimeType});const mediaUrl=await blobToDataUrl(blob);if(transfer.kind==='moment'){await receiveMoment(peer,{moment:{...transfer.message,mediaUrl,mediaType:transfer.mimeType.startsWith('video/')?'video':'image'}});}else{appendMessageOnce({...transfer.message,mediaUrl,mimeType:transfer.mimeType});sendP2PPacket(peer,{kind:'delivered',id:transfer.message.id});}}catch(error){console.warn('Mídia P2P:',error);}return;
    }
    if(packet?.kind==='message-action'){await applyRemoteMessageAction(peer,packet);return;}
    if(packet?.kind==='typing'){if(state.activeFriendshipId===peer.friendshipId){const indicator=$('#chat-typing-indicator');if(indicator){indicator.textContent=`${peer.peerName} está digitando...`;indicator.hidden=!packet.active;clearTimeout(state.mutedTypingTimer);if(packet.active)state.mutedTypingTimer=setTimeout(()=>indicator.hidden=true,2600);}}return;}
    if(packet?.kind==='read'){await receiveReadReceipt(peer,packet);return;}
    if(packet?.kind==='group-invite'){await receiveGroupInvite(peer,packet);return;}
    if(packet?.kind==='group-accept'){await receiveGroupAccept(peer,packet);return;}
    if(packet?.kind==='community-request'){await receiveCommunityRequest(peer,packet);return;}
    if(packet?.kind==='community-decision'){await receiveCommunityDecision(peer,packet);return;}
    if(packet?.kind==='group-update'){await receiveGroupUpdate(peer,packet);return;}
    if(packet?.kind==='group-message'){await receiveGroupMessage(peer,packet);return;}
    if(packet?.kind==='moment-action'){await receiveMomentAction(peer,packet);return;}
    if(packet?.kind==='moment'){await receiveMoment(peer,packet);return;}
    if(packet?.kind==='post'){await receivePost(peer,packet);return;}
    if(packet?.kind==='post-action'){await receivePostAction(peer,packet);return;}
    if(packet?.kind==='call-alert'){
      showIncomingCall({id:packet.callId,senderUid:peer.peerUid,senderName:peer.peerName,senderMiraculousId:peer.miraculousId,peer});return;
    }
    if(packet?.kind==='call-alert-ack'){
      state.activeOutgoingCalls=state.activeOutgoingCalls.filter(c=>c.id!==packet.callId);if(!state.activeOutgoingCalls.length)$('#outgoing-status').hidden=true;else $('#outgoing-title').textContent=`Aguardando ${state.activeOutgoingCalls.length} portador(es)`;updateCallTarget();showToast(`${peer.peerName} confirmou o alerta.`);return;
    }
    if(packet?.kind==='call-alert-cancel'){
      if(state.activeIncomingCall?.id===packet.callId){state.activeIncomingCall=null;stopVibration();showToast('O alerta foi cancelado.');}return;
    }
    if(packet?.kind==='voice-invite'||packet?.kind==='video-invite'){
      showIncomingVoiceCall({callId:packet.callId,fromUid:peer.peerUid,fromName:peer.peerName,friendshipId:peer.friendshipId,offer:packet.offer,peer,mediaMode:packet.kind==='video-invite'?'video':'audio'});return;
    }
    if(packet?.kind==='voice-answer'&&state.voiceCall?.callId===packet.callId&&state.voiceCall.pc){
      try{await state.voiceCall.pc.setRemoteDescription(new RTCSessionDescription(packet.answer));setVoiceStatus('Ligação conectada');}catch(error){showToast(`Falha ao conectar o áudio: ${error.message}`);}return;
    }
    if(packet?.kind==='voice-decline'&&state.voiceCall?.callId===packet.callId){closeVoiceCall(false);showToast('A pessoa recusou a ligação.');return;}
    if(packet?.kind==='voice-end'&&state.voiceCall?.callId===packet.callId){closeVoiceCall(false);showToast('A ligação foi encerrada.');return;}
  };
}
async function sendMediaOverPeer(file,message){
  const channel=state.chatPeer?.channel;
  if(!channel||channel.readyState!=='open')return false;
  if(file.size>2*1024*1024)throw new Error('O anexo precisa ter até 2 MB para envio P2P direto.');
  channel.send(JSON.stringify({kind:'media-start',message:{...message,mediaUrl:undefined},mimeType:file.type||'application/octet-stream',size:file.size}));
  const buffer=await file.arrayBuffer();const chunkSize=16*1024;
  for(let offset=0;offset<buffer.byteLength;offset+=chunkSize){
    if(channel.readyState!=='open')throw new Error('A conexão direta foi interrompida.');
    while(channel.bufferedAmount>512*1024)await new Promise(resolve=>setTimeout(resolve,15));
    channel.send(buffer.slice(offset,Math.min(offset+chunkSize,buffer.byteLength)));
  }
  channel.send(JSON.stringify({kind:'media-end',id:message.id}));return true;
}
async function beginChatPeer(contact){
  closeChatPeer();if(!contact)return;const peer=p2pPeerForContact(contact);state.chatPeer=peer;setP2PConnectionState(peer);
  if(!peer?.channel||peer.channel.readyState!=='open')showToast('Este contato está salvo, mas não há conexão ativa. Refaçam o emparelhamento P2P na área Portadores.');
}
function getLocalDatabase(){
  if(!('indexedDB'in window))return Promise.reject(new Error('IndexedDB indisponível neste navegador.'));
  if(localDbPromise)return localDbPromise;
  localDbPromise=new Promise((resolve,reject)=>{
    const request=indexedDB.open('mirafriends-local-v1',4);
    request.onupgradeneeded=()=>{
      const db=request.result;
      if(!db.objectStoreNames.contains('messages'))db.createObjectStore('messages',{keyPath:'cacheKey'});
      if(!db.objectStoreNames.contains('outbox'))db.createObjectStore('outbox',{keyPath:'id'});
      if(!db.objectStoreNames.contains('groups'))db.createObjectStore('groups',{keyPath:'id'});
      if(!db.objectStoreNames.contains('album'))db.createObjectStore('album',{keyPath:'id'});
      if(!db.objectStoreNames.contains('moments'))db.createObjectStore('moments',{keyPath:'id'});
      if(!db.objectStoreNames.contains('posts'))db.createObjectStore('posts',{keyPath:'id'});
      if(!db.objectStoreNames.contains('stickers'))db.createObjectStore('stickers',{keyPath:'id'});
    };
    request.onsuccess=()=>resolve(request.result);
    request.onerror=()=>reject(request.error||new Error('Não foi possível abrir o armazenamento local.'));
  }).catch(error=>{localDbPromise=null;throw error;});
  return localDbPromise;
}
async function idbStoreAction(storeName,mode,action){
  const db=await getLocalDatabase();
  return new Promise((resolve,reject)=>{
    const tx=db.transaction(storeName,mode);const store=tx.objectStore(storeName);let value;
    try{value=action(store);}catch(error){reject(error);return;}
    tx.oncomplete=()=>resolve(value?.result??value);
    tx.onerror=()=>reject(tx.error||new Error('Falha no armazenamento local.'));
    tx.onabort=()=>reject(tx.error||new Error('Operação local cancelada.'));
  });
}
async function cacheMessage(message){
  if(!message?.id||!message.friendshipId)return;
  try{await idbStoreAction('messages','readwrite',store=>store.put({...message,cacheKey:`${message.friendshipId}:${message.id}`}));}catch(error){console.warn('Cache local de mensagem:',error);}
}
async function cacheMessages(messages){
  const valid=(messages||[]).filter(message=>message?.id&&message.friendshipId);
  if(!valid.length)return;
  try{await idbStoreAction('messages','readwrite',store=>{for(const message of valid)store.put({...message,cacheKey:`${message.friendshipId}:${message.id}`});});}catch(error){console.warn('Cache local de conversa:',error);}
}
async function getCachedMessages(friendshipId){
  try{const all=await idbStoreAction('messages','readonly',store=>store.getAll());return (all||[]).filter(message=>message.friendshipId===friendshipId).sort((a,b)=>Number(a.createdAt)-Number(b.createdAt)).slice(-200);}catch{return [];}
}
async function queuePendingMessage(message){
  try{await idbStoreAction('outbox','readwrite',store=>store.put({...message,pending:true,queuedAt:Date.now()}));return true;}catch(error){console.warn('Fila offline:',error);return false;}
}
async function removePendingMessage(id){try{await idbStoreAction('outbox','readwrite',store=>store.delete(id));}catch(error){console.warn('Remoção da fila offline:',error);}}
async function getPendingMessages(){try{return await idbStoreAction('outbox','readonly',store=>store.getAll())||[];}catch{return [];}}
async function loadFeatureStores(){
  try{state.groups=(await idbStoreAction('groups','readonly',store=>store.getAll()))||[];}catch{state.groups=[];}
  try{state.moments=(await idbStoreAction('moments','readonly',store=>store.getAll()))||[];}catch{state.moments=[];}
  try{state.posts=(await idbStoreAction('posts','readonly',store=>store.getAll()))||[];}catch{state.posts=[];}
  state.moments=state.moments.filter(item=>Number(item.expiresAt||0)>Date.now()).sort((a,b)=>b.createdAt-a.createdAt);
  state.posts=state.posts.filter(item=>item&&item.visibility==='friends').sort((a,b)=>b.createdAt-a.createdAt);
  renderGroups();renderMoments();renderPosts();
}
async function saveGroup(group){
  await idbStoreAction('groups','readwrite',store=>store.put(group));
  const index=state.groups.findIndex(item=>item.id===group.id);if(index>=0)state.groups[index]=group;else state.groups.unshift(group);
  return group;
}
async function saveMoment(moment){
  await idbStoreAction('moments','readwrite',store=>store.put(moment));
  state.moments=[moment,...state.moments.filter(item=>item.id!==moment.id)].filter(item=>item.expiresAt>Date.now()).sort((a,b)=>b.createdAt-a.createdAt);
}
async function savePost(post){
  await idbStoreAction('posts','readwrite',store=>store.put(post));
  state.posts=[post,...state.posts.filter(item=>item.id!==post.id)].sort((a,b)=>b.createdAt-a.createdAt);
}
function renderGroupMemberPicker(){
  const container=$('#group-member-picker');if(!container)return;
  const connected=state.contacts.filter(contact=>{const peer=p2pPeerForContact(contact);return peer?.channel?.readyState==='open';});
  container.innerHTML=connected.length?connected.map(contact=>`<label class="group-member-option"><input type="checkbox" data-group-member="${escapeHTML(contact.uid)}"><span class="group-member-avatar">${sigilImage(contact.miraculousId,'','')}</span><span><strong>${escapeHTML(contact.name)}</strong><small>${escapeHTML(getMiraculous(contact.miraculousId)?.name||'Portador')} · ${escapeHTML(universeLabel(contact))}</small></span></label>`).join(''):'<div class="empty-state">Nenhum portador está conectado agora. Emparelhe e conecte seus amigos primeiro.</div>';
}
function groupMemberLabel(group){return `${(group.members||[]).filter(member=>member.status==='accepted'||member.status==='owner').length} participante(s)`;}
function renderGroups(){
  renderGroupMemberPicker();
  const list=$('#groups-list');if(!list)return;
  const groups=[...(state.groups||[])].sort((a,b)=>(b.updatedAt||b.createdAt||0)-(a.updatedAt||a.createdAt||0));
  list.innerHTML=groups.length?groups.map(group=>{
    const pending=group.status==='invited';const requested=group.status==='requested';
    const members=(group.members||[]).map(member=>member.name).slice(0,4).join(' · ');
    const self=group.members?.find(member=>member.uid===state.user.uid);const isAdmin=group.createdBy===state.user.uid;
    const role=isAdmin?'admin':(self?.role||'member');
    const roleLabel=role==='admin'?'Administrador':role==='moderator'?'Moderador':'Participante';
    const community=group.type==='community';
    const requests=isAdmin&&community?(group.members||[]).filter(member=>member.status==='requested'):[];
    const stateLabel=pending?(community?'Entrada sujeita à aprovação':'Convite recebido'):requested?'Solicitação enviada':group.status==='rejected'?'Solicitação recusada':roleLabel;
    const mainAction=pending?`<button class="secondary-button group-accept-button" type="button" data-accept-group="${escapeHTML(group.id)}">${community?'Solicitar entrada':'Aceitar convite'}</button>`:requested?'<span class="feature-status pending">Aguardando aprovação</span>':group.status==='rejected'?'<span class="feature-status pending">Acesso recusado</span>':`<button class="secondary-button" type="button" data-open-group="${escapeHTML(group.id)}">Abrir</button>`;
    const requestMarkup=requests.map(member=>`<div class="community-request"><span><strong>${escapeHTML(member.name)}</strong><small>Solicitou entrada · ${escapeHTML(getMiraculous(member.miraculousId)?.name||'Portador')}</small></span><button class="secondary-button" type="button" data-community-approve="${escapeHTML(group.id)}" data-community-member="${escapeHTML(member.uid)}">Aprovar</button><button class="secondary-button danger-outline" type="button" data-community-reject="${escapeHTML(group.id)}" data-community-member="${escapeHTML(member.uid)}">Rejeitar</button></div>`).join('');
    return `<article class="feature-list-card group-list-card"><div class="feature-card-symbol">${community?'✦':'♧'}</div><div class="feature-list-copy"><strong>${escapeHTML(group.name)}</strong><small>${community?'Comunidade':'Grupo privado'} · ${escapeHTML(groupMemberLabel(group))} · ${escapeHTML(members||'Equipe Mirafriends')}</small><span class="feature-status ${pending||requested?'pending':'ready'}">${escapeHTML(stateLabel)}${requests.length?` · ${requests.length} pedido(s)`:''}</span></div>${mainAction}${isAdmin?`<button class="secondary-button" type="button" data-manage-group="${escapeHTML(group.id)}">Gerenciar</button><button class="secondary-button" type="button" data-invite-group="${escapeHTML(group.id)}">Convidar P2P</button><button class="secondary-button" type="button" data-group-link="${escapeHTML(group.id)}">Link de convite</button>`:''}${requestMarkup?`<div class="community-request-list">${requestMarkup}</div>`:''}</article>`;
  }).join(''):'<div class="empty-state">Nenhum grupo ou comunidade por enquanto. Crie um e compartilhe convites com seus amigos.</div>';
  const count=$('#groups-count');if(count)count.textContent=String(groups.length);
}
async function createGroup(event){
  event.preventDefault();
  const name=$('#group-name').value.trim().slice(0,36);
  if(name.length<2){showToast('Dê um nome ao grupo.');return;}
  const group={id:`group-${randomLocalId()}`,name,type:$('#group-type')?.value==='community'?'community':'group',createdAt:Date.now(),updatedAt:Date.now(),createdBy:state.user.uid,status:'owner',members:[{uid:state.user.uid,name:state.profile.name,miraculousId:state.profile.miraculousId,status:'owner',role:'admin'}],messages:[]};
  try{await saveGroup(group);$('#group-name').value='';renderGroups();showToast(`“${name}” criado. Agora envie convites aos portadores conectados.`);}
  catch(error){showToast(`Não foi possível criar o grupo: ${error.message}`);}
}
function makeGroupInviteCode(group){
  const payload={kind:'mirafriends-group-invite',version:1,id:group.id,name:group.name,type:group.type||'group',createdBy:group.createdBy,createdAt:group.createdAt,creatorName:state.profile.name,expiresAt:Date.now()+7*86400000};
  return `MIRAFRIENDS-GROUP1.${base64UrlFromBytes(new TextEncoder().encode(JSON.stringify(payload)))}`;
}
async function shareGroupInviteLink(groupId){
  const group=state.groups.find(item=>item.id===groupId);if(!group||group.createdBy!==state.user.uid)return;
  const code=makeGroupInviteCode(group);const url=new URL(location.href);url.search='';url.hash='';url.searchParams.set('groupInvite',code);
  try{if(navigator.share){await navigator.share({title:`Convite para ${group.name} · Mirafriends`,text:`Entre no grupo ${group.name} no Mirafriends. Depois, emparelhe com o administrador para confirmar.`,url:url.toString()});return;}await navigator.clipboard.writeText(url.toString());showToast('Link do grupo copiado. Envie para quem deseja convidar.');}
  catch(error){if(error?.name==='AbortError')return;try{await navigator.clipboard.writeText(url.toString());showToast('Link do grupo copiado.');}catch{const input=$('#group-invite-code');if(input){input.value=code;input.focus();input.select();showToast('Copie o código de convite exibido no campo de entrada.');}}}
}
async function importGroupInviteCode(raw=null){
  const code=String(raw??$('#group-invite-code')?.value??'').trim();if(!code){showToast('Cole o link ou código do grupo.');return;}
  try{
    let token=code;if(/^https?:\/\//i.test(token)){const url=new URL(token);token=url.searchParams.get('groupInvite')||'';}
    if(!token.startsWith('MIRAFRIENDS-GROUP1.')||token.length>12000)throw new Error('Convite inválido. Peça ao administrador um link completo do Mirafriends.');
    const payload=JSON.parse(new TextDecoder().decode(bytesFromBase64Url(token.slice('MIRAFRIENDS-GROUP1.'.length))));
    if(payload.kind!=='mirafriends-group-invite'||payload.version!==1||!/^group-[A-Za-z0-9_-]{8,100}$/.test(String(payload.id||''))||typeof payload.createdBy!=='string'||payload.createdBy.length>100||typeof payload.name!=='string'||payload.name.trim().length<2||payload.name.length>36||!Number.isFinite(payload.createdAt)||!Number.isFinite(payload.expiresAt)||payload.expiresAt<Date.now()||payload.expiresAt>Date.now()+8*86400000)throw new Error('Este convite expirou ou contém dados inválidos. Peça um convite novo.');
    if(payload.createdBy===state.user.uid)throw new Error('Este convite foi criado por este mesmo aparelho.');
    const existing=state.groups.find(item=>item.id===payload.id);
    if(existing){if(existing.createdBy!==payload.createdBy)throw new Error('O código não corresponde ao grupo já salvo neste aparelho.');showToast(`O grupo “${existing.name}” já está na sua lista.`);}
    else{
      const group={id:payload.id,name:payload.name.trim(),type:payload.type==='community'?'community':'group',createdAt:payload.createdAt,updatedAt:Date.now(),createdBy:payload.createdBy,status:'invited',members:[{uid:payload.createdBy,name:String(payload.creatorName||'Administrador').slice(0,36),miraculousId:null,status:'owner',role:'admin'},{uid:state.user.uid,name:state.profile.name,miraculousId:state.profile.miraculousId,status:'invited',role:'member'}],messages:[]};
      await saveGroup(group);renderGroups();showToast(`Convite para “${group.name}” importado. Emparelhe com o administrador para aceitar.`);
    }
    $('#group-invite-code').value='';
  }catch(error){showToast(error.message||'Não foi possível importar o convite.');}
}
async function acceptGroupInvite(groupId){
  const group=state.groups.find(item=>item.id===groupId);if(!group||group.status!=='invited')return;
  const creator=state.contacts.find(contact=>contact.uid===group.createdBy);const peer=p2pPeerForContact(creator);
  if(!peer?.channel||peer.channel.readyState!=='open'){showToast('Para continuar, emparelhe primeiro com o administrador e mantenha a conexão P2P ativa.');return;}
  if(group.type==='community'){
    const own=group.members.find(member=>member.uid===state.user.uid);
    const requestMember={uid:state.user.uid,name:state.profile.name,miraculousId:state.profile.miraculousId,universeIndex:0,status:'requested',role:'member'};
    if(!sendP2PPacket(peer,{kind:'community-request',groupId:group.id,member:requestMember})){showToast('Não foi possível enviar a solicitação. Tente novamente.');return;}
    group.status='requested';if(own)Object.assign(own,requestMember);else group.members.push(requestMember);
    group.updatedAt=Date.now();await saveGroup(group);renderGroups();showToast(`Solicitação enviada para “${group.name}”. Aguarde a aprovação do administrador.`);return;
  }
  if(!sendP2PPacket(peer,{kind:'group-accept',groupId:group.id,member:{uid:state.user.uid,name:state.profile.name,miraculousId:state.profile.miraculousId}})){showToast('Não foi possível enviar o aceite ao administrador. Tente novamente.');return;}
  group.status='member';group.updatedAt=Date.now();const own=group.members.find(member=>member.uid===state.user.uid);if(own)own.status='accepted';
  await saveGroup(group);renderGroups();showToast(`Pedido de entrada enviado para “${group.name}”.`);
}
async function receiveCommunityRequest(peer,packet){
  const group=state.groups.find(item=>item.id===packet.groupId);const raw=packet.member;
  if(!group||group.type!=='community'||group.createdBy!==state.user.uid||!raw||raw.uid!==peer.peerUid||typeof raw.name!=='string'||!state.contacts.some(contact=>contact.uid===peer.peerUid)||state.blockedContacts?.includes(peer.peerUid))return;
  let member=group.members.find(item=>item.uid===peer.peerUid);
  if(!member){if(group.members.length>=32)return;member={uid:peer.peerUid,name:peer.peerName,miraculousId:peer.miraculousId||null,role:'member',status:'requested'};group.members.push(member);}
  member.name=String(raw.name||peer.peerName).slice(0,36);member.miraculousId=raw.miraculousId||peer.miraculousId||null;
  if(member.status!=='accepted'&&member.status!=='owner')member.status='requested';
  group.updatedAt=Date.now();await saveGroup(group);renderGroups();showToast(`${member.name} solicitou entrada em “${group.name}”.`);
}
async function decideCommunityRequest(groupId,memberUid,approve){
  const group=state.groups.find(item=>item.id===groupId);if(!group||group.type!=='community'||group.createdBy!==state.user.uid){showToast('Somente o administrador da comunidade pode decidir os pedidos.');return;}
  const member=group.members.find(item=>item.uid===memberUid&&item.status==='requested');if(!member||!state.contacts.some(item=>item.uid===memberUid)||state.blockedContacts?.includes(memberUid))return;
  const contact=state.contacts.find(item=>item.uid===memberUid);const peer=p2pPeerForContact(contact);
  if(!peer?.channel||peer.channel.readyState!=='open'){showToast('Conecte-se por P2P com este portador para enviar a decisão.');return;}
  const approved=Boolean(approve);
  if(!sendP2PPacket(peer,{kind:'community-decision',groupId:group.id,approved,groupName:group.name,createdBy:state.user.uid})){showToast('Não foi possível enviar a decisão.');return;}
  member.status=approved?'accepted':'rejected';group.updatedAt=Date.now();await saveGroup(group);
  if(approved)await broadcastGroupUpdate(group);
  renderGroups();showToast(approved?`${member.name} foi aprovado(a) na comunidade.`:`Solicitação de ${member.name} recusada.`);
}
async function receiveCommunityDecision(peer,packet){
  const group=state.groups.find(item=>item.id===packet.groupId);if(!group||group.type!=='community'||group.createdBy!==peer.peerUid||!['boolean'].includes(typeof packet.approved))return;
  const own=group.members.find(member=>member.uid===state.user.uid);if(!own)return;
  if(packet.approved){own.status='accepted';group.status='member';}
  else{own.status='rejected';group.status='rejected';}
  group.updatedAt=Date.now();await saveGroup(group);renderGroups();
  showToast(packet.approved?`Sua entrada em “${group.name}” foi aprovada.`:`Sua solicitação para “${group.name}” foi recusada.`);
}
async function inviteGroupMembers(groupId){
  const group=state.groups.find(item=>item.id===groupId);if(!group||group.createdBy!==state.user.uid){showToast('Somente o administrador pode enviar convites.');return;}
  const candidates=state.contacts.filter(contact=>!group.members.some(member=>member.uid===contact.uid)&&p2pPeerForContact(contact)?.channel?.readyState==='open');
  if(!candidates.length){showToast('Não há portadores conectados disponíveis para convidar.');return;}
  const list=candidates.map((contact,index)=>`${index+1}. ${contact.name}`).join('\n');const raw=prompt(`Digite os números separados por vírgula para convidar:\n${list}`,'1');if(raw===null)return;
  const indexes=[...new Set(raw.split(',').map(value=>Number(value.trim())-1).filter(value=>Number.isInteger(value)&&value>=0&&value<candidates.length))];if(!indexes.length){showToast('Nenhum portador válido foi selecionado.');return;}
  const selected=indexes.map(index=>candidates[index]);
  for(const contact of selected){const member={uid:contact.uid,name:contact.name,miraculousId:contact.miraculousId,universeIndex:contact.universeIndex,status:'invited',role:'member'};group.members.push(member);const peer=p2pPeerForContact(contact);sendP2PPacket(peer,{kind:'group-invite',invitedUid:contact.uid,group:{id:group.id,name:group.name,type:group.type||'group',createdAt:group.createdAt,createdBy:group.createdBy,creatorName:state.profile.name,members:group.members}});}
  group.updatedAt=Date.now();await saveGroup(group);await broadcastGroupUpdate(group);renderGroups();showToast(`${selected.length} convite(s) enviado(s) para “${group.name}”.`);
}
function openGroupChat(groupId){
  const group=state.groups.find(item=>item.id===groupId);if(!group||!['owner','member'].includes(group.status))return;
  const own=group.members?.find(member=>member.uid===state.user.uid);if(!own||!['owner','accepted'].includes(own.status))return;
  state.activeGroupId=groupId;$('#group-chat-title').textContent=group.name;$('#group-chat-subtitle').textContent=groupMemberLabel(group);renderGroupKwamiStage(group);
  $('#group-chat-info').textContent='Mensagens enviadas aos participantes com conexão P2P ativa.';
  renderGroupMessages();activatePage('group-chat','groups');
}
function groupKwamiInfo(miraculousId){
  if(!miraculousId)return null;
  const official=KWAMI_BY_MIRACULOUS[miraculousId];
  if(official)return {...official,miraculousId,miraculousName:getMiraculous(miraculousId)?.name||'Miraculous',avatar:`./assets/kwamis/${miraculousId}.png`};
  const m=getMiraculous(miraculousId);if(!m?.kwami?.name)return null;
  return {name:m.kwami.name,personality:m.kwami.personality||'curioso e prestativo',greeting:m.kwami.greeting||'Olá! Vamos conversar.',miraculousId,miraculousName:m.name,avatar:'./assets/logo.svg'};
}
function groupKwamiParticipants(group){
  const members=(group.members||[]).filter(member=>['owner','accepted'].includes(member.status));
  if(!members.some(member=>member.uid===state.user.uid))members.unshift({uid:state.user.uid,name:state.profile.name,miraculousId:state.profile.miraculousId,status:'owner'});
  return members.map(member=>({...member,kwami:groupKwamiInfo(member.miraculousId)})).filter(member=>member.kwami);
}
function renderGroupKwamiStage(group){
  const stage=$('#group-kwami-stage');if(!stage)return;
  const participants=groupKwamiParticipants(group);stage.hidden=participants.length<2;
  const roster=$('#group-kwami-roster');if(roster)roster.innerHTML=participants.map(item=>`<div class="group-kwami-person"><img src="${escapeHTML(item.kwami.avatar)}" alt="${escapeHTML(item.kwami.name)}"><span><strong>${escapeHTML(item.kwami.name)}</strong><small>${escapeHTML(item.name||'Portador')}</small></span></div>`).join('');
  const dialogue=$('#group-kwami-dialogue');if(dialogue){dialogue.hidden=true;dialogue.innerHTML='';}
  const talk=$('#group-kwami-talk');if(talk)talk.disabled=participants.length<2;
}
function kwamiConversationLine(kwami,role){
  const personality=String(kwami.personality||'').toLowerCase();
  if(/sarc[aá]stic|irrever|travess|brincalh/.test(personality))return role===0?'Espero que o plano seja interessante. E que tenha algum lanche.':'Vamos lá, isso pode ficar divertido!';
  if(/calm|s[aá]bio|seren|paciente|ponderad/.test(personality))return role===0?'Vamos ouvir todos com calma antes de decidir.':'Concordo. Cada ideia merece um momento para ser entendida.';
  if(/criativ|imagin|artístic|curios/.test(personality))return role===0?'E se juntarmos nossas ideias para criar uma solução diferente?':'Adorei! Uma boa ideia pode inspirar outra ainda melhor.';
  if(/protet|leal|atencios|gentil|acolhedor/.test(personality))return role===0?'O mais importante é que todos se sintam bem-vindos.':'Estamos juntos. Podemos ajudar o portador como uma equipe.';
  if(/determin|diret|objetiv|disciplin/.test(personality))return role===0?'Vamos organizar as tarefas e escolher o próximo passo.':'Perfeito. Um plano claro ajuda a equipe a avançar.';
  return role===0?'Olá! Que bom encontrar outros Kwamis por aqui.':'Olá! Podemos combinar nossas ideias e ajudar nossos portadores.';
}
function startGroupKwamiConversation(){
  const group=state.groups.find(item=>item.id===state.activeGroupId);const participants=group?groupKwamiParticipants(group):[];
  if(participants.length<2){showToast('São necessários pelo menos dois Kwamis associados aos portadores aceitos no grupo.');return;}
  const active=participants.slice(0,8);const dialogue=$('#group-kwami-dialogue');if(!dialogue)return;
  const lines=active.map((person,index)=>({person,text:kwamiConversationLine(person.kwami,index%2)}));
  lines.push({person:active[0],text:`${active[0].kwami.name}: Cada Miraculous tem seu jeito de contribuir. Vamos trabalhar em equipe!`});
  dialogue.innerHTML=lines.map((line,index)=>`<div class="group-kwami-line ${index%2?'reply':''}"><img src="${escapeHTML(line.person.kwami.avatar)}" alt=""><span><strong>${escapeHTML(line.person.kwami.name)}</strong><p>${escapeHTML(line.text.replace(/^.*?:\s*/,''))}</p></span></div>`).join('');dialogue.hidden=false;
}

function renderGroupMessages(){
  const group=state.groups.find(item=>item.id===state.activeGroupId);const box=$('#group-chat-messages');if(!box)return;
  if(!group){box.innerHTML='<div class="empty-state">Este grupo não está disponível neste aparelho.</div>';return;}
  box.innerHTML=(group.messages||[]).map(message=>`<div class="group-message ${message.senderUid===state.user.uid?'mine':''}"><strong>${escapeHTML(message.senderName||'Portador')}</strong><p>${escapeHTML(message.text)}</p><time>${new Date(message.createdAt).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})}</time></div>`).join('')||'<div class="chat-empty">O grupo foi criado. Envie a primeira mensagem!</div>';
  box.scrollTop=box.scrollHeight;
}
async function sendGroupMessage(event){
  event.preventDefault();const input=$('#group-message-input');const text=input.value.trim();if(!text)return;
  const group=state.groups.find(item=>item.id===state.activeGroupId);if(!group||!['owner','member'].includes(group.status))return;
  const own=group.members?.find(member=>member.uid===state.user.uid);if(!own||!['owner','accepted'].includes(own.status))return;
  const message={id:newMessageId(),groupId:group.id,senderUid:state.user.uid,senderName:state.profile.name,text:text.slice(0,1000),createdAt:Date.now()};
  group.messages=[...(group.messages||[]),message].slice(-250);group.updatedAt=Date.now();await saveGroup(group);renderGroupMessages();input.value='';
  let sent=0;for(const member of group.members||[]){if(member.uid===state.user.uid||!['accepted','owner'].includes(member.status))continue;const contact=state.contacts.find(item=>item.uid===member.uid);const peer=p2pPeerForContact(contact);if(peer?.channel?.readyState==='open'&&sendP2PPacket(peer,{kind:'group-message',message})){sent++;}}
  showToast(sent?`Mensagem enviada a ${sent} participante(s) conectado(s).`:'Mensagem salva no grupo, mas nenhum participante está conectado agora.');
}
async function receiveGroupInvite(peer,packet){
  const raw=packet.group;if(!raw||typeof raw.id!=='string'||!/^group-[A-Za-z0-9_-]{8,100}$/.test(raw.id)||typeof raw.name!=='string'||raw.name.length>36||raw.createdBy!==peer.peerUid||packet.invitedUid!==state.user.uid||!Array.isArray(raw.members)||raw.members.length>31)return;
  const members=raw.members.filter(member=>member&&typeof member.uid==='string').map(member=>({uid:member.uid,name:String(member.name||'Portador').slice(0,36),miraculousId:member.miraculousId||null,universeIndex:Number.isInteger(member.universeIndex)?member.universeIndex:0,status:member.uid===state.user.uid?'invited':member.uid===raw.createdBy?'owner':(['accepted','owner','invited'].includes(member.status)?member.status:'invited'),role:member.uid===raw.createdBy?'admin':(['moderator','member'].includes(member.role)?member.role:'member')}));
  if(!members.some(member=>member.uid===state.user.uid)||!members.some(member=>member.uid===peer.peerUid))return;
  const group={id:raw.id,name:raw.name,type:raw.type==='community'?'community':'group',createdAt:Number(raw.createdAt)||Date.now(),updatedAt:Date.now(),createdBy:raw.createdBy,status:'invited',members,messages:[]};
  await saveGroup(group);renderGroups();showToast(`Convite para o grupo “${group.name}” recebido.`);
}
async function receiveGroupAccept(peer,packet){
  const group=state.groups.find(item=>item.id===packet.groupId);if(!group||group.createdBy!==state.user.uid)return;
  const member=group.members.find(item=>item.uid===peer.peerUid);if(!member)return;
  member.status='accepted';group.updatedAt=Date.now();await saveGroup(group);await broadcastGroupUpdate(group);renderGroups();showToast(`${peer.peerName} entrou no grupo “${group.name}”.`);
}
async function broadcastGroupUpdate(group){
  const packet={kind:'group-update',groupId:group.id,members:group.members};
  for(const member of group.members||[]){if(member.uid===state.user.uid)continue;const contact=state.contacts.find(item=>item.uid===member.uid);const peer=p2pPeerForContact(contact);if(peer?.channel?.readyState==='open')sendP2PPacket(peer,packet);}
}
async function receiveGroupUpdate(peer,packet){
  const group=state.groups.find(item=>item.id===packet.groupId);if(!group||peer.peerUid!==group.createdBy||!Array.isArray(packet.members)||packet.members.length>32)return;
  group.members=packet.members.filter(member=>member&&typeof member.uid==='string').map(member=>({uid:member.uid,name:String(member.name||'Portador').slice(0,36),miraculousId:member.miraculousId||null,universeIndex:Number.isInteger(member.universeIndex)?member.universeIndex:0,status:['owner','accepted','invited'].includes(member.status)?member.status:'invited',role:member.uid===group.createdBy?'admin':(['moderator','member'].includes(member.role)?member.role:'member')}));
  group.updatedAt=Date.now();await saveGroup(group);renderGroups();if(state.activeGroupId===group.id)$('#group-chat-subtitle').textContent=groupMemberLabel(group);
}
function manageGroupRoles(groupId){
  const group=state.groups.find(item=>item.id===groupId);if(!group||group.createdBy!==state.user.uid){showToast('Somente o administrador pode gerenciar cargos.');return;}
  const candidates=group.members.filter(member=>member.uid!==state.user.uid&&member.status==='accepted');if(!candidates.length){showToast('Ainda não há participantes que aceitaram o convite.');return;}
  const choices=candidates.map((member,index)=>`${index+1}. ${member.name} — ${member.role==='moderator'?'moderador':'participante'}`).join('\n');const selected=Number(prompt(`Escolha o participante para alterar o cargo:\n${choices}`,'1'))-1;if(!Number.isInteger(selected)||selected<0||selected>=candidates.length)return;
  const member=candidates[selected];const next=member.role==='moderator'?'member':'moderator';if(!confirm(`${next==='moderator'?'Promover':'Retirar o cargo de moderador de'} ${member.name}?`))return;member.role=next;group.updatedAt=Date.now();saveGroup(group).then(()=>broadcastGroupUpdate(group)).then(()=>{renderGroups();showToast(`${member.name}: ${next==='moderator'?'moderador':'participante'}.`);}).catch(error=>showToast(`Não foi possível atualizar os cargos: ${error.message}`));
}
async function receiveGroupMessage(peer,packet){
  const message=packet.message;
  if(!message||typeof message.groupId!=='string'||typeof message.senderUid!=='string'||typeof message.text!=='string'||message.text.length>1000||!message.id)return;
  const group=state.groups.find(item=>item.id===message.groupId);
  if(!group||!['owner','member'].includes(group.status))return;
  const own=group.members?.find(member=>member.uid===state.user.uid);if(!own||!['owner','accepted'].includes(own.status))return;
  const sender=group.members?.find(member=>member.uid===message.senderUid);
  const senderIsMember=Boolean(sender&&['owner','accepted'].includes(sender.status));
  const directFromAuthor=message.senderUid===peer.peerUid;
  // Em grupos P2P sem servidor, quem criou o grupo pode retransmitir a mensagem
  // para os outros membros que só possuem conexão direta com o criador.
  const relayedByOwner=message.relayedBy===peer.peerUid&&peer.peerUid===group.createdBy;
  if(!senderIsMember||(!directFromAuthor&&!relayedByOwner))return;
  if((group.messages||[]).some(item=>item.id===message.id))return;
  const savedMessage={...message,senderName:String(message.senderName||peer.peerName).slice(0,36)};
  group.messages=[...(group.messages||[]),savedMessage].slice(-250);group.updatedAt=Date.now();await saveGroup(group);
  // Somente o criador retransmite mensagens originadas por outros participantes.
  // Os destinatários deduplicam pelo ID, então uma malha direta eventual não duplica o balão.
  if(group.createdBy===state.user.uid&&directFromAuthor&&message.senderUid!==state.user.uid){
    const relayMessage={...savedMessage,relayedBy:state.user.uid};
    for(const member of group.members||[]){
      if(member.uid===state.user.uid||member.uid===peer.peerUid||!['accepted','owner'].includes(member.status))continue;
      const contact=state.contacts.find(item=>item.uid===member.uid);const target=p2pPeerForContact(contact);
      if(target?.channel?.readyState==='open')sendP2PPacket(target,{kind:'group-message',message:relayMessage});
    }
  }
  if(state.activeGroupId===group.id)renderGroupMessages();else showToast(`Nova mensagem no grupo ${group.name}.`);renderGroups();
}
function renderMoments(){
  const list=$('#moments-list');if(!list)return;
  state.moments=(state.moments||[]).filter(item=>item.expiresAt>Date.now()).sort((a,b)=>b.createdAt-a.createdAt);
  list.innerHTML=state.moments.length?state.moments.map(moment=>{
    const media=moment.mediaUrl?.startsWith('data:image/')?`<img class="moment-media" src="${escapeHTML(moment.mediaUrl)}" alt="Mídia do momento">`:moment.mediaUrl?.startsWith('data:video/')?`<video class="moment-media" src="${escapeHTML(moment.mediaUrl)}" controls playsinline preload="metadata"></video>`:'';
    const reactions=Object.entries(moment.reactions||{}).map(([emoji,uids])=>`<span class="message-reaction">${escapeHTML(emoji)} ${Array.isArray(uids)?uids.length:0}</span>`).join('');
    const comments=(moment.comments||[]).slice(-4).map(comment=>`<p class="moment-comment"><strong>${escapeHTML(comment.name||'Portador')}:</strong> ${escapeHTML(comment.text)}</p>`).join('');
    return `<article class="moment-card"><div class="moment-avatar">${sigilImage(moment.miraculousId,'','')}</div><div class="moment-content"><strong>${escapeHTML(moment.authorName||'Portador')}</strong><small>${new Date(moment.createdAt).toLocaleString('pt-BR')}</small>${moment.text?`<p>${escapeHTML(moment.text)}</p>`:''}${media}<div class="message-reactions">${reactions}</div><div class="moment-social-actions"><button type="button" data-moment-react="${escapeHTML(moment.id)}">❤️ Reagir</button><button type="button" data-moment-comment="${escapeHTML(moment.id)}">Comentar</button><small>${(moment.comments||[]).length} comentário(s) · expira em 24h</small></div>${comments}</div></article>`;
  }).join(''):'<div class="empty-state">Ainda não há momentos nas últimas 24 horas.</div>';
}
async function publishMoment(event){
  event.preventDefault();const input=$('#moment-text');const text=input.value.trim();const file=$('#moment-media-input')?.files?.[0];if(!text&&!file)return;
  let mediaUrl=null,mediaType=null,mediaBlob=null;
  try{
    if(file){
      if(file.type.startsWith('image/')){mediaBlob=await compressImageFile(file);if(mediaBlob.size>900*1024)throw new Error('A imagem do momento ficou grande demais.');mediaUrl=await blobToDataUrl(mediaBlob);mediaType='image';}
      else if(/^video\/(mp4|webm|quicktime)$/i.test(file.type)){if(file.size>700*1024)throw new Error('Nesta beta, vídeos de Momentos precisam ter até 700 KB para envio P2P.');mediaBlob=file;mediaUrl=await blobToDataUrl(file);mediaType='video';}
      else throw new Error('Escolha uma imagem ou um vídeo MP4, WebM ou MOV.');
    }
    const moment={id:newMessageId(),authorUid:state.user.uid,authorName:state.profile.name,miraculousId:state.profile.miraculousId,text:text.slice(0,280),mediaUrl,mediaType,visibility:'friends',reactions:{},comments:[],createdAt:Date.now(),expiresAt:Date.now()+86400000};
    await saveMoment(moment);let sent=0;for(const contact of state.contacts){if(state.blockedContacts?.includes(contact.uid))continue;const peer=p2pPeerForContact(contact);if(peer?.channel?.readyState==='open'&&await sendMomentToPeer(peer,moment,mediaBlob)){sent++;}}
    input.value='';if($('#moment-media-input'))$('#moment-media-input').value='';renderMoments();showToast(sent?`Momento publicado e enviado a ${sent} contato(s).`:'Momento salvo neste aparelho. Nenhum contato P2P está conectado agora.');
  }catch(error){showToast(`Não foi possível publicar o momento: ${error.message}`);}
}
async function receiveMoment(peer,packet){
  const raw=packet.moment;  if(!raw||raw.authorUid!==peer.peerUid||raw.visibility==='public'||typeof raw.text!=='string'||raw.text.length>280||!raw.id||!Number.isFinite(raw.createdAt)||!state.contacts.some(contact=>contact.uid===peer.peerUid)||state.blockedContacts?.includes(peer.peerUid))return;
  if(raw.expiresAt<Date.now()||raw.expiresAt>Date.now()+86400000+60000)return;
  if(raw.mediaUrl&&(!/^data:(image\/(?:webp|jpeg|png)|video\/(?:mp4|webm|quicktime));base64,/i.test(raw.mediaUrl)||raw.mediaUrl.length>2900000))return;
  if(state.moments.some(item=>item.id===raw.id))return;
  const moment={id:raw.id,authorUid:peer.peerUid,authorName:String(raw.authorName||peer.peerName).slice(0,36),miraculousId:raw.miraculousId||peer.miraculousId,text:raw.text,mediaUrl:raw.mediaUrl||null,mediaType:raw.mediaType==='video'?'video':raw.mediaType==='image'?'image':null,visibility:'friends',reactions:{},comments:[],createdAt:raw.createdAt,expiresAt:raw.expiresAt};
  await saveMoment(moment);renderMoments();showToast(`Novo momento de ${moment.authorName}.`);
}
async function sendMomentToPeer(peer,moment,blob=null){
  const channel=peer?.channel;if(!channel||channel.readyState!=='open')return false;
  const metadata={...moment,mediaUrl:undefined};
  if(!blob)return sendP2PPacket(peer,{kind:'moment',moment:metadata});
  if(blob.size>2*1024*1024)throw new Error('A mídia do momento excede 2 MB.');
  if(!sendP2PPacket(peer,{kind:'moment-media-start',moment:metadata,mimeType:blob.type,size:blob.size}))return false;
  const buffer=await blob.arrayBuffer();const chunkSize=16*1024;
  for(let offset=0;offset<buffer.byteLength;offset+=chunkSize){
    if(channel.readyState!=='open')return false;
    while(channel.bufferedAmount>512*1024)await new Promise(resolve=>setTimeout(resolve,20));
    channel.send(buffer.slice(offset,Math.min(offset+chunkSize,buffer.byteLength)));
  }
  return sendP2PPacket(peer,{kind:'media-end',id:moment.id});
}
function sendMomentAction(moment,action,data={}){
  const packet={kind:'moment-action',momentId:moment.id,action,...data};
  for(const contact of state.contacts){if(state.blockedContacts?.includes(contact.uid))continue;const peer=p2pPeerForContact(contact);if(peer?.channel?.readyState==='open')sendP2PPacket(peer,packet);}
}
async function receiveMomentAction(peer,packet){
  const moment=state.moments.find(item=>item.id===packet.momentId);if(!moment||!state.contacts.some(contact=>contact.uid===peer.peerUid)||state.blockedContacts?.includes(peer.peerUid)||!['react','comment'].includes(packet.action))return;
  if(packet.action==='react'&&['❤️','👍','✨','😂'].includes(packet.emoji)){moment.reactions=moment.reactions||{};const users=Array.isArray(moment.reactions[packet.emoji])?moment.reactions[packet.emoji]:[];moment.reactions[packet.emoji]=packet.remove?users.filter(uid=>uid!==peer.peerUid):(users.includes(peer.peerUid)?users:users.concat(peer.peerUid).slice(0,100));}
  if(packet.action==='comment'&&typeof packet.text==='string'&&packet.text.trim()&&packet.text.length<=240){moment.comments=moment.comments||[];if(!moment.comments.some(comment=>comment.id===packet.commentId))moment.comments.push({id:String(packet.commentId||newMessageId()).slice(0,64),uid:peer.peerUid,name:peer.peerName,text:packet.text.trim(),createdAt:Date.now()});moment.comments=moment.comments.slice(-50);}
  await saveMoment(moment);renderMoments();
}
function handleMomentAction(element){
  const moment=state.moments.find(item=>item.id===(element.dataset.momentReact||element.dataset.momentComment));if(!moment)return;
  if(element.dataset.momentReact){moment.reactions=moment.reactions||{};const emoji='❤️';const users=Array.isArray(moment.reactions[emoji])?moment.reactions[emoji]:[];const exists=users.includes(state.user.uid);moment.reactions[emoji]=exists?users.filter(uid=>uid!==state.user.uid):users.concat(state.user.uid);sendMomentAction(moment,'react',{emoji,remove:exists});saveMoment(moment).then(renderMoments);return;}
  const text=prompt('Escreva um comentário (até 240 caracteres):','');if(text===null||!text.trim())return;const comment={id:newMessageId(),uid:state.user.uid,name:state.profile.name,text:text.trim().slice(0,240),createdAt:Date.now()};moment.comments=[...(moment.comments||[]),comment].slice(-50);sendMomentAction(moment,'comment',{commentId:comment.id,text:comment.text});saveMoment(moment).then(renderMoments);
}

// Rede online Node.js: autenticação por cookie HttpOnly, amizades por Miracode e feed hospedado.
async function networkApi(path, options={}){
  const headers={...(options.headers||{})};
  if(options.json!==undefined){headers['Content-Type']='application/json';options.body=JSON.stringify(options.json);delete options.json;}
  const response=await fetch(`/api${path}`,{credentials:'same-origin',...options,headers});
  if(response.status===204)return null;
  const payload=await response.json().catch(()=>({error:'Resposta inválida do servidor.'}));
  if(!response.ok)throw new Error(payload.error||`Erro ${response.status}`);
  return payload;
}
function setNetworkStatus(text,connected=false){
  const pill=$('#network-status');if(pill){pill.textContent=text;pill.classList.toggle('online',connected);}
}
function renderNetworkAccount(){
  const authenticated=Boolean(state.networkUser);
  const forms=$('#network-auth-forms'),account=$('#network-account-state');
  if(forms)forms.hidden=authenticated;if(account)account.hidden=!authenticated;
  const codeSearch=$('#network-add-form'),networkLists=$('.network-lists-grid');
  if(codeSearch)codeSearch.hidden=!authenticated;if(networkLists)networkLists.hidden=!authenticated;
  if(authenticated){
    $('#network-account-name').textContent=state.networkUser.name||'Portador';
    $('#network-account-code').textContent=state.networkUser.miracode||'';
    $('#network-visibility-setting').value=state.networkUser.visibility||'private';
    setNetworkStatus('CONECTADO',true);
    const regName=$('#network-register-name');if(regName)regName.value=state.profile.name||'';
  }else setNetworkStatus('DESCONECTADO',false);
  const postVisibility=$('#post-visibility');if(postVisibility){
    const publicAllowed=authenticated&&state.networkUser.visibility==='public';
    const publicOption=postVisibility.querySelector('option[value="public"]');if(publicOption)publicOption.disabled=!publicAllowed;
    postVisibility.value=publicAllowed?'public':'friends';
    const publishButton=$('#post-form button[type=submit]');if(publishButton)publishButton.textContent=postVisibility.value==='public'?'Publicar publicamente':'Publicar para meus amigos';
  }
}
function applyNetworkUser(user){
  state.networkUser=user;
  if(user){
    profileFromUser({...state.user,uid:user.id,friendCode:user.miracode,name:user.name,about:user.about||'',miraculousId:user.miraculousId||state.profile.miraculousId,avatarData:state.profile.avatarData||null});
    $('#network-register-name').value=user.name||'';
  }
  renderNetworkAccount();renderProfile();renderAll();
}
function renderNetworkLists(){
  const incoming=state.networkIncomingRequests||[];const outgoing=state.networkOutgoingRequests||[];const requests=$('#network-requests-list');
  if(requests){
    const incomingHtml=incoming.map(item=>`<article class="network-person-row"><div class="network-person-avatar">✧</div><div class="network-person-copy"><strong>${escapeHTML(item.user.name)}</strong><small>${escapeHTML(item.user.miracode)} · conta ${item.user.visibility==='public'?'pública':'privada'}</small></div><div class="network-person-actions"><button type="button" class="primary-button" data-network-accept="${escapeHTML(item.id)}">Aceitar</button><button type="button" class="text-button" data-network-decline="${escapeHTML(item.id)}">Recusar</button></div></article>`).join('');
    const outgoingHtml=outgoing.map(item=>`<article class="network-person-row"><div class="network-person-avatar">…</div><div class="network-person-copy"><strong>${escapeHTML(item.user.name)}</strong><small>${escapeHTML(item.user.miracode)} · aguardando aprovação</small></div><span class="network-pending-pill">PENDENTE</span></article>`).join('');
    requests.innerHTML=(incomingHtml+outgoingHtml)||'<div class="empty-state compact-empty">Nenhuma solicitação pendente.</div>';
  }
  const friends=$('#network-friends-list');
  if(friends){friends.innerHTML=(state.networkFriends||[]).map(person=>`<article class="network-person-row"><div class="network-person-avatar">${sigilImage(person.miraculousId,'network-person-sigil','')}</div><div class="network-person-copy"><strong>${escapeHTML(person.name)}</strong><small>${escapeHTML(person.miracode)} · ${person.visibility==='public'?'pública':'privada'}</small></div><button type="button" class="text-button" data-network-remove="${escapeHTML(person.id)}">Remover</button></article>`).join('')||'<div class="empty-state compact-empty">Você ainda não adicionou amigos pelo Miracode.</div>';}
  const requestCount=$('#network-requests-count');if(requestCount)requestCount.textContent=String(incoming.length+outgoing.length);
  const friendCount=$('#network-friends-count');if(friendCount)friendCount.textContent=String((state.networkFriends||[]).length);
}
async function refreshNetworkSocial({silent=false}={}){
  if(!state.networkUser)return;
  try{
    const [friends,requests,feed]=await Promise.all([networkApi('/friendships'),networkApi('/friend-requests'),networkApi('/feed')]);
    state.networkFriends=friends.friends||[];state.networkIncomingRequests=requests.incoming||[];state.networkOutgoingRequests=requests.outgoing||[];
    state.serverPosts=(feed.posts||[]).map(post=>({...post,source:'server',authorName:post.author?.name||'Portador',miraculousId:post.author?.miraculousId||null}));
    renderNetworkLists();renderPosts();
  }catch(error){if(!silent)showToast(`Rede online: ${error.message}`);setNetworkStatus('SEM SINCRONIA',false);}
}
async function initializeNetworkSocial(){
  try{
    const data=await networkApi('/me');applyNetworkUser(data.user);await refreshNetworkSocial({silent:true});
  }catch(error){
    if(error.message.includes('Entre na sua conta')){state.networkUser=null;renderNetworkAccount();renderNetworkLists();}
    else {renderNetworkAccount();setNetworkStatus('SERVIDOR INDISPONÍVEL',false);}
  }
  const registerForm=$('#network-register-form');if($('#network-register-name'))$('#network-register-name').value=state.profile.name||'';registerForm?.addEventListener('submit',async event=>{
    event.preventDefault();const button=registerForm.querySelector('button[type="submit"]');button.disabled=true;
    try{
      const data=await networkApi('/auth/register',{method:'POST',json:{name:$('#network-register-name').value,password:$('#network-register-password').value,visibility:$('#network-register-visibility').value,miraculousId:state.profile.miraculousId,about:state.profile.about||''}});
      applyNetworkUser(data.user);$('#network-register-password').value='';await refreshNetworkSocial();showToast(`Conta criada! Seu Miracode é ${data.user.miracode}.`);
    }catch(error){showToast(error.message);}finally{button.disabled=false;}
  });
  const loginForm=$('#network-login-form');loginForm?.addEventListener('submit',async event=>{
    event.preventDefault();const button=loginForm.querySelector('button[type="submit"]');button.disabled=true;
    try{const data=await networkApi('/auth/login',{method:'POST',json:{miracode:$('#network-login-code').value,password:$('#network-login-password').value}});applyNetworkUser(data.user);$('#network-login-password').value='';await refreshNetworkSocial();showToast('Você entrou na Rede Mirafriends.');}
    catch(error){showToast(error.message);}finally{button.disabled=false;}
  });
  $('#network-logout')?.addEventListener('click',async()=>{try{await networkApi('/auth/logout',{method:'POST'});}catch{}state.networkUser=null;state.serverPosts=[];state.networkFriends=[];state.networkIncomingRequests=[];state.networkOutgoingRequests=[];renderNetworkAccount();renderNetworkLists();renderPosts();showToast('Você saiu da conta online.');});
  $('#network-copy-code')?.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(state.networkUser?.miracode||'');showToast('Miracode copiado.');}catch{showToast('Não foi possível copiar. Selecione o Miracode na tela.');}});
  $('#network-save-settings')?.addEventListener('click',async()=>{
    try{const data=await networkApi('/me',{method:'PATCH',json:{visibility:$('#network-visibility-setting').value,name:state.profile.name,about:state.profile.about||'',miraculousId:state.profile.miraculousId}});applyNetworkUser(data.user);await refreshNetworkSocial();showToast('Privacidade da conta atualizada.');}
    catch(error){showToast(error.message);}
  });
  $('#network-add-form')?.addEventListener('submit',async event=>{
    event.preventDefault();if(!state.networkUser){showToast('Entre ou crie uma conta online antes de adicionar por Miracode.');return;}
    const code=$('#network-add-code').value.trim().toUpperCase();const result=$('#network-lookup-result');result.hidden=false;result.textContent='Consultando Miracode…';
    try{
      const lookup=await networkApi(`/users/by-code/${encodeURIComponent(code)}`);const person=lookup.user;
      if(lookup.relation==='self'){result.textContent='Este é o seu próprio Miracode.';return;}
      let actionText='';
      if(lookup.relation==='accepted')actionText='Já está na sua lista';
      else if(lookup.relation==='pending')actionText=lookup.requestedBy===state.networkUser.id?'Solicitação já enviada':'Esta pessoa enviou uma solicitação para você; aceite na área Solicitações';
      else{
        const added=await networkApi(`/friendships/by-code/${encodeURIComponent(person.miracode)}`,{method:'POST',json:{}});
        actionText=added.status==='accepted'?'Amizade adicionada': 'Solicitação enviada · aguardando aprovação';
        showToast(added.message);
        await refreshNetworkSocial({silent:true});
      }
      result.innerHTML=`<div class="network-lookup-person"><div class="network-person-avatar">${sigilImage(person.miraculousId,'network-person-sigil','')}</div><div class="network-person-copy"><strong>${escapeHTML(person.name)}</strong><small>${escapeHTML(person.miracode)} · conta ${person.visibility==='public'?'pública':'privada'}</small></div><strong class="network-lookup-action">${escapeHTML(actionText)}</strong></div>`;
      $('#network-add-code').value='';
    }catch(error){result.textContent=error.message;}
  });
  document.addEventListener('click',async event=>{
    const accept=event.target.closest('[data-network-accept]');const decline=event.target.closest('[data-network-decline]');const remove=event.target.closest('[data-network-remove]');
    try{
      if(accept){await networkApi(`/friend-requests/${encodeURIComponent(accept.dataset.networkAccept)}/accept`,{method:'POST',json:{}});showToast('Solicitação aceita.');await refreshNetworkSocial();}
      if(decline){await networkApi(`/friend-requests/${encodeURIComponent(decline.dataset.networkDecline)}/decline`,{method:'POST',json:{}});showToast('Solicitação recusada.');await refreshNetworkSocial();}
      if(remove&&confirm('Remover este amigo da sua lista?')){await networkApi(`/friendships/${encodeURIComponent(remove.dataset.networkRemove)}`,{method:'DELETE'});await refreshNetworkSocial();showToast('Amigo removido.');}
    }catch(error){showToast(error.message);}
  });
  window.addEventListener('mirafriends:profile-updated',async()=>{
    if(!state.networkUser)return;
    try{const data=await networkApi('/me',{method:'PATCH',json:{name:state.profile.name,about:state.profile.about||'',miraculousId:state.profile.miraculousId}});applyNetworkUser(data.user);}
    catch(error){showToast(`Não foi possível sincronizar o perfil: ${error.message}`);}
  });
  if(state.networkUser){refreshNetworkSocial({silent:true});}
  setInterval(()=>{if(state.networkUser&&document.visibilityState==='visible')refreshNetworkSocial({silent:true});},30000);
}
function serverPostMedia(post){
  const mediaUrl=String(post.mediaUrl||'');
  if(!mediaUrl)return '';
  if(/^\/uploads\/[a-f0-9-]+\.(?:jpg|png|webp|mp4|mov|webm)$/i.test(mediaUrl)){
    return post.mediaType==='video'?`<video class="moment-media" src="${escapeHTML(mediaUrl)}" controls playsinline preload="metadata"></video>`:`<img class="moment-media" src="${escapeHTML(mediaUrl)}" alt="Mídia da publicação" loading="lazy">`;
  }
  if(mediaUrl.startsWith('data:image/'))return `<img class="moment-media" src="${escapeHTML(mediaUrl)}" alt="Mídia da publicação">`;
  if(mediaUrl.startsWith('data:video/'))return `<video class="moment-media" src="${escapeHTML(mediaUrl)}" controls playsinline preload="metadata"></video>`;
  return '';
}

function renderPosts(){
  const list=$('#posts-list');if(!list)return;
  const localPosts=(state.posts||[]).filter(post=>post&&post.visibility==='friends');
  const onlinePosts=(state.serverPosts||[]).filter(post=>post&&post.source==='server');
  const posts=[...onlinePosts,...localPosts].sort((a,b)=>Number(b.createdAt)-Number(a.createdAt));
  list.innerHTML=posts.length?posts.map(post=>{
    const server=post.source==='server';
    const media=server?serverPostMedia(post):(post.mediaUrl?.startsWith('data:image/')?`<img class="moment-media" src="${escapeHTML(post.mediaUrl)}" alt="Mídia da publicação">`:post.mediaUrl?.startsWith('data:video/')?`<video class="moment-media" src="${escapeHTML(post.mediaUrl)}" controls playsinline preload="metadata"></video>`:'');
    const reactionCount=server?Number(post.reactionCount||0):Object.values(post.reactions||{}).reduce((sum,uids)=>sum+(Array.isArray(uids)?uids.length:0),0);
    const comments=server?(post.comments||[]).map(comment=>`<p class="moment-comment"><strong>${escapeHTML(comment.author?.name||'Portador')}:</strong> ${escapeHTML(comment.text)}</p>`).join(''):(post.comments||[]).slice(-5).map(comment=>`<p class="moment-comment"><strong>${escapeHTML(comment.name||'Portador')}:</strong> ${escapeHTML(comment.text)}</p>`).join('');
    const authorName=server?(post.author?.name||post.authorName||'Portador'):(post.authorName||'Portador');
    const miraculousId=server?(post.author?.miraculousId||null):post.miraculousId;
    const canInteract=server?Boolean(state.networkUser&&(post.author?.id===state.networkUser.id||(state.networkFriends||[]).some(friend=>friend.id===post.author?.id))):true;
    const badge=server?(post.visibility==='public'?'◉ Público':'⌑ Amigos'):'⌑ Amigos';
    const reacted=server?post.reacted:(post.reactions?.['❤️']||[]).includes(state.user?.uid);
    const reactButton=server?`<button type="button" data-post-server-react="${escapeHTML(post.id)}" ${!canInteract?'disabled title="Somente amigos podem reagir"':''}>${reacted?'❤️ Curtido':'♡ Curtir'} · ${reactionCount}</button>`:`<button type="button" data-post-react="${escapeHTML(post.id)}">❤️ Reagir · ${reactionCount}</button>`;
    const commentButton=server?`<button type="button" data-post-server-comment="${escapeHTML(post.id)}" ${!canInteract?'disabled title="Somente amigos podem comentar"':''}>Comentar</button>`:`<button type="button" data-post-comment="${escapeHTML(post.id)}">Comentar</button>`;
    const deleteButton=server&&post.own?`<button type="button" data-post-server-delete="${escapeHTML(post.id)}">Excluir</button>`:'';
    return `<article class="moment-card post-card"><div class="moment-avatar">${sigilImage(miraculousId,'','')}</div><div class="moment-content"><div class="post-author-line"><strong>${escapeHTML(authorName)}</strong><span class="post-friends-badge">${badge}</span></div><small>${new Date(post.createdAt).toLocaleString('pt-BR')}</small>${post.text?`<p>${escapeHTML(post.text)}</p>`:''}${media}<div class="moment-social-actions">${reactButton}${commentButton}${deleteButton}<small>${server?Number(post.commentCount||0):(post.comments||[]).length} comentário(s)</small></div>${comments}</div></article>`;
  }).join(''):'<div class="empty-state">Ainda não há publicações no seu feed. Adicione amigos pelo Miracode ou siga contas públicas.</div>';
  const count=$('#posts-count');if(count)count.textContent=String(posts.length);
}
async function publishPost(event){
  event.preventDefault();const input=$('#post-text');const text=input.value.trim();const file=$('#post-media-input')?.files?.[0];if(!text&&!file)return;
  if(state.networkUser){
    try{
      if(file){const isImage=file.type.startsWith('image/');const isVideo=/^video\/(mp4|webm|quicktime)$/i.test(file.type);if(!isImage&&!isVideo)throw new Error('Escolha JPG, PNG, WebP, MP4, WebM ou MOV.');if(file.size>(isImage?12:80)*1024*1024)throw new Error(isImage?'A imagem excede 12 MB.':'O vídeo excede 80 MB.');}
      const visibility=$('#post-visibility')?.value==='public'?'public':'friends';
      const created=await networkApi('/posts',{method:'POST',json:{text:text.slice(0,600),visibility,wantsMedia:Boolean(file)}});
      if(file){
        try{await networkApi(`/posts/${encodeURIComponent(created.post.id)}/media`,{method:'POST',headers:{'Content-Type':file.type},body:file});}
        catch(error){await networkApi(`/posts/${encodeURIComponent(created.post.id)}`,{method:'DELETE'}).catch(()=>{});throw error;}
      }
      input.value='';if($('#post-media-input'))$('#post-media-input').value='';await refreshNetworkSocial();showToast('Publicação enviada para a Rede Mirafriends.');return;
    }catch(error){showToast(`Não foi possível publicar: ${error.message}`);return;}
  }
  let mediaUrl=null,mediaType=null;
  try{
    if(file){
      if(file.type.startsWith('image/')){const blob=await compressImageFile(file);if(blob.size>900*1024)throw new Error('A imagem ficou grande demais.');mediaUrl=await blobToDataUrl(blob);mediaType='image';}
      else if(/^video\/(mp4|webm|quicktime)$/i.test(file.type)){if(file.size>1200*1024)throw new Error('O vídeo precisa ter até 1,2 MB para distribuição P2P nesta beta.');mediaUrl=await blobToDataUrl(file);mediaType='video';}
      else throw new Error('Escolha uma imagem ou vídeo MP4, WebM ou MOV.');
    }
    const post={id:newMessageId(),authorUid:state.user.uid,authorName:state.profile.name,miraculousId:state.profile.miraculousId,text:text.slice(0,600),mediaUrl,mediaType,visibility:'friends',reactions:{},comments:[],createdAt:Date.now()};
    await savePost(post);let sent=0;
    for(const contact of state.contacts){if(state.blockedContacts?.includes(contact.uid))continue;const peer=p2pPeerForContact(contact);if(peer?.channel?.readyState==='open'&&sendP2PPacket(peer,{kind:'post',post}))sent++;}
    input.value='';if($('#post-media-input'))$('#post-media-input').value='';renderPosts();
    showToast(sent?`Publicação compartilhada com ${sent} amigo(s) conectado(s).`:'Publicação salva neste aparelho. Nenhum amigo P2P está conectado agora.');
  }catch(error){showToast(`Não foi possível publicar: ${error.message}`);}
}
async function receivePost(peer,packet){
  const raw=packet.post;if(!raw||raw.visibility!=='friends'||raw.authorUid!==peer.peerUid||typeof raw.text!=='string'||raw.text.length>600||!raw.id||!Number.isFinite(raw.createdAt))return;
  if(!state.contacts.some(contact=>contact.uid===peer.peerUid)||state.blockedContacts?.includes(peer.peerUid))return;
  if(raw.mediaUrl&&(!/^data:(?:image\/(?:webp|jpeg|png)|video\/(?:mp4|webm|quicktime));base64,/i.test(raw.mediaUrl)||raw.mediaUrl.length>1900000))return;
  if(state.posts.some(item=>item.id===raw.id))return;
  const post={id:String(raw.id).slice(0,64),authorUid:peer.peerUid,authorName:String(raw.authorName||peer.peerName).slice(0,36),miraculousId:raw.miraculousId||peer.miraculousId,text:raw.text,mediaUrl:raw.mediaUrl||null,mediaType:raw.mediaType==='video'?'video':raw.mediaType==='image'?'image':null,visibility:'friends',reactions:{},comments:[],createdAt:raw.createdAt};
  await savePost(post);renderPosts();showToast(`Nova publicação de ${post.authorName}.`);
}
function sendPostAction(post,action,data={}){
  const packet={kind:'post-action',postId:post.id,action,...data};
  for(const contact of state.contacts){if(state.blockedContacts?.includes(contact.uid))continue;const peer=p2pPeerForContact(contact);if(peer?.channel?.readyState==='open')sendP2PPacket(peer,packet);}
}
async function receivePostAction(peer,packet){
  const post=state.posts.find(item=>item.id===packet.postId);if(!post||!state.contacts.some(contact=>contact.uid===peer.peerUid)||state.blockedContacts?.includes(peer.peerUid)||!['react','comment'].includes(packet.action))return;
  if(packet.action==='react'&&['❤️','👍','✨','😂'].includes(packet.emoji)){
    post.reactions=post.reactions||{};const users=Array.isArray(post.reactions[packet.emoji])?post.reactions[packet.emoji]:[];
    post.reactions[packet.emoji]=packet.remove?users.filter(uid=>uid!==peer.peerUid):(users.includes(peer.peerUid)?users:users.concat(peer.peerUid).slice(0,100));
  }
  if(packet.action==='comment'&&typeof packet.text==='string'&&packet.text.trim()&&packet.text.length<=240){
    post.comments=post.comments||[];if(!post.comments.some(comment=>comment.id===packet.commentId))post.comments.push({id:String(packet.commentId||newMessageId()).slice(0,64),uid:peer.peerUid,name:peer.peerName,text:packet.text.trim(),createdAt:Date.now()});post.comments=post.comments.slice(-50);
  }
  await savePost(post);renderPosts();
}
function handlePostAction(element){
  const serverReact=element.dataset.postServerReact;const serverComment=element.dataset.postServerComment;const serverDelete=element.dataset.postServerDelete;
  if(serverDelete){if(confirm('Excluir esta publicação?'))networkApi(`/posts/${encodeURIComponent(serverDelete)}`,{method:'DELETE'}).then(refreshNetworkSocial).then(()=>showToast('Publicação excluída.')).catch(error=>showToast(error.message));return;}
  if(serverReact||serverComment){
    const postId=serverReact||serverComment;
    if(serverReact){networkApi(`/posts/${encodeURIComponent(postId)}/reactions`,{method:'POST',json:{emoji:'❤️'}}).then(refreshNetworkSocial).catch(error=>showToast(error.message));return;}
    const text=prompt('Escreva um comentário para os amigos (até 240 caracteres):','');if(text===null||!text.trim())return;
    networkApi(`/posts/${encodeURIComponent(postId)}/comments`,{method:'POST',json:{text:text.trim().slice(0,240)}}).then(refreshNetworkSocial).catch(error=>showToast(error.message));return;
  }
  const post=state.posts.find(item=>item.id===(element.dataset.postReact||element.dataset.postComment));if(!post)return;
  if(element.dataset.postReact){post.reactions=post.reactions||{};const emoji='❤️';const users=Array.isArray(post.reactions[emoji])?post.reactions[emoji]:[];const exists=users.includes(state.user.uid);post.reactions[emoji]=exists?users.filter(uid=>uid!==state.user.uid):users.concat(state.user.uid);sendPostAction(post,'react',{emoji,remove:exists});savePost(post).then(renderPosts);return;}
  const text=prompt('Escreva um comentário para os amigos (até 240 caracteres):','');if(text===null||!text.trim())return;const comment={id:newMessageId(),uid:state.user.uid,name:state.profile.name,text:text.trim().slice(0,240),createdAt:Date.now()};post.comments=[...(post.comments||[]),comment].slice(-50);sendPostAction(post,'comment',{commentId:comment.id,text:comment.text});savePost(post).then(renderPosts);
}

let cameraStream=null;
async function startCamera(){
  if(!navigator.mediaDevices?.getUserMedia){showToast('A câmera precisa de HTTPS e de um navegador compatível.');return;}
  try{
    stopCamera();cameraStream=await navigator.mediaDevices.getUserMedia({audio:false,video:{facingMode:{ideal:state.cameraFacingMode},width:{ideal:1280},height:{ideal:960}}});state.cameraStream=cameraStream;
    const video=$('#camera-video');video.srcObject=cameraStream;video.hidden=false;$('#camera-placeholder').hidden=true;await video.play().catch(()=>{});
    $('#camera-status').textContent='AO VIVO';$('#camera-status').classList.add('live');$('#camera-start').textContent='Fechar câmera';$('#camera-switch').disabled=false;$('#camera-capture').disabled=false;
  }catch(error){showToast(error.name==='NotAllowedError'?'Permita a câmera nas configurações do navegador.':`Não foi possível abrir a câmera: ${error.message}`);}
}
function stopCamera(){
  const stream=state.cameraStream||cameraStream;if(stream)stream.getTracks().forEach(track=>track.stop());state.cameraStream=null;cameraStream=null;
  const video=$('#camera-video');if(video){video.pause?.();video.srcObject=null;video.hidden=true;}
  const placeholder=$('#camera-placeholder');if(placeholder)placeholder.hidden=false;
  const status=$('#camera-status');if(status){status.textContent='DESLIGADA';status.classList.remove('live');}
  const start=$('#camera-start');if(start)start.textContent='Abrir câmera';const sw=$('#camera-switch');if(sw)sw.disabled=true;const cap=$('#camera-capture');if(cap)cap.disabled=true;
}
async function switchCamera(){
  state.cameraFacingMode=state.cameraFacingMode==='environment'?'user':'environment';if(cameraStream||state.cameraStream)await startCamera();
}
function releaseAlbumUrls(){for(const url of state.albumObjectUrls||[])URL.revokeObjectURL(url);state.albumObjectUrls=[];}
async function renderAlbum(){
  const grid=$('#album-grid');if(!grid)return;releaseAlbumUrls();
  let items=[];try{items=(await idbStoreAction('album','readonly',store=>store.getAll()))||[];}catch{}
  items.sort((a,b)=>b.createdAt-a.createdAt);state.albumItems=items;
  $('#album-count').textContent=String(items.length);
  const hint=$('#album-picker-hint');if(hint){hint.hidden=!state.mediaPickerMode;hint.textContent=state.mediaPickerMode&&state.activeContact?`Escolha uma foto para enviar a ${state.activeContact.name}.`:'Escolha uma foto do álbum.';}
  if(!items.length){grid.innerHTML='<div class="empty-state">Seu álbum está vazio. Tire uma foto ou importe imagens.</div>';$('#album-send-selected').hidden=true;$('#album-delete-selected').hidden=true;return;}
  grid.innerHTML=items.map(item=>{const url=URL.createObjectURL(item.blob);state.albumObjectUrls.push(url);return `<button type="button" class="album-item ${state.selectedAlbumId===item.id?'selected':''}" data-album-select="${escapeHTML(item.id)}"><img src="${url}" alt="Foto salva no álbum"><small>${new Date(item.createdAt).toLocaleDateString('pt-BR')}</small></button>`;}).join('');
  const selected=items.some(item=>item.id===state.selectedAlbumId);$('#album-send-selected').hidden=!(selected&&state.mediaPickerMode);$('#album-delete-selected').hidden=!selected;
}
async function compressImageFile(file){
  if(!file||!file.type.startsWith('image/'))throw new Error('Escolha um arquivo de imagem.');
  const url=URL.createObjectURL(file);
  try{
    const img=await new Promise((resolve,reject)=>{const image=new Image();image.onload=()=>resolve(image);image.onerror=()=>reject(new Error('Não foi possível abrir essa imagem.'));image.src=url;});
    const scale=Math.min(1,1600/Math.max(img.naturalWidth,img.naturalHeight));const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(img.naturalWidth*scale));canvas.height=Math.max(1,Math.round(img.naturalHeight*scale));
    const ctx=canvas.getContext('2d');if(!ctx)throw new Error('Não foi possível processar a foto.');ctx.drawImage(img,0,0,canvas.width,canvas.height);
    let blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/webp',.78));if(!blob)blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/jpeg',.76));
    if(!blob||blob.size>900*1024)blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/jpeg',.62));if(!blob||blob.size>900*1024)throw new Error('A foto ficou muito grande. Escolha outra imagem.');return blob;
  }finally{URL.revokeObjectURL(url);}
}
async function addAlbumPhoto(blob,name='Foto do Mirafriends'){
  if((state.albumItems||[]).length>=250)throw new Error('Seu álbum interno chegou ao limite de 250 fotos. Exclua algumas para liberar espaço.');
  const item={id:`photo-${randomLocalId()}`,name:String(name).slice(0,80),createdAt:Date.now(),mimeType:blob.type||'image/jpeg',blob};
  await idbStoreAction('album','readwrite',store=>store.put(item));state.selectedAlbumId=item.id;await renderAlbum();showToast('Foto salva no álbum interno do Mirafriends.');
  if(state.mediaPickerMode&&state.activeContact)await sendSelectedAlbumPhoto();
}
async function capturePhoto(){
  const video=$('#camera-video');if(!cameraStream||!video.videoWidth){showToast('Abra a câmera antes de tirar uma foto.');return;}
  const canvas=$('#camera-canvas'),scale=Math.min(1,1600/Math.max(video.videoWidth,video.videoHeight));canvas.width=Math.round(video.videoWidth*scale);canvas.height=Math.round(video.videoHeight*scale);
  const ctx=canvas.getContext('2d');ctx.drawImage(video,0,0,canvas.width,canvas.height);
  const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/jpeg',.82));if(!blob){showToast('Não foi possível capturar esta foto.');return;}await addAlbumPhoto(blob,`Captura-${Date.now()}.jpg`);
}
async function importAlbumPhotos(event){
  const files=[...(event.target.files||[])];event.target.value='';if(!files.length)return;
  for(const file of files.slice(0,12)){try{const blob=await compressImageFile(file);await addAlbumPhoto(blob,file.name);}catch(error){showToast(error.message);}}
}
async function sendSelectedAlbumPhoto(){
  const item=state.albumItems.find(photo=>photo.id===state.selectedAlbumId);if(!item||!state.mediaPickerMode||!state.activeContact){showToast('Abra uma conversa antes de escolher uma foto para enviar.');return;}
  const file=new File([item.blob],item.name||'foto-mirafriends.jpg',{type:item.blob.type||'image/jpeg'});
  state.mediaPickerMode=false;await uploadAndSend(file,'image');activatePage('chat','chats');releaseAlbumUrls();
}
async function deleteSelectedAlbumPhoto(){
  if(!state.selectedAlbumId)return;await idbStoreAction('album','readwrite',store=>store.delete(state.selectedAlbumId));state.selectedAlbumId=null;await renderAlbum();showToast('Foto removida do álbum interno.');
}

async function flushPendingMessages(){
  if(state.flushingOutbox)return;state.flushingOutbox=true;
  try{
    const pending=(await getPendingMessages()).sort((a,b)=>Number(a.queuedAt)-Number(b.queuedAt));
    for(const message of pending){
      const peer=p2pPeers.get(message.friendshipId);if(!peer?.channel||peer.channel.readyState!=='open')continue;
      try{
        if(message.type==='text')peer.channel.send(JSON.stringify({kind:'text',message:{...message,pending:undefined,queuedAt:undefined}}));
        else if(message.mediaUrl?.startsWith('data:')){
          const blob=await (await fetch(message.mediaUrl)).blob();const active=state.chatPeer;state.chatPeer=peer;
          const sent=await sendMediaOverPeer(new File([blob],`anexo-${message.id}`,{type:blob.type}),message);state.chatPeer=active;if(!sent)continue;
        }else continue;
        await removePendingMessage(message.id);const saved={...message,pending:false};await cacheMessage(saved);
        if(state.activeFriendshipId===message.friendshipId){const index=state.messages.findIndex(m=>m.id===message.id);if(index>=0){state.messages[index]={...state.messages[index],pending:false};renderMessages();}}
      }catch(error){console.warn('Fila P2P aguardando:',error);break;}
    }
  }finally{state.flushingOutbox=false;}
}

function appendMessageOnce(message){
  if(!message?.id)return;cacheMessage(message);
  if(message.friendshipId!==state.activeFriendshipId){const contact=state.contacts.find(c=>c.friendshipId===message.friendshipId);if(contact){showToast(`Nova mensagem P2P de ${contact.name}.`);showLocalNotification(`${currentKwami().name} avisa: nova mensagem`,`Mensagem de ${contact.name}: ${message.type==='text'?message.text:'você recebeu um anexo.'}`,`message-${message.friendshipId}`);renderChats();}return;}
  if(state.messages.some(item=>item.id===message.id))return;state.messages.push(message);playUiSound('receive');renderMessages();if(message.senderUid!==state.user?.uid&&state.activeFriendshipId===message.friendshipId&&state.chatPeer?.channel?.readyState==='open')sendP2PPacket(state.chatPeer,{kind:'read',ids:[message.id]});
}
async function openChat(uid){
  const contact=state.contacts.find(c=>c.uid===uid);if(!contact)return;if(state.blockedContacts.includes(uid)){showToast('Este portador está bloqueado neste aparelho. Desbloqueie no perfil para abrir a conversa.');return;}
  state.assistantOpen=false;updateKwamiTransformControls();$('#bot-help-panel').hidden=true;$('#kwami-chat-transform').hidden=true;$('#start-voice-call').hidden=false;$('#start-video-call').hidden=false;$('#composer-tools').hidden=false;
  state.activeContact=contact;state.activeFriendshipId=contact.friendshipId;const m=getMiraculous(contact.miraculousId);setTheme(state.profile.miraculousId);
  $('#chat-contact-name').textContent=contact.name;$('#chat-contact-miraculous').textContent=`Portador do Miraculous da ${m?.name||'—'} · P2P`;
  $('#chat-avatar').innerHTML=contact.avatarData?`<img class="chat-avatar-photo" src="${contact.avatarData}" alt="Foto de perfil de ${escapeHTML(contact.name)}">`:sigilImage(contact.miraculousId,'chat-avatar-sigil','Emblema do Miraculous');
  state.messages=await getCachedMessages(contact.friendshipId);$('#chat-search').value='';state.replyTarget=null;updateReplyPreview();activatePage('chat','chats');renderMessages();await beginChatPeer(contact);markVisibleMessagesRead();
}

function updateReplyPreview(){const panel=$('#reply-preview');if(!panel)return;panel.hidden=!state.replyTarget;$('#reply-preview-text').textContent=state.replyTarget?`Respondendo: ${String(state.replyTarget.text||'Mensagem').slice(0,90)}`:'';}
function sendMessageAction(action,message,extra={}){const payload={kind:'message-action',action,messageId:message.id,...extra};if(state.chatPeer?.channel?.readyState==='open')sendP2PPacket(state.chatPeer,payload);}
async function receiveReadReceipt(peer,packet){
  const ids=Array.isArray(packet.ids)?packet.ids.filter(id=>typeof id==='string').slice(0,100):[];if(!ids.length)return;
  const isActive=state.activeFriendshipId===peer.friendshipId;
  const messages=isActive?state.messages:await getCachedMessages(peer.friendshipId);let changed=false;
  for(const message of messages){
    if(ids.includes(message.id)&&message.senderUid===state.user.uid){message.readBy=[...new Set([...(message.readBy||[]),peer.peerUid])];changed=true;}
  }
  if(changed){await cacheMessages(messages.filter(message=>ids.includes(message.id)));if(isActive)renderMessages();}
}
async function applyRemoteMessageAction(peer,packet){
  if(!['edit','delete','react','pin'].includes(packet.action)||typeof packet.messageId!=='string')return;
  const isActive=state.activeFriendshipId===peer.friendshipId;
  const messages=isActive?state.messages:await getCachedMessages(peer.friendshipId);
  const message=messages.find(item=>item.id===packet.messageId);if(!message)return;
  if(['edit','delete'].includes(packet.action)&&message.senderUid!==peer.peerUid)return;
  if(packet.action==='edit'&&typeof packet.text==='string'&&packet.text.length<=1000)message.text=packet.text;
  if(packet.action==='delete')message.deleted=true;
  if(packet.action==='react'&&['👍','❤️','😂','✨','😮','👏'].includes(packet.emoji)){message.reactions=message.reactions||{};if(packet.remove)delete message.reactions[peer.peerUid];else message.reactions[peer.peerUid]=packet.emoji;}
  if(packet.action==='pin')message.pinned=Boolean(packet.pinned);
  await cacheMessage(message);if(isActive)renderMessages();
}
function handleMessageAction(button){
  const message=state.messages.find(item=>item.id===button.dataset.messageId);if(!message)return;const action=button.dataset.messageAction;
  if(action==='reply'){state.replyTarget=message;updateReplyPreview();$('#message-input').focus();return;}
  if(action==='react'){const options=['👍','❤️','😂','✨','😮','👏'];const chosen=prompt(`Escolha uma reação: ${options.join(' ')}`,'❤️');if(!options.includes(chosen))return;message.reactions=message.reactions||{};const remove=message.reactions[state.user.uid]===chosen;if(remove)delete message.reactions[state.user.uid];else message.reactions[state.user.uid]=chosen;sendMessageAction('react',message,{emoji:chosen,remove});cacheMessage(message);renderMessages();return;}
  if(action==='pin'){message.pinned=!message.pinned;sendMessageAction('pin',message,{pinned:message.pinned});cacheMessage(message);renderMessages();return;}
  if(action==='edit'){if(message.senderUid!==state.user.uid)return;const updated=prompt('Editar mensagem:',message.text||'');if(updated===null)return;const text=updated.trim().slice(0,1000);if(!text)return;message.text=text;sendMessageAction('edit',message,{text});cacheMessage(message);renderMessages();return;}
  if(action==='delete'){if(message.senderUid!==state.user.uid||!confirm('Apagar esta mensagem para os dois portadores?'))return;message.deleted=true;sendMessageAction('delete',message);cacheMessage(message);renderMessages();}
}
function sendSticker(text){
  if(state.assistantOpen){sendAssistantMessage(text);return;}
  if(!state.activeFriendshipId||!state.activeContact){showToast('Abra uma conversa antes de enviar uma figurinha.');return;}
  const message={id:newMessageId(),friendshipId:state.activeFriendshipId,senderUid:state.user.uid,type:'sticker',text,createdAt:Date.now(),delivered:false};
  if(state.chatPeer?.channel?.readyState==='open'&&sendP2PPacket(state.chatPeer,{kind:'text',message})){appendMessageOnce(message);}else showToast('Conecte o portador para enviar figurinhas.');
  $('#sticker-tray').hidden=true;
}
async function renderCustomStickers(){
  const host=$('#custom-sticker-list');if(!host)return;
  for(const url of state.stickerObjectUrls||[])URL.revokeObjectURL(url);state.stickerObjectUrls=[];
  let items=[];try{items=(await idbStoreAction('stickers','readonly',store=>store.getAll()))||[];}catch{}
  items.sort((a,b)=>(b.createdAt||0)-(a.createdAt||0));
  host.innerHTML=items.slice(0,24).map(item=>{const url=URL.createObjectURL(item.blob);state.stickerObjectUrls.push(url);return `<div class="custom-sticker-tile"><button type="button" class="custom-sticker-item" data-custom-sticker="${escapeHTML(item.id)}" title="Enviar figurinha"><img src="${url}" alt="Figurinha personalizada"></button><button type="button" class="custom-sticker-remove" data-delete-custom-sticker="${escapeHTML(item.id)}" aria-label="Remover figurinha" title="Remover figurinha">×</button></div>`;}).join('');
}
async function deleteCustomSticker(id){
  if(!id)return;
  const item=await idbStoreAction('stickers','readonly',store=>store.get(id)).catch(()=>null);
  if(!item)return;
  if(!confirm(`Remover a figurinha “${String(item.name||'Figurinha').slice(0,50)}” desta coleção?`))return;
  await idbStoreAction('stickers','readwrite',store=>store.delete(id));
  await renderCustomStickers();showToast('Figurinha removida da coleção.');
}
async function addCustomSticker(file){
  if(!file)return;
  const count=await idbStoreAction('stickers','readonly',store=>store.count()).catch(()=>0);
  if(count>=24){showToast('Limite de 24 figurinhas personalizadas. Remova algumas para adicionar outras.');return;}
  const blob=await compressImageFile(file);
  if(blob.size>900*1024)throw new Error('A figurinha ficou muito grande. Escolha uma imagem menor.');
  const item={id:`sticker-${randomLocalId()}`,name:String(file.name||'Figurinha').slice(0,80),createdAt:Date.now(),mimeType:blob.type||'image/webp',blob};
  await idbStoreAction('stickers','readwrite',store=>store.put(item));await renderCustomStickers();showToast('Figurinha personalizada adicionada à sua coleção.');
}
async function sendCustomSticker(id){
  const item=await idbStoreAction('stickers','readonly',store=>store.get(id)).catch(()=>null);if(!item?.blob)return;
  if(!state.activeContact||!state.activeFriendshipId){showToast('Abra uma conversa para enviar a figurinha.');return;}
  const file=new File([item.blob],item.name||'figurinha.webp',{type:item.mimeType||item.blob.type||'image/webp'});
  $('#sticker-tray').hidden=true;await uploadAndSend(file,'sticker');
}
function sendTypingState(active){if(!state.chatPeer?.channel||state.chatPeer.channel.readyState!=='open')return;const now=Date.now();if(active&&now-state.lastTypingSignal<800)return;state.lastTypingSignal=now;sendP2PPacket(state.chatPeer,{kind:'typing',active:Boolean(active)});}
function markVisibleMessagesRead(){if(!state.activeFriendshipId||!state.chatPeer?.channel||state.chatPeer.channel.readyState!=='open')return;const ids=state.messages.filter(message=>message.senderUid===state.activeContact?.uid&&!message.readBy?.includes(state.user.uid)).map(message=>message.id).slice(0,100);if(ids.length)sendP2PPacket(state.chatPeer,{kind:'read',ids});}
function renderMessages(){
  state.mediaObjectUrls.forEach(url=>URL.revokeObjectURL(url));state.mediaObjectUrls=[];
  const currentUid=state.user?.uid;
  const kwami=currentKwami();
  const search=($('#chat-search')?.value||'').trim().toLocaleLowerCase('pt-BR');
  const filtered=state.messages.filter(message=>!search||String(message.text||message.fileName||'').toLocaleLowerCase('pt-BR').includes(search));
  const html=filtered.map(message=>{
    const mine=!message.isKwami&&message.senderUid===currentUid;let content='';
    if(message.deleted)content='<em>Mensagem apagada</em>';
    else if(message.type==='image')content=`<img data-private-media="${escapeHTML(message.mediaUrl)}" alt="Imagem enviada">`;
    else if(message.type==='audio')content=`<audio controls preload="none" data-private-media="${escapeHTML(message.mediaUrl)}"></audio>`;
    else if(message.type==='video')content=`<video controls playsinline preload="metadata" data-private-media="${escapeHTML(message.mediaUrl)}"></video>`;
    else if(message.type==='file')content=`<a class="chat-file-link" data-private-file="${escapeHTML(message.mediaUrl)}" download="${escapeHTML(message.fileName||'arquivo')}">📎 ${escapeHTML(message.fileName||'Arquivo recebido')}</a>`;
    else if(message.type==='sticker'&&message.mediaUrl?.startsWith('data:image/'))content=`<img class="chat-sticker-image" data-private-media="${escapeHTML(message.mediaUrl)}" alt="Figurinha personalizada">`;
    else if(message.type==='sticker')content=`<span class="chat-sticker">${escapeHTML(message.text||'✨')}</span>`;
    else content=escapeHTML(message.text||'');
    const delivery=mine?(message.pending?'Pendente':(message.readBy?.includes(state.activeContact?.uid)?'Lida ✓✓':(message.delivered?'Entregue ✓':'Enviada ✓'))):'';
    const kwamiSigil=message.isKwami?`<img class="kwami-message-sigil" src="${escapeHTML(sigilURL(kwami.miraculousId))}" alt="Símbolo do Miraculous da ${escapeHTML(kwami.miraculousName)}">`:'';
    const quote=message.replyTo?`<div class="message-quote">↪ ${escapeHTML(message.replyTo.text||'Mensagem')}</div>`:'';
    const reactions=Object.entries(message.reactions||{}).reduce((acc,[uid,emoji])=>{const key=escapeHTML(emoji);acc[key]=(acc[key]||0)+1;return acc;},{});
    const reactionHtml=Object.entries(reactions).map(([emoji,total])=>`<span class="message-reaction">${emoji} ${total}</span>`).join('');
    const actions=!message.isKwami&&!message.deleted?`<div class="message-actions"><button type="button" data-message-action="reply" data-message-id="${escapeHTML(message.id)}">Responder</button><button type="button" data-message-action="react" data-message-id="${escapeHTML(message.id)}">❤️</button><button type="button" data-message-action="pin" data-message-id="${escapeHTML(message.id)}">${message.pinned?'Desafixar':'Fixar'}</button>${mine?`<button type="button" data-message-action="edit" data-message-id="${escapeHTML(message.id)}">Editar</button><button type="button" data-message-action="delete" data-message-id="${escapeHTML(message.id)}">Apagar</button>`:''}</div>`:'';
    return `<div class="message ${mine?'mine':'theirs'} ${message.pending?'pending-message':''} ${message.isKwami?'kwami-reply':''} ${message.pinned?'message-pinned':''}" data-message-id="${escapeHTML(message.id)}">${kwamiSigil}${quote}<span class="message-copy">${content}</span><div class="message-reactions">${reactionHtml}</div>${delivery?`<small class="message-delivery-status">${delivery}</small>`:''}<time>${new Date(message.createdAt||Date.now()).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})}</time>${actions}</div>`;
  }).join('');
  $('#chat-messages').innerHTML=html||'<div class="chat-empty">As mensagens entre vocês aparecerão aqui.</div>';
  // No modo P2P puro, as mídias recebidas são armazenadas localmente como data URLs.
  $$('[data-private-media]').forEach(element=>{const mediaUrl=element.dataset.privateMedia||'';if(mediaUrl.startsWith('data:'))element.src=mediaUrl;else element.replaceWith(document.createTextNode('Anexo local indisponível'));});
  $$('[data-private-file]').forEach(element=>{const mediaUrl=element.dataset.privateFile||'';if(mediaUrl.startsWith('data:'))element.href=mediaUrl;else element.replaceWith(document.createTextNode('Arquivo local indisponível'));});
  const box=$('#chat-messages');box.scrollTop=box.scrollHeight;
}
async function postMessage(text){
  if(!state.activeFriendshipId||!state.activeContact){showToast('Abra uma conversa emparelhada para enviar mensagens.');return;}
  const messageId=newMessageId();const reply=state.replyTarget?{id:state.replyTarget.id,text:String(state.replyTarget.text||'Mensagem').slice(0,100)}:null;const directMessage={id:messageId,friendshipId:state.activeFriendshipId,senderUid:state.user.uid,type:'text',text,replyTo:reply,createdAt:Date.now(),delivered:false};state.replyTarget=null;updateReplyPreview();playUiSound('send');
  const peer=state.chatPeer;
  if(peer?.channel?.readyState==='open'&&sendP2PPacket(peer,{kind:'text',message:directMessage})){appendMessageOnce(directMessage);return;}
  const pending={...directMessage,pending:true};appendMessageOnce(pending);await queuePendingMessage(pending);showToast('Sem conexão P2P ativa. Mensagem guardada neste aparelho e será enviada quando vocês se reconectarem.');
}
async function uploadAndSend(file,type){
  if(!file||!state.activeFriendshipId)return;const maxBytes=2*1024*1024;if(file.size>maxBytes){showToast('No modo P2P direto, cada arquivo precisa ter até 2 MB.');return;}if(type==='sticker'&&!/^image\/(png|jpeg|webp)$/i.test(file.type)){showToast('Figurinhas precisam ser imagens PNG, JPG ou WebP.');return;}if(type==='video'&&!/^video\/(mp4|webm|quicktime)$/i.test(file.type)){showToast('Formato de vídeo não compatível. Use MP4, WebM ou MOV.');return;}if(type==='file'&&!/^(application\/pdf|text\/plain|application\/zip|application\/vnd\.openxmlformats-officedocument\.)/i.test(file.type)){showToast('Por segurança, este formato de arquivo não é aceito nesta versão.');return;}
  const messageId=newMessageId();const safeType=['image','sticker','audio','video','file'].includes(type)?type:'file';const directMessage={id:messageId,friendshipId:state.activeFriendshipId,senderUid:state.user.uid,type:safeType,fileName:String(file.name||'arquivo').slice(0,100),createdAt:Date.now(),mimeType:file.type||'application/octet-stream',delivered:false};
  try{
    const mediaUrl=await blobToDataUrl(file);const localMessage={...directMessage,mediaUrl};
    if(state.chatPeer?.channel?.readyState==='open'&&await sendMediaOverPeer(file,directMessage)){appendMessageOnce(localMessage);return;}
    const pending={...localMessage,pending:true};appendMessageOnce(pending);await queuePendingMessage(pending);showToast('Anexo guardado neste aparelho. Ele será enviado quando a conexão P2P estiver ativa.');
  }catch(error){showToast(`Não foi possível preparar o anexo: ${error.message}`);}
}

function vibratePattern(){
  if(!('vibrate'in navigator)){showToast('Este aparelho ou navegador não permite controlar a vibração.');return;}
  stopVibration(false);const pattern=[800,250,800,250,1100];navigator.vibrate(pattern);
  state.vibrationTimer=setInterval(()=>{if(document.visibilityState==='visible')navigator.vibrate(pattern);},3400);
}
function stopVibration(closeBanner=true){if(state.vibrationTimer){clearInterval(state.vibrationTimer);state.vibrationTimer=null;}if('vibrate'in navigator)navigator.vibrate(0);if(closeBanner)$('#incoming-alert-banner').hidden=true;}
function startVoiceVibration(){
  stopVoiceVibration();
  if(document.visibilityState!=='visible'||!('vibrate'in navigator))return;
  const pattern=[550,280,550,850];
  navigator.vibrate(pattern);
  state.voiceVibrationTimer=setInterval(()=>{
    if(document.visibilityState==='visible'&&state.voiceCall&&!state.voiceCall.accepted)navigator.vibrate(pattern);
  },2500);
}
function stopVoiceVibration(){if(state.voiceVibrationTimer){clearInterval(state.voiceVibrationTimer);state.voiceVibrationTimer=null;}if('vibrate'in navigator)navigator.vibrate(0);}
window.addEventListener('online',()=>flushPendingMessages().catch(()=>{}));
window.addEventListener('pagehide',()=>stopCamera());let appHiddenAt=0;document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')appHiddenAt=Date.now();else if(appHiddenAt&&Date.now()-appHiddenAt>120000)lockApp();});
document.addEventListener('visibilitychange',()=>{
  if(document.visibilityState!=='visible')stopCamera();
  if(document.visibilityState==='visible'&&state.voiceCall&&!state.voiceCall.accepted)startVoiceVibration();
  if(document.visibilityState!=='visible'&&state.voiceVibrationTimer){clearInterval(state.voiceVibrationTimer);state.voiceVibrationTimer=null;if('vibrate'in navigator)navigator.vibrate(0);}
});
function showIncomingCall(call,localTest=false){
  if(!localTest&&state.activeIncomingCall?.id===call.id)return;
  state.activeIncomingCall=localTest?null:call;
  setPendingImage('#alert-sigil',call.senderMiraculousId||call.miraculousId);
  const senderM=getMiraculous(call.senderMiraculousId||call.miraculousId);
  const senderLabel=call.senderMiraculousName||senderM?.name||'Miraculous';
  $('#alert-title').textContent=localTest?'Teste de alerta recebido':`${call.senderName||'Um portador'} está te chamando`;
  $('#alert-description').textContent=localTest?'Teste local de vibração.':`Portador de ${senderLabel} está te chamando.`;
  $('#incoming-alert-explainer').textContent=localTest?'Nenhum outro celular recebeu este teste.':'Toque em Parar vibração para encerrar o alerta e confirmar para quem chamou.';
  $('#incoming-alert-banner').hidden=false;if(!localTest)showLocalNotification('Alerta de portador',`${call.senderName||'Um portador'} está chamando você.`,`call-${call.id}`);vibratePattern();
}
async function acknowledgeIncoming(){
  const call=state.activeIncomingCall;state.activeIncomingCall=null;stopVibration();if(call?.peer)sendP2PPacket(call.peer,{kind:'call-alert-ack',callId:call.id});
}
let callLaunchTimer=null;
function triggerCallLaunchAnimation(miraculousIds){
  // Preserve one emblem per actual recipient, even when two friends chose the same Miraculous.
  const ids=(miraculousIds||[]).filter(id=>Boolean(getMiraculous(id)));if(!ids.length)return;
  const overlay=$('#call-launch-overlay');if(!overlay)return;
  clearTimeout(callLaunchTimer);overlay.className=`call-launch-overlay ${ids.length>1?'multi-call-launch':'single-call-launch'}`;overlay.innerHTML='';
  ids.forEach((id,index)=>{
    const miraculous=getMiraculous(id);
    const burst=document.createElement('div');burst.className='call-launch-burst';burst.style.setProperty('--burst-index',String(index));
    burst.style.setProperty('--call-color',miraculous?.color||'var(--accent)');
    burst.style.setProperty('--call-rgb',miraculous?.custom?hexToRgbTriplet(miraculous.color):(miraculous?.rgb||'196,175,232'));
    for(let wave=0;wave<3;wave++){const ring=document.createElement('span');ring.className='call-launch-wave';ring.style.setProperty('--wave-index',String(wave));burst.append(ring);}
    const icon=document.createElement('img');icon.className='call-launch-icon';icon.src=sigilURL(id);icon.alt=`Emblema ${miraculous?.name||'Miraculous'}`;burst.append(icon);
    overlay.append(burst);
  });
  overlay.hidden=false;void overlay.offsetWidth;requestAnimationFrame(()=>overlay.classList.add('playing'));
  callLaunchTimer=setTimeout(()=>{overlay.classList.remove('playing');overlay.classList.add('call-launch-leaving');setTimeout(()=>{overlay.hidden=true;overlay.className='call-launch-overlay';overlay.innerHTML='';},360);},3200);
}

async function sendCallAlert(allFriends=false){
  if(state.activeOutgoingCalls.length)return;
  const selectedUids=allFriends?state.contacts.map(c=>c.uid):(state.multiCallMode?state.selectedCallIds:[state.selectedCallContactUid].filter(Boolean));
  const recipients=state.contacts.filter(contact=>selectedUids.includes(contact.uid));const sent=[];
  for(const contact of recipients){
    const peer=p2pPeerForContact(contact);const callId=newMessageId();
    if(peer?.channel?.readyState==='open'&&sendP2PPacket(peer,{kind:'call-alert',callId,senderUid:state.user.uid})){sent.push({id:callId,targetName:contact.name,peerUid:contact.uid,miraculousId:contact.miraculousId,peer});}
  }
  state.activeOutgoingCalls=sent;if(sent.length)triggerCallLaunchAnimation(sent.map(call=>call.miraculousId));
  setPendingImage('#outgoing-sigil',state.profile.miraculousId);$('#outgoing-title').textContent=`Alerta P2P enviado para ${sent.length} portador(es)`;
  $('#outgoing-description').textContent=sent.map(c=>`${c.targetName} · ${universeLabel(state.contacts.find(contact=>contact.uid===c.peerUid))}`).join(', ')||'Nenhuma conexão P2P ativa.';
  $('#outgoing-explainer').textContent='O alerta chega somente aos contatos com canal P2P aberto neste momento.';$('#outgoing-status').hidden=!sent.length;updateCallTarget();
  if(!sent.length)showToast('Nenhum dos portadores selecionados está conectado diretamente.');
}
async function cancelOutgoing(){
  const calls=state.activeOutgoingCalls.slice();for(const call of calls)sendP2PPacket(call.peer,{kind:'call-alert-cancel',callId:call.id});
  state.activeOutgoingCalls=[];$('#outgoing-status').hidden=true;updateCallTarget();
}
function simulateLocalIncoming(){showIncomingCall({senderName:'Teste do Mirafriends',senderMiraculousId:'ladybug'},true);}

async function enableLocalNotifications(){
  if(!('Notification' in window)){showToast('Este navegador não oferece notificações locais.');return;}
  if(!window.isSecureContext){showToast('Publique o Mirafriends em HTTPS para solicitar notificações.');return;}
  try{
    const permission=await Notification.requestPermission();
    if(permission==='granted')showToast('Notificações locais ativadas. Só chegam enquanto o Mirafriends estiver aberto e conectado por P2P.');
    else showToast(permission==='denied'?'Notificações bloqueadas nas permissões do navegador.':'Permissão de notificação não concedida.');
  }catch(error){showToast(`Não foi possível ativar notificações: ${error.message}`);}
}
async function showLocalNotification(title,body,tag='mirafriends-event'){
  if(!('Notification' in window)||Notification.permission!=='granted')return;
  try{
    const options={body:String(body||'').slice(0,180),icon:'./assets/pwa-192.png',badge:'./assets/icon.svg',tag,renotify:false,data:{url:'./'}};
    if('serviceWorker'in navigator){const registration=await navigator.serviceWorker.ready;if(registration?.showNotification){await registration.showNotification(title,options);return;}}
    if(document.visibilityState!=='visible')new Notification(title,options);
  }catch(error){console.debug('Notificação local indisponível:',error);}
}



function manageCurrentContactSafety(){
  const contact=state.activeContact;if(!contact)return;const action=prompt(`Contato: ${contact.name}\nDigite BLOQUEAR ou DENUNCIAR.`,'');if(!action)return;
  if(action.trim().toUpperCase()==='BLOQUEAR'){
    if(!confirm(`Bloquear ${contact.name} neste aparelho?`))return;
    state.blockedContacts=[...new Set([...state.blockedContacts,contact.uid])];localStorage.setItem('mirafriends-blocked-v1',JSON.stringify(state.blockedContacts));sendP2PPacket(state.chatPeer,{kind:'blocked-notice'});closeChatPeer();state.activeContact=null;state.activeFriendshipId=null;nav('chats');showToast(`${contact.name} bloqueado neste aparelho.`);return;
  }
  if(action.trim().toUpperCase()==='DENUNCIAR'){
    const reason=prompt('Descreva o motivo da denúncia (ela ficará registrada somente neste aparelho; não existe servidor de moderação nesta versão).','');if(reason===null)return;
    const reports=JSON.parse(localStorage.getItem('mirafriends-local-reports-v1')||'[]');reports.push({uid:contact.uid,name:contact.name,reason:String(reason).slice(0,500),createdAt:Date.now()});localStorage.setItem('mirafriends-local-reports-v1',JSON.stringify(reports));showToast('Denúncia registrada localmente. Ela não foi enviada a uma equipe de moderação.');
  }
}

function setVoiceStatus(text){$('#voice-status').textContent=text;$('#voice-status').dataset.state=text.toLowerCase().includes('conectada')?'connected':'ringing';}
function showIncomingVoiceCall(data){
  if(state.voiceCall?.callId===data.callId)return;if(state.voiceCall){sendP2PPacket(data.peer,{kind:'voice-decline',callId:data.callId});return;}
  state.voiceCall={callId:data.callId,role:'callee',peerUid:data.fromUid,peerName:data.fromName,friendshipId:data.friendshipId,offer:data.offer,accepted:false,pc:null,localStream:null,peer:data.peer,mediaMode:data.mediaMode||'audio'};
  $('#voice-title').textContent=`${data.fromName} está ${state.voiceCall.mediaMode==='video'?'fazendo chamada de vídeo':'ligando'}`;$('#voice-status').textContent=state.voiceCall.mediaMode==='video'?'Chamada de vídeo P2P recebida':'Ligação P2P recebida';$('#video-call-stage').hidden=state.voiceCall.mediaMode!=='video';showLocalNotification(`${currentKwami().name} alerta: ligação recebida`,`${data.fromName} está tentando ligar.`,`voice-${data.callId}`);$('#voice-answer').hidden=false;$('#voice-decline').hidden=false;$('#voice-end').hidden=true;$('#voice-mute').hidden=true;$('#voice-call-modal').hidden=false;startVoiceVibration();
}
function showVoiceCallUI(status){$('#voice-title').textContent=state.voiceCall?.peerName||'Ligação';$('#voice-status').textContent=status;$('#voice-answer').hidden=true;$('#voice-decline').hidden=true;$('#voice-end').hidden=false;$('#voice-mute').hidden=false;$('#voice-call-modal').hidden=false;}
async function createVoicePeer(peer,stream){
  const pc=new RTCPeerConnection({iceServers:getP2PIceServers(),iceCandidatePoolSize:6});state.voiceCall.pc=pc;state.voiceCall.localStream=stream;
  stream.getTracks().forEach(track=>pc.addTrack(track,stream));
  pc.ontrack=event=>{const streamIn=event.streams[0];const audio=$('#remote-audio');audio.srcObject=streamIn;audio.play().catch(()=>{});if(state.voiceCall.mediaMode==='video'){const video=$('#remote-video');video.srcObject=streamIn;video.play().catch(()=>{});}};
  if(state.voiceCall.mediaMode==='video'){const local=$('#local-video');local.srcObject=stream;$('#video-call-stage').hidden=false;}
  pc.onconnectionstatechange=()=>{if(pc.connectionState==='connected')setVoiceStatus('Ligação P2P conectada');if(['failed','disconnected'].includes(pc.connectionState))setVoiceStatus('Conexão de áudio interrompida');};
  return pc;
}
async function startVoiceCall(videoMode=false){
  const peer=state.chatPeer;if(!state.activeContact||!peer?.channel||peer.channel.readyState!=='open'){showToast('Emparelhe este portador e mantenha o canal P2P conectado antes de ligar.');return;}
  if(!navigator.mediaDevices?.getUserMedia||!window.RTCPeerConnection){showToast('Este navegador não oferece chamadas WebRTC.');return;}
  try{
    const stream=await navigator.mediaDevices.getUserMedia({audio:true,video:videoMode?{facingMode:'user'}:false});const callId=newMessageId();
    state.voiceCall={callId,role:'caller',peerUid:peer.peerUid,peerName:peer.peerName,friendshipId:peer.friendshipId,pc:null,localStream:stream,accepted:true,peer,mediaMode:videoMode?'video':'audio'};
    showVoiceCallUI(`${videoMode?'Chamando por vídeo':'Chamando'} ${peer.peerName}…`);$('#video-call-stage').hidden=!videoMode;const pc=await createVoicePeer(peer,stream);const offer=await pc.createOffer();await pc.setLocalDescription(offer);await gatherIceForShare(pc);
    if(!sendP2PPacket(peer,{kind:videoMode?'video-invite':'voice-invite',callId,offer:pc.localDescription.toJSON?.()||pc.localDescription}))throw new Error('O canal P2P foi interrompido antes de enviar a chamada.');
  }catch(error){closeVoiceCall(false);showToast(error.message||'Não foi possível acessar o microfone.');}
}
async function acceptVoiceCall(){
  const call=state.voiceCall;if(!call)return;call.accepted=true;stopVoiceVibration();showVoiceCallUI('Conectando áudio P2P…');
  try{if(!call.offer)throw new Error('O convite de áudio não contém a oferta WebRTC.');const stream=await navigator.mediaDevices.getUserMedia({audio:true,video:call.mediaMode==='video'?{facingMode:'user'}:false});const pc=await createVoicePeer(call.peer,stream);
    await pc.setRemoteDescription(new RTCSessionDescription(call.offer));const answer=await pc.createAnswer();await pc.setLocalDescription(answer);await gatherIceForShare(pc);
    if(!sendP2PPacket(call.peer,{kind:'voice-answer',callId:call.callId,answer:pc.localDescription.toJSON?.()||pc.localDescription}))throw new Error('O canal de dados P2P foi perdido.');setVoiceStatus('Resposta enviada · aguardando áudio');
  }catch(error){showToast(error.message||'Não foi possível atender.');closeVoiceCall(true);}
}
async function acceptVoiceOffer(){return acceptVoiceCall();}
function declineVoiceCall(){const call=state.voiceCall;if(call?.peer)sendP2PPacket(call.peer,{kind:'voice-decline',callId:call.callId});stopVoiceVibration();closeVoiceCall(false);}
function closeVoiceCall(notify=true){
  const call=state.voiceCall;if(notify&&call?.peer)sendP2PPacket(call.peer,{kind:'voice-end',callId:call.callId});stopVoiceVibration();
  if(call?.localStream)call.localStream.getTracks().forEach(t=>t.stop());if(call?.pc)call.pc.close();const audio=$('#remote-audio');if(audio)audio.srcObject=null;const remoteVideo=$('#remote-video'),localVideo=$('#local-video');if(remoteVideo)remoteVideo.srcObject=null;if(localVideo)localVideo.srcObject=null;$('#video-call-stage').hidden=true;state.voiceCall=null;$('#voice-call-modal').hidden=true;
}
function toggleVoiceMute(){const tracks=state.voiceCall?.localStream?.getAudioTracks()||[];if(!tracks.length)return;const enabled=!tracks[0].enabled;tracks.forEach(t=>t.enabled=enabled);$('#voice-mute').textContent=enabled?'Silenciar':'Ativar microfone';}

// Eventos da interface
document.addEventListener('click',event=>{
  const holderCell=event.target.closest('[data-holder-edit]');if(holderCell){openHolderEditor(holderCell.dataset.holderEdit);return;}
  const page=event.target.closest('[data-page]');if(page){nav(page.dataset.page);return;}
  const choice=event.target.closest('[data-select-miraculous]');if(choice){chooseMiraculous(choice.dataset.selectMiraculous);return;}
  const callContact=event.target.closest('[data-call-contact]');if(callContact){toggleCallSelection(callContact.dataset.callContact);return;}
  const callChoice=event.target.closest('[data-call-miraculous]');if(callChoice){if(state.wheelMoved)return;snapToCallIndex(miraculous.findIndex(m=>m.id===callChoice.dataset.callMiraculous));return;}
  if(event.target.closest('[data-open-custom]')){openCustomCreator();return;}
  if(event.target.closest('#kwami-pet')){openKwamiMenu();return;}
  if(event.target.closest('[data-open-kwami-chat]')){openKwamiChat();return;}
  if(event.target.closest('#kwami-menu-open-chat')){closeKwamiMenu();openKwamiChat();return;}
  if(event.target.closest('#kwami-menu-transform')){toggleKwamiTransformation();closeKwamiMenu();return;}
  if(event.target.closest('#kwami-chat-transform')||event.target.closest('#kwami-panel-transform')||event.target.closest('#kwami-transform-dock')){toggleKwamiTransformation();return;}
  const kwamiFaq=event.target.closest('[data-kwami-faq]');if(kwamiFaq){answerKwamiLore(Number(kwamiFaq.dataset.kwamiFaq));return;}
  const kwamiPreset=event.target.closest('[data-kwami-preset]');if(kwamiPreset){answerKwamiPreset(kwamiPreset.dataset.kwamiPreset);return;}
  if(event.target.closest('#kwami-menu-close')){closeKwamiMenu();return;}
  if(event.target.closest('#kwami-menu-back')){resetKwamiMenuQuestions();return;}
  if(event.target.closest('#kwami-menu-connect')){closeKwamiMenu();nav('contacts');return;}
  if(event.target.id==='kwami-help-modal'){closeKwamiMenu();return;}
  const botQuestion=event.target.closest('[data-bot-question]');if(botQuestion){sendAssistantMessage(botQuestion.dataset.botQuestion);return;}
  const chat=event.target.closest('[data-open-chat]');if(chat){openChat(chat.dataset.openChat);return;}
});
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!$('#kwami-help-modal')?.hidden)closeKwamiMenu();});
$('#open-profile').addEventListener('click',()=>nav('profile'));$('#chat-safety-button')?.addEventListener('click',manageCurrentContactSafety);
$('#open-holder-grid').addEventListener('click',openHolderGridWithRipple);
$('#holder-orientation-retry')?.addEventListener('click',retryHolderLandscape);
$('#holder-editor-close').addEventListener('click',closeHolderEditor);
$('#holder-editor-cancel').addEventListener('click',closeHolderEditor);
$('#holder-editor').addEventListener('click',event=>{if(event.target.id==='holder-editor')closeHolderEditor();});
$('#holder-editor-form').addEventListener('submit',saveHolderEditor);
$('#holder-delete').addEventListener('click',deleteHolderRecord);
$('#holder-photo-input').addEventListener('change',async event=>{const file=event.target.files?.[0];if(!file)return;try{holderPhotoDraft=await compressHolderPhoto(file);$('#holder-photo-preview').src=holderPhotoDraft;$('#holder-editor-status').textContent='Fotografia otimizada e carregada. Confirme para salvar.';}catch(error){event.target.value='';showToast(error.message);}});
// O listener do RESET é registrado no bloco P2P ao final do arquivo.
$('#simulate-incoming').addEventListener('click',simulateLocalIncoming);
$('#stop-alert').addEventListener('click',acknowledgeIncoming);
$('#close-outgoing').addEventListener('click',cancelOutgoing);
$('#send-call-button').addEventListener('click',()=>sendCallAlert(false));
$('#send-all-calls').addEventListener('click',()=>sendCallAlert(true));
$('#multi-call-button').addEventListener('click',toggleMultiCallMode);
let lastCenterTap=0;$('#wheel-center').addEventListener('pointerup',event=>{event.stopPropagation();state.wheelPointer=null;const now=Date.now();if(now-lastCenterTap<360){toggleMultiCallMode();lastCenterTap=0;}else lastCenterTap=now;});
$('#open-custom-creator').addEventListener('click',openCustomCreator);$('#selection-custom-button').addEventListener('click',openCustomCreator);
$('#custom-close').addEventListener('click',closeCustomCreator);$('#custom-miraculous-form').addEventListener('submit',createCustomMiraculous);
$('#custom-icon-file').addEventListener('change',async e=>{const f=e.target.files?.[0];if(!f)return;try{$('#custom-icon-preview').src=await fileToDataUrl(f);$('#custom-icon-preview').hidden=false;}catch(err){showToast(err.message);}});
$('#profile-photo-input').addEventListener('change',async e=>{const f=e.target.files?.[0];if(f)await uploadProfilePhoto(f);e.target.value='';});
$('#start-voice-call').addEventListener('click',()=>startVoiceCall(false));$('#start-video-call')?.addEventListener('click',()=>startVoiceCall(true));$('#voice-answer').addEventListener('click',acceptVoiceCall);$('#voice-decline').addEventListener('click',declineVoiceCall);$('#voice-end').addEventListener('click',()=>closeVoiceCall(true));$('#voice-mute').addEventListener('click',toggleVoiceMute);
$('#contact-search').addEventListener('input',renderContacts);
$('#friend-code-form').addEventListener('submit',event=>{event.preventDefault();addFriendByCode($('#friend-code').value);});
$('#copy-friend-code').addEventListener('click',copyFriendCode);
$('#save-profile').addEventListener('click',updateDisplayName);$('#set-app-pin')?.addEventListener('click',configureAppPin);$('#remove-app-pin')?.addEventListener('click',removeAppPin);$('#lock-app-now')?.addEventListener('click',lockApp);$('#app-pin-form')?.addEventListener('submit',unlockApp);
$('#enable-notifications').addEventListener('click',enableLocalNotifications);$('#toggle-ui-sounds')?.addEventListener('click',()=>setUiSounds(!state.soundEnabled));
$('#message-form').addEventListener('submit',async event=>{event.preventDefault();const input=$('#message-input');const text=input.value.trim();if(!text)return;input.value='';sendTypingState(false);if(state.assistantOpen){sendAssistantMessage(text);return;}await postMessage(text);});
$('#message-input').addEventListener('input',()=>sendTypingState(Boolean($('#message-input').value.trim())));
$('#message-input').addEventListener('blur',()=>sendTypingState(false));
$('#chat-search')?.addEventListener('input',renderMessages);
$('#cancel-reply')?.addEventListener('click',()=>{state.replyTarget=null;updateReplyPreview();});
$('#sticker-button')?.addEventListener('click',()=>{$('#sticker-tray').hidden=!$('#sticker-tray').hidden;$('#emoji-tray').hidden=true;});
$('#sticker-tray')?.addEventListener('click',event=>{
  const custom=event.target.closest('[data-custom-sticker]');
  if(custom){sendCustomSticker(custom.dataset.customSticker).catch(error=>showToast(error.message));return;}
  const button=event.target.closest('[data-sticker]');if(button)sendSticker(button.dataset.sticker);
});
document.addEventListener('click',event=>{const remove=event.target.closest('[data-delete-custom-sticker]');if(remove){deleteCustomSticker(remove.dataset.deleteCustomSticker).catch(error=>showToast(error.message));return;}});
$('#add-custom-sticker')?.addEventListener('click',()=>$('#custom-sticker-file')?.click());
$('#custom-sticker-file')?.addEventListener('change',async event=>{const file=event.target.files?.[0];event.target.value='';try{await addCustomSticker(file);}catch(error){showToast(error.message||'Não foi possível adicionar a figurinha.');}});
document.addEventListener('click',event=>{const action=event.target.closest('[data-message-action]');if(action)handleMessageAction(action);});
$('#file-input')?.addEventListener('change',async event=>{const file=event.target.files?.[0];if(file){const type=file.type.startsWith('video/')?'video':'file';await uploadAndSend(file,type);}event.target.value='';});
$('#emoji-button').addEventListener('click',()=>{$('#emoji-tray').hidden=!$('#emoji-tray').hidden;});
$('#emoji-tray').addEventListener('click',event=>{if(event.target.tagName==='BUTTON'){$('#message-input').value+=event.target.textContent;$('#message-input').focus();}});
$('#photo-input').addEventListener('change',async event=>{const file=event.target.files?.[0];if(file){const type=file.type.startsWith('video/')?'video':'image';await uploadAndSend(file,type);}event.target.value='';});
$('#record-button').addEventListener('click',async()=>{
  if(state.mediaRecorder?.state==='recording'){state.mediaRecorder.stop();$('#record-button').classList.remove('recording');return;}
  if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder){showToast('Gravação de áudio não é suportada neste navegador.');return;}
  try{const stream=await navigator.mediaDevices.getUserMedia({audio:true});state.audioChunks=[];state.mediaRecorder=new MediaRecorder(stream);
    state.mediaRecorder.ondataavailable=event=>{if(event.data.size)state.audioChunks.push(event.data);};
    state.mediaRecorder.onstop=async()=>{const blob=new Blob(state.audioChunks,{type:state.mediaRecorder.mimeType||'audio/webm'});await uploadAndSend(new File([blob],`audio-${Date.now()}.webm`,{type:blob.type}),'audio');stream.getTracks().forEach(track=>track.stop());};
    state.mediaRecorder.start();$('#record-button').classList.add('recording');showToast('Gravando áudio. Toque novamente para parar e enviar.');
  }catch{showToast('Permita o uso do microfone para gravar áudio.');}
});
$('#wheel-prev').addEventListener('click',()=>snapToCallIndex(selectedIndexFromRotation(state.callRotation)-1));
$('#wheel-next').addEventListener('click',()=>snapToCallIndex(selectedIndexFromRotation(state.callRotation)+1));
$('#call-wheel').addEventListener('pointerdown',event=>{state.wheelPointer={x:event.clientX,rotation:state.callRotation,moved:0,pointerId:event.pointerId};$('#call-wheel').setPointerCapture?.(event.pointerId);});
$('#call-wheel').addEventListener('pointermove',event=>{if(!state.wheelPointer||state.wheelPointer.pointerId!==event.pointerId)return;const dx=event.clientX-state.wheelPointer.x;state.wheelPointer.moved=Math.max(state.wheelPointer.moved,Math.abs(dx));if(state.wheelPointer.moved>4)setCallRotation(state.wheelPointer.rotation+dx*.72,false);});
$('#call-wheel').addEventListener('pointerup',event=>{if(!state.wheelPointer||state.wheelPointer.pointerId!==event.pointerId)return;const moved=state.wheelPointer.moved;state.wheelPointer=null;if(moved>8){state.wheelMoved=true;snapToCallIndex(selectedIndexFromRotation(state.callRotation));setTimeout(()=>state.wheelMoved=false,180);}});
$('#call-wheel').addEventListener('pointercancel',()=>{state.wheelPointer=null;});
$('#wheel-center').addEventListener('dblclick',event=>{event.preventDefault();toggleMultiCallMode();});
$('#wheel-center').addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();toggleMultiCallMode();}});

let deferredInstallPrompt=null;
window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();deferredInstallPrompt=event;$('#install-app').hidden=false;});
$('#install-app').addEventListener('click',async()=>{
  if(!deferredInstallPrompt)return;
  deferredInstallPrompt.prompt();
  await deferredInstallPrompt.userChoice;
  deferredInstallPrompt=null;$('#install-app').hidden=true;
});
window.addEventListener('appinstalled',()=>{deferredInstallPrompt=null;$('#install-app').hidden=true;showToast('Mirafriends instalado neste aparelho.');});

async function boot(){
  $('#holder-editor').hidden=true;$('#identity-loader').hidden=true;$('#holder-note-modal').hidden=true;$('#connection-setup').hidden=true;$('#miraculous-awakening').hidden=true;
  const local=makeLocalIdentity();state.user={...local};state.profile={name:local.name,miraculousId:local.miraculousId,friendCode:local.friendCode,avatarData:local.avatarData,uid:local.uid};
  state.contacts=readLocalContacts();
  try{state.blockedContacts=JSON.parse(localStorage.getItem('mirafriends-blocked-v1')||'[]');if(!Array.isArray(state.blockedContacts))state.blockedContacts=[];}catch{state.blockedContacts=[];}
  normalizeContactUniverses(state.contacts);
  state.customMiraculous=readLocalCustomMiraculous();miraculous.splice(0,miraculous.length,...baseMiraculous,...state.customMiraculous);
  normalizeContactUniverses(state.contacts);rebuildMiraculousOwners();
  await loadFeatureStores();await renderCustomStickers();state.kwamiTransformed=false;document.documentElement.classList.remove('kwami-transformed');setTheme(state.profile.miraculousId);persistLocalState();buildWheel();renderAll();renderGroups();renderMoments();renderPosts();renderAlbum();updateKwamiTransformControls();setConnectionStatus('P2P · PRONTO',false);
  if(!state.profile.miraculousId)renderSelection();else $('#selection-modal').hidden=true;
  if(!window.__mirafriendsMiraGamesReady){
    initMiraGames({miraculous,kwamiByMiraculous:KWAMI_BY_MIRACULOUS,initialMiraculousId:state.profile.miraculousId});
    window.__mirafriendsMiraGamesReady=true;
  }
  if('serviceWorker'in navigator)navigator.serviceWorker.register('./service-worker.js',{updateViaCache:'none'}).catch(()=>{});
  document.body.classList.add('app-ready');
  const groupInviteParam=new URLSearchParams(location.search).get('groupInvite');if(groupInviteParam){const field=$('#group-invite-code');if(field)field.value=groupInviteParam.startsWith('MIRAFRIENDS-GROUP1.')?groupInviteParam:`MIRAFRIENDS-GROUP1.${groupInviteParam}`;activatePage('groups','groups');}
  if(location.protocol==='file:')showToast('Para usar WebRTC, abra o Mirafriends por HTTPS ou localhost. O perfil local ainda funciona.');if(localStorage.getItem(APP_PIN_KEY))lockApp();
  initializeNetworkSocial().catch(error=>{console.warn('Rede online indisponível:',error);setNetworkStatus('SERVIDOR INDISPONÍVEL',false);});
}
function openConnectionSetup(){const modal=$('#connection-setup');if(modal)modal.hidden=false;}
$('#open-connection-setup')?.addEventListener('click',openConnectionSetup);
$('#connection-setup-close')?.addEventListener('click',()=>$('#connection-setup').hidden=true);
// Identidade e backups são locais; a sinalização inicial é feita por troca manual P2P.

function openHolderNote(id){
  const m=getMiraculous(id);const custom=holderCustomSlots.find(s=>s.id===id);if(!m&&!custom)return;
  selectedHolderNoteId=id;const record=holderRecords[id]||{};
  $('#holder-note-title').textContent=`Nota · ${m?.name||'? Slot adicional'}`;
  $('#holder-note-hint').textContent=`Anotações pessoais sobre ${m?.name||'este slot'}. O texto fica salvo somente neste aparelho.`;
  $('#holder-note-text').value=record.note||'';$('#holder-note-modal').hidden=false;
}
function saveHolderNote(){
  if(!selectedHolderNoteId)return;const id=selectedHolderNoteId;const record=holderRecords[id]||{};record.note=$('#holder-note-text').value.slice(0,5000);record.noteUpdatedAt=Date.now();holderRecords[id]=record;
  if(saveHolderRecords()){closeHolderNote();showToast('Nota salva neste aparelho.');}
}
function closeHolderNote(){ $('#holder-note-modal').hidden=true;selectedHolderNoteId=null; }
function addCustomHolderSlot(){
  if(holderCustomSlots.length>=30){showToast('Limite de 30 slots adicionais atingido.');return;}
  const id=`slot-${randomLocalId()}`;holderCustomSlots.push({id,name:'Slot adicional',createdAt:Date.now()});
  if(!saveHolderCustomSlots()){holderCustomSlots.pop();return;}renderHolderGrid();showToast('Slot adicional criado com símbolo ?. Toque na fotografia para cadastrar o portador.');
}
function profileForP2P(){return {uid:state.user.uid,code:state.profile.friendCode,friendCode:state.profile.friendCode,name:state.profile.name,about:state.profile.about||'',miraculousId:state.profile.miraculousId,avatarData:state.profile.avatarData||null};}
function createPC(){return new RTCPeerConnection({iceServers:getP2PIceServers(),iceCandidatePoolSize:6,bundlePolicy:'max-bundle',rtcpMuxPolicy:'require',iceTransportPolicy:'all'});}
function bindPeerConnection(peer,pc){
  peer.pc=pc;
  pc.onconnectionstatechange=()=>{
    setP2PConnectionState(peer);
    if(pc.connectionState==='connected'){setP2PStatus(`Conectado diretamente com ${peer.peerName||'o portador'}.`,true);}
    else if(pc.connectionState==='failed'){setP2PStatus('A rede bloqueou o caminho direto. Tente novamente em outra rede; algumas exigem TURN.',false);showToast('Não foi possível abrir o P2P direto nesta rede.');}
    else if(pc.connectionState==='disconnected'){setP2PStatus('Conexão instável. O navegador está tentando recuperar o caminho P2P; mantenha os dois aparelhos abertos.',false);}
  };
  pc.oniceconnectionstatechange=()=>{
    setP2PConnectionState(peer);
    if(pc.iceConnectionState==='checking')setP2PStatus('Testando caminhos de conexão entre os dois aparelhos…',false);
    if(pc.iceConnectionState==='failed')setP2PStatus('Nenhum caminho direto encontrado nesta rede. Gere novos convites ou teste outra rede.',false);
  };
}
function currentPeerIdentity(){const p=profileForP2P();return {...p,avatarData:null};}
async function createP2PInvite(){
  const button=$('#p2p-create-invite');
  if(!window.RTCPeerConnection){showToast('Este navegador não oferece WebRTC. Atualize o navegador ou abra o Mirafriends em outro navegador compatível.');return;}
  if(!window.isSecureContext){setP2PStatus('Abra o Mirafriends por HTTPS ou localhost para usar a conexão P2P.',false);showToast('A conexão P2P precisa de um contexto seguro (HTTPS/localhost).');return;}
  if(!navigator.onLine){setP2PStatus('Sem internet. Conecte-se à internet antes de gerar o convite P2P.',false);showToast('Conecte-se à internet para criar o convite.');return;}
  if(button){button.disabled=true;button.textContent='Preparando convite…';}
  $('#p2p-invite-output').value='';
  let handshakeId=null;let peer=null;
  try{
    for(const oldPeer of pendingP2PHandshakes.values())oldPeer.pc?.close();pendingP2PHandshakes.clear();
    handshakeId=randomLocalId();peer={handshakeId,friendshipId:null,peerUid:null,peerName:'Novo portador',miraculousId:null,pc:null,channel:null,incomingMediaTransfer:null};
    const pc=createPC();bindPeerConnection(peer,pc);
    peer.channel=pc.createDataChannel('mirafriends-direct',{ordered:true});attachChatDataChannel(peer,peer.channel);
    pendingP2PHandshakes.set(handshakeId,peer);
    setP2PStatus('Preparando a conexão e procurando caminhos na internet… mantenha esta tela aberta.',false);
    const offer=await pc.createOffer();await pc.setLocalDescription(offer);
    if(!pc.localDescription?.sdp)throw new Error('O navegador não gerou a descrição da conexão. Tente novamente.');
    const ice=await gatherIceForShare(pc,26000);
    if(!Object.values(ice.counts).some(count=>count>0))throw new Error('Nenhum candidato ICE foi encontrado. Confira a internet, permissões de rede e VPN; sem candidatos, este convite não conseguirá conectar.');
    const code=await encodeP2PCode({v:1,type:'offer',handshakeId,createdAt:Date.now(),peer:currentPeerIdentity(),description:pc.localDescription.toJSON?.()||pc.localDescription});
    if(code.length>160000)throw new Error('O convite ficou grande demais para compartilhar. Gere outro convite ou desative redes/VPN muito complexas e tente novamente.');
    $('#p2p-invite-output').value=code;
    const iceHint=iceSummaryText(ice);
    await autoCopyP2PCode(code,'Convite P2P');
    setP2PStatus(`CONVITE PRONTO. Copie/compartilhe o bloco completo. ${iceHint} Depois mantenha esta página aberta para receber a resposta.`,false);
    showToast('Convite gerado! Agora toque em Copiar ou Compartilhar.');
  }catch(error){
    if(handshakeId)pendingP2PHandshakes.delete(handshakeId);peer?.pc?.close();
    const message=error?.message||'Erro desconhecido';setP2PStatus(`Não foi possível gerar o convite: ${message}`,false);showToast(`Falha ao criar convite: ${message}`);
  }finally{if(button){button.disabled=false;button.textContent='① Criar meu convite';}}
}
async function acceptP2PInvite(rawCode=null){
  const button=$('#p2p-accept-invite');let peer=null;
  try{
    const invite=await decodeP2PCode(rawCode??$('#p2p-invite-input').value);if(invite.type!=='offer')throw new Error('Este código é uma resposta. Para concluir sua conexão, quem criou o convite deve processá-lo.');
    if(invite.peer.uid===state.user.uid)throw new Error('Esse convite foi criado pelo próprio aparelho.');
    if(!confirm(`Emparelhar com ${invite.peer.name||'Portador'} · ${invite.peer.code||'sem Miracode'}? Confirme esse código com a pessoa por outro canal antes de confiar.`))return;
    if(button){button.disabled=true;button.textContent='Gerando resposta…';}
    setP2PStatus('Convite reconhecido. Preparando a resposta e procurando caminhos de rede…',false);
    const friendshipId=getP2PFriendshipId(invite.peer.uid);peer={handshakeId:invite.handshakeId,friendshipId,peerUid:invite.peer.uid,peerName:invite.peer.name||'Portador',miraculousId:invite.peer.miraculousId||null,peerProfile:invite.peer,pc:null,channel:null,incomingMediaTransfer:null};
    const pc=createPC();bindPeerConnection(peer,pc);pc.ondatachannel=event=>attachChatDataChannel(peer,event.channel);
    await pc.setRemoteDescription(new RTCSessionDescription(invite.description));
    const answer=await pc.createAnswer();await pc.setLocalDescription(answer);
    if(!pc.localDescription?.sdp)throw new Error('O navegador não gerou a resposta da conexão. Tente novamente.');
    const ice=await gatherIceForShare(pc,26000);
    if(!Object.values(ice.counts).some(count=>count>0))throw new Error('Nenhum caminho de rede foi encontrado neste aparelho. Verifique a internet/VPN e tente gerar outra resposta.');
    const code=await encodeP2PCode({v:1,type:'answer',handshakeId:invite.handshakeId,createdAt:Date.now(),peer:currentPeerIdentity(),description:pc.localDescription.toJSON?.()||pc.localDescription});
    if(code.length>160000)throw new Error('A resposta ficou grande demais para compartilhar. Gere um convite novo e tente novamente.');
    p2pPeers.set(friendshipId,peer);saveP2PContact(invite.peer,friendshipId);
    $('#p2p-answer-output').value=code;
    await autoCopyP2PCode(code,'Resposta P2P');
    setP2PStatus(`RESPOSTA PRONTA. Compartilhe de volta com quem criou o convite. ${iceSummaryText(ice)} Aguarde a outra pessoa concluir, mantendo o app aberto.`,false);
    showToast('Resposta gerada! Copie e envie para quem criou o convite.');
  }catch(error){
    peer?.pc?.close();const message=error?.message||'Erro desconhecido';$('#p2p-status').textContent=message;showToast(message);
  }finally{if(button){button.disabled=false;button.textContent='② Aceitar convite e gerar resposta';}}
}
function waitForDataChannelOpen(peer,timeout=18000){
  if(peer?.channel?.readyState==='open')return Promise.resolve(true);
  if(!peer?.channel)return Promise.resolve(false);
  return new Promise(resolve=>{
    let done=false;const channel=peer.channel;let timer=null;
    const finish=value=>{if(done)return;done=true;channel.removeEventListener('open',onOpen);channel.removeEventListener('close',onClose);peer.pc?.removeEventListener('connectionstatechange',onState);if(timer)clearTimeout(timer);resolve(value);};
    const onOpen=()=>finish(true);const onClose=()=>finish(false);const onState=()=>{if(peer.pc?.connectionState==='failed'||peer.pc?.connectionState==='closed')finish(false);};
    channel.addEventListener('open',onOpen);channel.addEventListener('close',onClose);peer.pc?.addEventListener('connectionstatechange',onState);timer=setTimeout(()=>finish(channel.readyState==='open'),timeout);onState();
  });
}
async function finishP2PConnection(rawCode=null){
  const button=$('#p2p-finish-connect');
  try{
    const answer=await decodeP2PCode(rawCode??$('#p2p-answer-input').value);if(answer.type!=='answer')throw new Error('Este código é um convite. Cole a resposta gerada pelo outro aparelho.');
    const peer=pendingP2PHandshakes.get(answer.handshakeId);if(!peer?.pc)throw new Error('Este aparelho não tem o convite correspondente aberto. Gere um convite novo nesta mesma aba e troque os códigos novamente.');
    if(answer.peer.uid===state.user.uid)throw new Error('A resposta pertence ao próprio aparelho.');
    if(!confirm(`Concluir conexão com ${answer.peer.name||'Portador'} · ${answer.peer.code||'sem Miracode'}? Compare o Miracode com a pessoa antes de aceitar.`))return;
    if(button){button.disabled=true;button.textContent='Testando conexão…';}
    setP2PStatus(`Resposta reconhecida. Testando o caminho até ${answer.peer.name||'o outro portador'}…`,false);
    await peer.pc.setRemoteDescription(new RTCSessionDescription(answer.description));peer.friendshipId=getP2PFriendshipId(answer.peer.uid);peer.peerUid=answer.peer.uid;peer.peerName=answer.peer.name||'Portador';peer.miraculousId=answer.peer.miraculousId||null;peer.peerProfile=answer.peer;
    p2pPeers.set(peer.friendshipId,peer);saveP2PContact(answer.peer,peer.friendshipId);pendingP2PHandshakes.delete(answer.handshakeId);
    const opened=await waitForDataChannelOpen(peer,45000);
    if(opened){setP2PStatus(`Conectado com ${peer.peerName}! A conversa já pode ser aberta em Mensagens.`,true);showToast('Conexão P2P estabelecida!');}
    else if(peer.pc.connectionState==='failed'||peer.pc.iceConnectionState==='failed'){
      setP2PStatus('Os códigos foram aceitos, mas as redes não encontraram um caminho. Teste outra rede ou configure TURN nos dois aparelhos; STUN sozinho não atravessa todos os NATs/firewalls.',false);
      showToast('A rede bloqueou a conexão direta. Pode ser necessário TURN.');
    }else{
      setP2PStatus('Resposta aplicada. A conexão ainda está sendo testada. Mantenha os dois aparelhos com esta página aberta; se não conectar, configure TURN nos dois aparelhos ou tente outra rede.',false);
      showToast('A negociação foi concluída; aguardando o canal P2P abrir.');
    }
  }catch(error){const message=error?.message||'Erro desconhecido';$('#p2p-status').textContent=message;showToast(message);}
  finally{if(button){button.disabled=false;button.textContent='③ Concluir conexão P2P';}}
}
async function processP2PCode(){
  const value=$('#p2p-any-code-input')?.value?.trim();const button=$('#p2p-process-code');
  if(!value){showToast('Cole primeiro o código que recebeu.');return;}
  if(button){button.disabled=true;button.textContent='Identificando código…';}
  try{
    const decoded=await decodeP2PCode(value);
    if(decoded.type==='offer'){
      $('#p2p-invite-input').value=value;
      await acceptP2PInvite(value);
    }else{
      $('#p2p-answer-input').value=value;
      await finishP2PConnection(value);
    }
  }catch(error){$('#p2p-status').textContent=error.message;showToast(error.message);}
  finally{if(button){button.disabled=false;button.textContent='② Processar código automaticamente';}}
}
async function diagnoseP2PNetwork(){
  const button=$('#p2p-network-test');const result=$('#p2p-network-result');
  if(!window.RTCPeerConnection){if(result)result.textContent='Este navegador não oferece WebRTC.';return;}
  if(!navigator.onLine){if(result)result.textContent='Sem internet. Conecte-se e tente novamente.';return;}
  if(button){button.disabled=true;button.textContent='Testando…';}if(result)result.textContent='Consultando STUN/TURN e reunindo candidatos de rede…';
  let pc=null;
  try{
    pc=createPC();pc.createDataChannel('mirafriends-network-test');
    const offer=await pc.createOffer();await pc.setLocalDescription(offer);
    const report=await gatherIceForShare(pc,12000);const c=report.counts;
    const parts=[`caminhos públicos: ${c.srflx}`,`relay TURN: ${c.relay}`,`locais: ${c.host}`];
    if(result)result.textContent=`Teste local concluído (${parts.join(' · ')}). ${c.relay?'TURN respondeu; isso pode ajudar em redes restritivas.':c.srflx?'STUN respondeu. A conexão entre redes diferentes pode funcionar, mas o teste não garante conexão com o outro aparelho.':'Nenhum caminho público apareceu. Verifique a rede ou configure TURN nos dois aparelhos.'}`;
  }catch(error){if(result)result.textContent=`Não foi possível testar esta rede: ${error.message}`;}
  finally{pc?.close();if(button){button.disabled=false;button.textContent='Verificar minha rede';}}
}
async function copyTextFrom(selector){
  const text=$(selector)?.value||'';if(!text){showToast('Não há código para copiar.');return;}
  try{await navigator.clipboard.writeText(text);showToast('Código copiado.');}catch{const el=$(selector);el.focus();el.select();showToast('Selecione e copie o texto manualmente.');}
}
async function autoCopyP2PCode(code,label){
  try{if(!navigator.clipboard?.writeText)throw new Error('Área de transferência indisponível');await navigator.clipboard.writeText(code);showToast(`${label} gerado e copiado. Agora compartilhe com o outro aparelho.`);return true;}
  catch{showToast(`${label} gerado. Toque em Copiar para enviar ao outro aparelho.`);return false;}
}
function createP2PQr(){
  const invite=$('#p2p-invite-output')?.value.trim()||'';const answer=$('#p2p-answer-output')?.value.trim()||'';const code=answer||invite;
  if(!code){showToast('Primeiro crie um convite ou processe um convite recebido para gerar sua resposta.');return;}
  try{
    if(!window.MirafriendsQRCode||!window.MirafriendsQRErrorLevel)throw new Error('O gerador local de QR Code não carregou.');
    const qr=new window.MirafriendsQRCode(0,window.MirafriendsQRErrorLevel.M);qr.addData(code);qr.make();
    const canvas=$('#p2p-qr-canvas');const ctx=canvas.getContext('2d');const count=qr.getModuleCount();const quiet=4;const unit=Math.floor(canvas.width/(count+quiet*2));const real=unit*(count+quiet*2);const offset=Math.floor((canvas.width-real)/2);
    ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.fillStyle='#101018';
    for(let row=0;row<count;row++)for(let col=0;col<count;col++)if(qr.isDark(row,col))ctx.fillRect(offset+(col+quiet)*unit,offset+(row+quiet)*unit,unit,unit);
    $('#p2p-qr-preview').hidden=false;$('#p2p-qr-caption').textContent=answer?'QR Code da sua resposta P2P. Envie de volta para quem criou o convite.':'QR Code do seu convite P2P. A outra pessoa deve ler e enviar uma resposta.';
  }catch(error){const detail=/overflow|code length|too long/i.test(error.message||'')?'O código ficou grande demais para caber em um QR. Use Copiar/Compartilhar ou o campo manual.':(error.message||'Não foi possível gerar o QR Code.');showToast(detail);}
}
function downloadP2PQr(){
  const canvas=$('#p2p-qr-canvas');if(!canvas||$('#p2p-qr-preview').hidden)return;
  const link=document.createElement('a');link.href=canvas.toDataURL('image/png');link.download='mirafriends-p2p-qr.png';link.click();
}
let p2pQrStream=null,p2pQrFrame=0,p2pQrDetector=null,p2pQrScanActive=false;
function stopP2PQrScanner(){
  p2pQrScanActive=false;if(p2pQrFrame)cancelAnimationFrame(p2pQrFrame);p2pQrFrame=0;
  if(p2pQrStream){p2pQrStream.getTracks().forEach(track=>track.stop());p2pQrStream=null;}
  const video=$('#p2p-qr-video');if(video)video.srcObject=null;
  const panel=$('#p2p-qr-scanner');if(panel)panel.hidden=true;
}
function acceptScannedP2PCode(value){
  const raw=String(value||'').trim();if(!raw)return false;
  if(!/^MIRAFRIENDS-P2P[12]\./.test(raw)){showToast('Este QR não contém um convite ou resposta P2P do Mirafriends.');return false;}
  $('#p2p-any-code-input').value=raw;stopP2PQrScanner();processP2PCode().catch(error=>showToast(error.message));return true;
}
async function startP2PQrScanner(){
  if(!('BarcodeDetector'in window)){showToast('Este navegador não oferece leitura QR nativa. Use uma imagem com suporte a BarcodeDetector ou cole o código manualmente.');return;}
  if(!navigator.mediaDevices?.getUserMedia){showToast('A câmera exige HTTPS e permissão do navegador.');return;}
  try{
    const formats=await window.BarcodeDetector.getSupportedFormats?.();if(formats&&!formats.includes('qr_code'))throw new Error('Este navegador não oferece o formato QR Code.');
    p2pQrDetector=new window.BarcodeDetector({formats:['qr_code']});p2pQrStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'}},audio:false});
    const video=$('#p2p-qr-video');video.srcObject=p2pQrStream;$('#p2p-qr-scanner').hidden=false;$('#p2p-qr-scan-status').textContent='Aponte a câmera para o QR Code do Mirafriends.';await video.play();p2pQrScanActive=true;
    const scan=async()=>{if(!p2pQrScanActive)return;try{const results=await p2pQrDetector.detect(video);const found=results.find(result=>result.rawValue);if(found){acceptScannedP2PCode(found.rawValue);return;}}catch(error){$('#p2p-qr-scan-status').textContent='Não foi possível ler o QR Code. Ajuste a câmera e tente novamente.';}p2pQrFrame=requestAnimationFrame(scan);};p2pQrFrame=requestAnimationFrame(scan);
  }catch(error){stopP2PQrScanner();showToast(`Não foi possível iniciar o leitor: ${error.message}`);}
}
async function scanP2PQrImage(file){
  if(!file)return;if(!('BarcodeDetector'in window)){showToast('Seu navegador não consegue ler QR de imagem. Cole o código de conexão manualmente.');return;}
  try{const detector=new window.BarcodeDetector({formats:['qr_code']});const bitmap=await createImageBitmap(file);const results=await detector.detect(bitmap);bitmap.close?.();const found=results.find(result=>result.rawValue);if(!found)throw new Error('Nenhum QR Code foi encontrado nesta imagem.');acceptScannedP2PCode(found.rawValue);}
  catch(error){showToast(error.message||'Não foi possível ler esta imagem.');}
}

async function shareTextFrom(selector,title){
  const text=$(selector)?.value||'';if(!text){showToast('Não há código para compartilhar.');return;}
  if(navigator.share){try{await navigator.share({title,text});return;}catch(error){if(error?.name==='AbortError')return;}}
  await copyTextFrom(selector);
}
const APP_PIN_KEY='mirafriends-local-pin-v1';
function bytesToB64(bytes){let binary='';for(const byte of bytes)binary+=String.fromCharCode(byte);return btoa(binary);}
function b64ToBytes(value){return Uint8Array.from(atob(value),char=>char.charCodeAt(0));}
async function hashAppPin(pin,salt){
  if(!crypto.subtle)throw new Error('A proteção por PIN exige HTTPS e Web Crypto.');
  const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(pin),'PBKDF2',false,['deriveBits']);
  return new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',salt,iterations:180000,hash:'SHA-256'},key,256));
}
async function verifyAppPin(pin){
  let saved;try{saved=JSON.parse(localStorage.getItem(APP_PIN_KEY)||'null');}catch{return false;}
  if(!saved?.salt||!saved?.hash)return false;
  try{const actual=await hashAppPin(pin,b64ToBytes(saved.salt));const expected=b64ToBytes(saved.hash);return actual.length===expected.length&&actual.every((value,index)=>value===expected[index]);}catch{return false;}
}
async function configureAppPin(){
  const existing=localStorage.getItem(APP_PIN_KEY);if(existing){const current=prompt('Digite o PIN atual para alterar a proteção:','');if(current===null)return;if(!await verifyAppPin(current)){showToast('PIN atual incorreto.');return;}}
  const pin=prompt('Crie um PIN local de 6 a 12 números:','');if(pin===null)return;if(!/^\d{6,12}$/.test(pin)){showToast('O PIN precisa ter de 6 a 12 números.');return;}
  const confirmPin=prompt('Digite o PIN novamente:','');if(confirmPin!==pin){showToast('Os PINs não coincidem.');return;}
  try{const salt=crypto.getRandomValues(new Uint8Array(16));const hash=await hashAppPin(pin,salt);localStorage.setItem(APP_PIN_KEY,JSON.stringify({salt:bytesToB64(salt),hash:bytesToB64(hash),iterations:180000,createdAt:Date.now()}));showToast('PIN local configurado. Ele protege a abertura deste aplicativo neste aparelho.');}
  catch(error){showToast(error.message||'Não foi possível configurar o PIN.');}
}
function lockApp(){if(!localStorage.getItem(APP_PIN_KEY))return;const overlay=$('#app-pin-lock');if(overlay){overlay.hidden=false;$('#app-pin-input').value='';$('#app-pin-error').textContent='';setTimeout(()=>$('#app-pin-input').focus(),50);}}
async function unlockApp(event){event?.preventDefault();const pin=$('#app-pin-input').value;if(!await verifyAppPin(pin)){$('#app-pin-error').textContent='PIN incorreto. Tente novamente.';$('#app-pin-input').value='';return;}$('#app-pin-lock').hidden=true;$('#app-pin-error').textContent='';}
function removeAppPin(){if(!localStorage.getItem(APP_PIN_KEY)){showToast('Nenhum PIN está configurado.');return;}const pin=prompt('Digite o PIN atual para remover a proteção:','');if(pin===null)return;verifyAppPin(pin).then(valid=>{if(!valid){showToast('PIN incorreto.');return;}localStorage.removeItem(APP_PIN_KEY);$('#app-pin-lock').hidden=true;showToast('Proteção por PIN removida.');});}

async function sendLocalBackup(){
  try{
    const messages=await idbStoreAction('messages','readonly',store=>store.getAll()).catch(()=>[]);
    const album=await idbStoreAction('album','readonly',store=>store.getAll()).catch(()=>[]);
    const stickers=await idbStoreAction('stickers','readonly',store=>store.getAll()).catch(()=>[]);
    const stickerExport=[];for(const item of stickers||[]){if(item?.blob)stickerExport.push({id:item.id,name:item.name,createdAt:item.createdAt,mimeType:item.mimeType,dataUrl:await blobToDataUrl(item.blob)});}
    const albumExport=[];for(const item of album||[]){if(item?.blob)albumExport.push({id:item.id,name:item.name,createdAt:item.createdAt,mimeType:item.mimeType,dataUrl:await blobToDataUrl(item.blob)});}
    const posts=await idbStoreAction('posts','readonly',store=>store.getAll()).catch(()=>state.posts||[]);
    const backup={format:'MIRAFRIENDS-P2P-BACKUP',version:4,createdAt:new Date().toISOString(),profile:profileForP2P(),contacts:state.contacts,groups:state.groups,moments:state.moments,posts:posts||[],customMiraculous:state.customMiraculous,holderRecords,holderCustomSlots,messages:messages||[],album:albumExport,stickers:stickerExport};
    const blob=new Blob([JSON.stringify(backup)],{type:'application/json'});if(blob.size>50*1024*1024)throw new Error('O backup passou de 50 MB. Exclua mídias grandes do álbum/conversas e tente novamente.');const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`mirafriends-backup-${Date.now()}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);showToast('Backup exportado com conversas e mídias incluídas quando armazenadas localmente. Guarde em local seguro.');
  }catch(error){showToast(`Não foi possível criar o backup: ${error.message}`);}
}
async function restoreLocalBackup(file){
  try{
    if(!file||file.size>50*1024*1024)throw new Error('O arquivo de backup excede 50 MB.');const data=JSON.parse(await file.text());
    if(data.format!=='MIRAFRIENDS-P2P-BACKUP'||![1,2,3,4].includes(data.version)||!data.profile?.uid)throw new Error('Este não é um backup compatível do Mirafriends.');
    profileFromUser(data.profile);state.contacts=Array.isArray(data.contacts)?data.contacts:[];state.customMiraculous=Array.isArray(data.customMiraculous)?data.customMiraculous:[];miraculous.splice(0,miraculous.length,...baseMiraculous,...state.customMiraculous);
    holderRecords=data.holderRecords&&typeof data.holderRecords==='object'?data.holderRecords:{};holderCustomSlots=Array.isArray(data.holderCustomSlots)?data.holderCustomSlots:[];
    state.groups=Array.isArray(data.groups)?data.groups:[];state.moments=Array.isArray(data.moments)?data.moments:[];state.posts=Array.isArray(data.posts)?data.posts.filter(post=>post?.visibility==='friends'):[];
    for(const group of state.groups)await idbStoreAction('groups','readwrite',store=>store.put(group));for(const moment of state.moments)await idbStoreAction('moments','readwrite',store=>store.put(moment));for(const post of state.posts)await idbStoreAction('posts','readwrite',store=>store.put(post));
    saveHolderRecords();saveHolderCustomSlots();persistLocalState();
    for(const message of (Array.isArray(data.messages)?data.messages:[]))await cacheMessage(message);
    if(Array.isArray(data.album)){for(const item of data.album){if(!item?.id||typeof item.dataUrl!=='string'||!item.dataUrl.startsWith('data:image/'))continue;const response=await fetch(item.dataUrl);const blob=await response.blob();await idbStoreAction('album','readwrite',store=>store.put({id:item.id,name:String(item.name||'Foto restaurada'),createdAt:Number(item.createdAt)||Date.now(),mimeType:item.mimeType||blob.type,blob}));}}
    if(Array.isArray(data.stickers)){for(const item of data.stickers){if(!item?.id||typeof item.dataUrl!=='string'||!/^data:image\/(?:webp|jpeg|png);base64,/i.test(item.dataUrl))continue;const response=await fetch(item.dataUrl);const blob=await response.blob();await idbStoreAction('stickers','readwrite',store=>store.put({id:item.id,name:String(item.name||'Figurinha restaurada').slice(0,80),createdAt:Number(item.createdAt)||Date.now(),mimeType:item.mimeType||blob.type,blob}));}}
    normalizeContactUniverses(state.contacts);rebuildMiraculousOwners();
    renderAll();renderGroups();renderMoments();renderPosts();renderAlbum();renderCustomStickers();renderGroupMemberPicker();if(!state.profile.miraculousId)renderSelection();showToast('Backup restaurado. Emparelhe novamente seus contatos para abrir canais WebRTC.');
  }catch(error){showToast(`Falha ao restaurar backup: ${error.message}`);}
}



$('#group-create-form')?.addEventListener('submit',createGroup);
$('#group-message-form')?.addEventListener('submit',sendGroupMessage);
$('#moment-form')?.addEventListener('submit',publishMoment);
$('#post-form')?.addEventListener('submit',publishPost);
$('#post-visibility')?.addEventListener('change',()=>{const button=$('#post-form button[type=submit]');if(button)button.textContent=$('#post-visibility').value==='public'?'Publicar publicamente':'Publicar para meus amigos';});
document.addEventListener('click',event=>{const action=event.target.closest('[data-post-react],[data-post-comment],[data-post-server-react],[data-post-server-comment],[data-post-server-delete]');if(action)handlePostAction(action);});
$('#group-kwami-talk')?.addEventListener('click',startGroupKwamiConversation);
$('#refresh-moments')?.addEventListener('click',renderMoments);document.addEventListener('click',event=>{const action=event.target.closest('[data-moment-react],[data-moment-comment]');if(action)handleMomentAction(action);});
$('#camera-start')?.addEventListener('click',()=>cameraStream?stopCamera():startCamera());
$('#camera-switch')?.addEventListener('click',switchCamera);
$('#camera-capture')?.addEventListener('click',capturePhoto);
$('#media-import-input')?.addEventListener('change',importAlbumPhotos);
$('#album-send-selected')?.addEventListener('click',sendSelectedAlbumPhoto);
$('#album-delete-selected')?.addEventListener('click',deleteSelectedAlbumPhoto);
$('#open-chat-media')?.addEventListener('click',()=>{if(!state.activeContact){showToast('Abra uma conversa com outro portador para enviar uma foto.');return;}state.mediaPickerMode=true;state.selectedAlbumId=null;nav('media');});
document.addEventListener('click',event=>{const album=event.target.closest('[data-album-select]');if(album){state.selectedAlbumId=album.dataset.albumSelect;if(state.mediaPickerMode){sendSelectedAlbumPhoto().catch(error=>showToast(error.message));}else renderAlbum();return;}});
document.addEventListener('click',event=>{const link=event.target.closest('[data-group-link]');if(link){shareGroupInviteLink(link.dataset.groupLink);return;}const approve=event.target.closest('[data-community-approve]');if(approve){decideCommunityRequest(approve.dataset.communityApprove,approve.dataset.communityMember,true).catch(error=>showToast(error.message));return;}const reject=event.target.closest('[data-community-reject]');if(reject){decideCommunityRequest(reject.dataset.communityReject,reject.dataset.communityMember,false).catch(error=>showToast(error.message));return;}const manage=event.target.closest('[data-manage-group]');if(manage){manageGroupRoles(manage.dataset.manageGroup);return;}const accept=event.target.closest('[data-accept-group]');if(accept){acceptGroupInvite(accept.dataset.acceptGroup).catch(error=>showToast(error.message));return;}const invite=event.target.closest('[data-invite-group]');if(invite){inviteGroupMembers(invite.dataset.inviteGroup).catch(error=>showToast(error.message));return;}const open=event.target.closest('[data-open-group]');if(open){openGroupChat(open.dataset.openGroup);return;}});
$('#group-join-invite')?.addEventListener('click',()=>importGroupInviteCode().catch(error=>showToast(error.message)));
$('#p2p-show-qr')?.addEventListener('click',createP2PQr);$('#p2p-download-qr')?.addEventListener('click',downloadP2PQr);
$('#p2p-start-qr-scan')?.addEventListener('click',startP2PQrScanner);$('#p2p-stop-qr-scan')?.addEventListener('click',stopP2PQrScanner);
$('#p2p-qr-image-input')?.addEventListener('change',event=>{const file=event.target.files?.[0];if(file)scanP2PQrImage(file);event.target.value='';});
$('#holder-add-slot')?.addEventListener('click',addCustomHolderSlot);
document.addEventListener('click',event=>{const note=event.target.closest('[data-holder-note]');if(note){openHolderNote(note.dataset.holderNote);return;}});
$('#holder-note-close')?.addEventListener('click',closeHolderNote);$('#holder-note-cancel')?.addEventListener('click',closeHolderNote);$('#holder-note-save')?.addEventListener('click',saveHolderNote);
$('#holder-note-modal')?.addEventListener('click',event=>{if(event.target.id==='holder-note-modal')closeHolderNote();});
$('#holder-grid-reset')?.addEventListener('click',()=>{if(!Object.keys(holderRecords).length&&!holderCustomSlots.length){showToast('A grade já está vazia.');return;}if(confirm('Apagar todos os cadastros, notas e slots adicionais deste aparelho?')){holderRecords={};holderCustomSlots=[];saveHolderRecords();saveHolderCustomSlots();renderHolderGrid();showToast('Grade restaurada.');}});
$('#p2p-create-invite')?.addEventListener('click',createP2PInvite);
$('#p2p-copy-invite')?.addEventListener('click',()=>copyTextFrom('#p2p-invite-output'));
$('#p2p-share-invite')?.addEventListener('click',()=>shareTextFrom('#p2p-invite-output','Convite Mirafriends P2P'));
$('#p2p-accept-invite')?.addEventListener('click',()=>acceptP2PInvite());
$('#p2p-copy-answer')?.addEventListener('click',()=>copyTextFrom('#p2p-answer-output'));
$('#p2p-share-answer')?.addEventListener('click',()=>shareTextFrom('#p2p-answer-output','Resposta Mirafriends P2P'));
$('#p2p-finish-connect')?.addEventListener('click',()=>finishP2PConnection());
$('#p2p-process-code')?.addEventListener('click',processP2PCode);
$('#p2p-network-test')?.addEventListener('click',diagnoseP2PNetwork);
$('#p2p-save-turn')?.addEventListener('click',saveP2PTurnSettings);
$('#connection-setup-go-contacts')?.addEventListener('click',()=>{$('#connection-setup').hidden=true;nav('contacts');});
$('#export-local-backup')?.addEventListener('click',sendLocalBackup);
$('#import-local-backup')?.addEventListener('change',async event=>{const file=event.target.files?.[0];if(file)await restoreLocalBackup(file);event.target.value='';});

initAdminExperience({
  state, miraculous, kwamiByMiraculous:KWAMI_BY_MIRACULOUS, getMiraculous,
  profileFromUser, setTheme, renderAll, updateKwamiPet, updateKwamiTransformControls,
  showToast
});
initializeP2PTurnSettings();
boot();
