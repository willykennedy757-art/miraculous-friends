const CACHE = 'mirafriends-v56-node-social-230';
const FILES = ["/", "/index.html", "/styles.css", "/mf-command-center.css", "/mf-admin-landscape.css", "/miragames.css", "/network-social.css", "/miragames.js", "/admin-guardiao.js", "/app.js", "/service-worker.js", "/manifest.webmanifest", "/assets/icon.svg", "/assets/logo.svg", "/assets/pwa-192.png", "/assets/pwa-512.png", "/assets/sigils/bee.png", "/assets/sigils/butterfly.png", "/assets/sigils/cat.png", "/assets/sigils/dog.png", "/assets/sigils/dragon.png", "/assets/sigils/fox.png", "/assets/sigils/goat.png", "/assets/sigils/horse.png", "/assets/sigils/ladybug.png", "/assets/sigils/monkey.png", "/assets/sigils/mouse.png", "/assets/sigils/ox.png", "/assets/sigils/peacock.png", "/assets/sigils/pig.png", "/assets/sigils/rabbit.png", "/assets/sigils/rooster.png", "/assets/sigils/snake.png", "/assets/sigils/tiger.png", "/assets/sigils/turtle.png", "/assets/sigils/pending.png", "/assets/kwamis/bee.png", "/assets/kwamis/butterfly.png", "/assets/kwamis/cat.png", "/assets/kwamis/dog.png", "/assets/kwamis/dragon.png", "/assets/kwamis/fox.png", "/assets/kwamis/goat.png", "/assets/kwamis/horse.png", "/assets/kwamis/ladybug.png", "/assets/kwamis/monkey.png", "/assets/kwamis/mouse.png", "/assets/kwamis/ox.png", "/assets/kwamis/peacock.png", "/assets/kwamis/pig.png", "/assets/kwamis/rabbit.png", "/assets/kwamis/rooster.png", "/assets/kwamis/snake.png", "/assets/kwamis/tiger.png", "/assets/kwamis/turtle.png", "/assets/qr-code.js", "/assets/themes/bee/wallpaper.jpg", "/assets/themes/bee/decoration-1.jpg", "/assets/themes/bee/decoration-2.jpg", "/assets/themes/butterfly/wallpaper.jpg", "/assets/themes/butterfly/decoration-1.jpg", "/assets/themes/butterfly/decoration-2.jpg", "/assets/themes/cat/wallpaper.jpg", "/assets/themes/cat/decoration-1.jpg", "/assets/themes/cat/decoration-2.jpg", "/assets/themes/dog/wallpaper.jpg", "/assets/themes/dog/decoration-1.jpg", "/assets/themes/dog/decoration-2.jpg", "/assets/themes/dragon/wallpaper.jpg", "/assets/themes/dragon/decoration-1.jpg", "/assets/themes/dragon/decoration-2.jpg", "/assets/themes/fox/wallpaper.jpg", "/assets/themes/fox/decoration-1.jpg", "/assets/themes/fox/decoration-2.jpg", "/assets/themes/goat/wallpaper.jpg", "/assets/themes/goat/decoration-1.jpg", "/assets/themes/goat/decoration-2.jpg", "/assets/themes/horse/wallpaper.jpg", "/assets/themes/horse/decoration-1.jpg", "/assets/themes/horse/decoration-2.jpg", "/assets/themes/ladybug/wallpaper.jpg", "/assets/themes/ladybug/decoration-1.jpg", "/assets/themes/ladybug/decoration-2.jpg", "/assets/themes/monkey/wallpaper.jpg", "/assets/themes/monkey/decoration-1.jpg", "/assets/themes/monkey/decoration-2.jpg", "/assets/themes/mouse/wallpaper.jpg", "/assets/themes/mouse/decoration-1.jpg", "/assets/themes/mouse/decoration-2.jpg", "/assets/themes/ox/wallpaper.jpg", "/assets/themes/ox/decoration-1.jpg", "/assets/themes/ox/decoration-2.jpg", "/assets/themes/peacock/wallpaper.jpg", "/assets/themes/peacock/decoration-1.jpg", "/assets/themes/peacock/decoration-2.jpg", "/assets/themes/pig/wallpaper.jpg", "/assets/themes/pig/decoration-1.jpg", "/assets/themes/pig/decoration-2.jpg", "/assets/themes/rabbit/wallpaper.jpg", "/assets/themes/rabbit/decoration-1.jpg", "/assets/themes/rabbit/decoration-2.jpg", "/assets/themes/rooster/wallpaper.jpg", "/assets/themes/rooster/decoration-1.jpg", "/assets/themes/rooster/decoration-2.jpg", "/assets/themes/snake/wallpaper.jpg", "/assets/themes/snake/decoration-1.jpg", "/assets/themes/snake/decoration-2.jpg", "/assets/themes/tiger/wallpaper.jpg", "/assets/themes/tiger/decoration-1.jpg", "/assets/themes/tiger/decoration-2.jpg", "/assets/themes/turtle/wallpaper.jpg", "/assets/themes/turtle/decoration-1.jpg", "/assets/themes/turtle/decoration-2.jpg"];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(FILES)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
  const request=event.request;const url=new URL(request.url);
  if(request.method!=='GET'||url.origin!==self.location.origin)return;
  if(url.pathname.startsWith('/api/')||url.pathname.startsWith('/uploads/'))return;
  const shell=['/','/index.html','/app.js','/styles.css','/mf-command-center.css','/mf-admin-landscape.css','/miragames.css','/network-social.css','/miragames.js','/admin-guardiao.js','/service-worker.js'].includes(url.pathname);
  if(shell){
    event.respondWith(fetch(request,{cache:'no-store'}).then(response=>{
      if(response.ok&&response.type==='basic')caches.open(CACHE).then(cache=>cache.put(request,response.clone()));
      return response;
    }).catch(()=>caches.match(request).then(cached=>cached||caches.match('/index.html'))));
    return;
  }
  event.respondWith(caches.match(request).then(cached=>cached||fetch(request).then(response=>{
    if(response.ok&&response.type==='basic')caches.open(CACHE).then(cache=>cache.put(request,response.clone()));
    return response;
  }).catch(()=>caches.match('/index.html'))));
});

self.addEventListener('notificationclick',event=>{
  event.notification.close();
  event.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(windows=>{
    for(const client of windows){if('focus'in client)return client.focus();}
    if(self.clients.openWindow)return self.clients.openWindow('./');
  }));
});
