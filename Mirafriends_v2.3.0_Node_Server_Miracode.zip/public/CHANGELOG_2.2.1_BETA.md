# Mirafriends 2.2.1 Beta — ajuste solicitado

- Central ADM permanece em composição retrato; removida chamada de preparação de orientação do formulário de senha. Não solicita rotação nem bloqueio de orientação.
- Direcional dos minijogos organizado em cruz, com cima, baixo, esquerda e direita nos lugares esperados e alvos táteis maiores.
- Controles capturam o ponteiro mesmo para ações pontuais da Corrida, evitando estado visual preso ao arrastar o dedo.
- Toques no campo do jogo são convertidos considerando as barras laterais do canvas 16:9, corrigindo a posição de destino em telas com letterbox.
- Ações identificadas por jogo: PULAR, IMPULSO, CORRER, COLETAR, REVELAR, PEGAR e RESGATAR. Instruções de cada modalidade atualizadas.
- Configurações de aparência preservadas: visibilidade das imagens, quatro tons por Miraculous e transformação suave (padrão) ou completa.

Testes: sintaxe de JavaScript/CSS, HTML, IDs, referências locais, existência das 19 paletas, versão/cache e integridade do ZIP. A validação final em WebView Android físico ainda depende do aparelho e empacotador.
