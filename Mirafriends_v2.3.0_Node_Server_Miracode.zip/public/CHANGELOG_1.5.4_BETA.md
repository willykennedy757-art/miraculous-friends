# Mirafriends 1.5.4 Beta

- Interface escura renovada em preto/grafite, com cores de destaque predefinidas pelo Miraculous ativo.
- Navegação com oito áreas: Início, Mensagens, Grupos, Momentos, Câmera, Chamadas, Portadores e Perfil.
- Transformação do Kwami persiste ao trocar de área e mantém um botão fixo de destransformação.
- Emblema do Miraculous exibido nos balões de resposta do Kwami.
- Grupos P2P básicos com convites diretos, aceite e retransmissão de mensagens pelo criador para membros diretamente conectados.
- Momentos de texto P2P com expiração de 24 horas.
- Câmera integrada, captura e álbum interno IndexedDB com até 250 fotos, seleção para envio e exclusão.
- Vários contatos podem ter o mesmo Miraculous; etiquetas locais identificam Universo original, Universo 1, Universo 2 etc.
- Central de Chamadas mostra portadores por nome de perfil e permite selecionar um contato específico ou vários para alertas P2P.
- Códigos P2P2 compactados com gzip quando possível; compatibilidade de leitura com P2P1.

## Limitações

- A conexão continua dependendo da troca manual de convite/resposta. Não há servidor de sinalização nem descoberta pelo Miracode.
- TURN não vem hospedado/configurado; algumas redes exigem credenciais TURN próprias.
- Grupos dependem de conexões P2P ativas e do criador como retransmissor simples.
- Momentos são apenas texto e entregues somente a contatos P2P conectados.
- O álbum interno guarda capturas/importações locais. A primeira importação de fotos existentes no telefone usa o seletor seguro do navegador.
- A Central de Chamadas envia alertas; a chamada de voz continua dentro da conversa individual.
- A conectividade remota e a câmera precisam de validação em aparelhos físicos.
