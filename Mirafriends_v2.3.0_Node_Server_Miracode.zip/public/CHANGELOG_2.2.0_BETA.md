# Mirafriends 2.2.0 Beta — ADM retrato, controles e aparência

- Central ADM deixa de solicitar orientação paisagem e usa layout dedicado em retrato, com navegação compacta e conteúdo rolável.
- Controles dos minijogos reposicionados para o centro inferior, com alvos táteis maiores, liberação robusta de ponteiros e ações específicas funcionais para cada jogo.
- Corrida agora aceita deslocamento lateral, salto e deslize; ações de Aventura e Caça aos Doces receberam funções explícitas.
- Nova página Configurações de aparência: visibilidade dos wallpapers, paleta de transformação independente por Miraculous, transformação suave (padrão) ou completa.
- Preferências visuais persistidas localmente.
- Mantidos os sete jogos, recordes locais, Guardião, painel administrativo e mecanismo P2P existente.

Limites: bloqueio físico de orientação e interação em WebView Android exigem validação no empacotador/aparelho real.
- Ajuste adicional: direcional dos jogos em formato de cruz (cima/baixo/esquerda/direita), com captura de ponteiro para evitar comandos presos ao arrastar o dedo.
- Toques no campo do jogo agora compensam as barras laterais de letterbox para posicionar o personagem corretamente.
- Rótulos das ações foram individualizados por jogo (PULAR, IMPULSO, CORRER, COLETAR, REVELAR, PEGAR e RESGATAR).
