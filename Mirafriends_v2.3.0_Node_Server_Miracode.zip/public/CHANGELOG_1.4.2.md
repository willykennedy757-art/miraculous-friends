# Mirafriends 1.4.2 — Menu de perguntas dos Kwamis

- Tocar no Kwami flutuante abre um menu dedicado de perguntas predefinidas, sem navegar automaticamente para a tela de Mensagens.
- Cada resposta usa a base local de conhecimento e prefixos de personalidade do Kwami selecionado.
- Pergunta dedicada explica passo a passo como conectar dois aparelhos por convite e resposta P2P.
- A resposta de conexão oferece atalho para abrir Portadores e iniciar o emparelhamento.
- Incluídas orientações para Miracode, mensagens/fotos/áudios, chamadas, Central de Portadores, poderes e backup local.
- Menu adaptável a telas pequenas, com botão fechar, clique no backdrop e tecla Escape.
- Cor e imagem do menu acompanham o Kwami selecionado.
- Service Worker atualizado para renovar o cache do app.
