# Referências de lore utilizadas na revisão 1.4.3

As respostas do aplicativo são textos originais e resumidos, não transcrições da série. Referências consultadas para conferir conceitos e poderes:

- Kwamis (lista e conceitos): https://miraculousladybug.fandom.com/pt-br/wiki/Kwamis
- Miraculous superpowers (descrição dos poderes): https://miraculousladybug.fandom.com/wiki/Miraculous_superpowers
- Plagg (detalhes do Cataclysm): https://miraculousladybug.fandom.com/pt-br/wiki/Plagg

As páginas consultadas são wikis comunitárias de referência e podem conter diferenças de tradução entre temporadas. Os textos do app usam formulações prudentes quando um detalhe específico não é necessário para explicar a função principal.
