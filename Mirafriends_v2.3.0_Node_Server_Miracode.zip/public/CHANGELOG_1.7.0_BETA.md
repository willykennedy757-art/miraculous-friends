# Mirafriends 1.7.0 Beta — atualização visual e recursos sociais P2P

Esta revisão parte do beta 1.6.0 enviado para esta atualização. A grade de portadores foi preservada sem redesign. A atualização não transforma o projeto em uma versão 1.0 final e mantém documentadas as limitações que dependem de serviços externos ou testes em aparelhos reais.

## Atualizações desta revisão

### Temas e interfaces
- Aplicados os novos PNGs dos 19 Kwamis oficiais.
- Adicionados, para cada um dos 19 Miraculous oficiais, um wallpaper temático e dois elementos decorativos fornecidos no segundo ZIP (57 imagens de tema).
- A seleção do Miraculous aplica seu wallpaper e suas duas decorações nas telas comuns; Miraculous personalizados usam o símbolo já existente como fallback.
- Redesign tecnológico das páginas e componentes comuns, incluindo cabeçalhos, cartões, formulários, conversas, navegação, áreas sociais e conexão.
- A grade `page-holder-grid` não recebeu o redesign; ao abrir a grade, o fundo decorativo novo é removido para preservar sua apresentação anterior.
- O cache do aplicativo foi atualizado para incluir os recursos visuais e o gerador QR local.

### Conexão e QR
- Adicionado gerador local de QR para os códigos de convite/resposta P2P.
- Adicionado leitor por câmera/arquivo quando o navegador oferece `BarcodeDetector`; quando não houver suporte, o campo manual continua disponível.
- O QR transporta o mesmo código P2P do fluxo existente. Ele não faz sinalização automática, não cria um servidor e não garante conexão em redes que exigem TURN.

### Publicações e privacidade
- Criada uma página de publicações persistentes dos amigos, com texto, imagem/vídeo pequeno, reações e comentários.
- Publicações são marcadas como `friends`; envio e recepção são limitados a contatos adicionados e não bloqueados, conectados diretamente por P2P no momento.
- Reações e comentários são propagados apenas para contatos P2P adicionados e não bloqueados.
- Momentos continuam com validade de 24 horas e foram restringidos a amigos não bloqueados no envio e nas ações sociais.
- Incluída a política de entrada em comunidades por solicitação e aprovação/recusa do administrador. A decisão depende de conexão P2P ativa com o administrador.

### Grupos e Kwamis
- A interface do grupo mostra os Kwamis dos participantes aceitos e permite uma pequena troca de falas local, com base em características/personalidades cadastradas.
- Essa troca é uma interação roteirizada local entre os Kwamis dos participantes aprovados (até oito por rodada); não é conversa gerada por IA nem mensagem enviada aos outros aparelhos.
- O atalho do Kwami permanece fixo e clicável, sem flutuação ou animação automática; o menu e o chat mostram sugestões textuais baseadas na personalidade cadastrada.
- Notificações locais de mensagens e chamadas agora são apresentadas como avisos do Kwami do portador, desde que o navegador tenha permissão e a página esteja ativa/conectada.
- O envio e recebimento de mensagens de grupo agora verificam o status de participação aprovada; membros convidados/pendentes/recusados não acessam as mensagens.
- Pedidos de comunidade só são aceitos de contatos adicionados e não bloqueados; a aprovação também exige uma conexão P2P ativa com o solicitante.

### Backup
- Backup local passa para a versão 4 e inclui publicações. Restauração continua aceitando versões 1 a 4.

## Limitações que permanecem
- O primeiro emparelhamento ainda depende de compartilhar convite e resposta manualmente; o QR apenas facilita esse transporte.
- Reconexão automática após fechar/recarregar, sinalização automática e TURN gerenciado não estão incluídos. O usuário ainda precisa configurar credenciais TURN válidas quando a rede exigir relay.
- Push confiável com o app fechado exige serviço externo.
- Publicações e comunidades não são globais: não há diretório, descoberta nem servidor de feed. A publicação só chega a contatos P2P conectados no momento do envio; o armazenamento local não sincroniza automaticamente entre aparelhos.
- A aprovação da comunidade é P2P e precisa da conexão direta com o administrador; não há fila de pedidos em servidor para quando ele estiver offline.
- Em grupos, o criador continua sendo o relay central; se estiver offline, a distribuição entre os demais participantes não é garantida.
- A interação dos Kwamis nos grupos é local e roteirizada, não IA autônoma sincronizada entre portadores; sugestões são dicas locais fixas por personalidade, não aconselhamento inteligente.
- O leitor QR usa a API `BarcodeDetector`, que não existe em todos os navegadores/WebViews. A leitura de imagem também depende de suporte do navegador. O código manual permanece como alternativa.
- Biometria nativa, sincronização automática de backup, moderação centralizada e testes reais de chamadas/P2P em Android continuam pendentes.
- Continuam válidos os limites de tamanho de arquivos descritos no changelog 1.6.0.

## Verificações realizadas
- Verificação sintática de JavaScript e service worker.
- Verificação de JSON do manifesto, referências de arquivos locais, IDs HTML duplicados e recursos pré-cacheados.
- Teste do gerador QR local com um payload de demonstração.
- Não foi possível certificar chamadas, câmera, QR em todos os WebViews ou conectividade P2P entre dois aparelhos reais neste ambiente.
