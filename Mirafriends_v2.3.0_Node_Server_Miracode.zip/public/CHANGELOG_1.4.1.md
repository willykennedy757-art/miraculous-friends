# Mirafriends 1.4.1 — P2P puro

- Removida a dependência do Firebase e de backend de sinalização.
- Emparelhamento WebRTC por convite/resposta manual com SDP/ICE embutido.
- Mensagens, anexos e chamadas de voz usam canais WebRTC diretos.
- Contatos, mensagens, perfis e fila pendente armazenados localmente.
- Exportação/importação de backup local.
- Grade de portadores com ação separada: símbolo abre nota; fotografia abre ficha.
- Botão para adicionar slots com símbolo `?`, cada um com fotografia/ficha e nota independentes.
- Mantidos os 19 símbolos e 19 imagens PNG dos Kwamis com personalidades locais.
- Corrigida inicialização da ficha de identidade para não aparecer na abertura.
- Limites de P2P, STUN/TURN, armazenamento e notificações documentados.
