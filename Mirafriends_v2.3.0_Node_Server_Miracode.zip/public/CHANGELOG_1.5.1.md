# Mirafriends 1.5.1 — correção visual da grade de portadores

- Restaurado o fundo holográfico roxo original da grade de portadores, conforme a referência visual enviada.
- Restaurados também os fundos roxos originais dos cartões e slots da própria grade para manter a composição visual coerente.
- Nenhuma outra tela, função, dado, símbolo, Kwami ou comportamento foi alterado.
- Cache PWA atualizado para aplicar a correção ao reabrir o aplicativo.
