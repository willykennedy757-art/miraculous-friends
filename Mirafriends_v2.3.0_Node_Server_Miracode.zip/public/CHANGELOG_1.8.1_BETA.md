# Mirafriends 1.8.1 Beta — correção visual, conexão e mascote

## Correções desta revisão
- Corrigida a falha de aplicação visual dos assets: `--theme-wallpaper`, `--theme-icon-1` e `--theme-icon-2` agora são efetivamente consumidos pelo CSS das interfaces comuns.
- Criado novo sistema visual para todas as páginas comuns: central inicial, contatos, mensagens, chamadas, Miraculous, perfil, grupos, comunidades, Momentos, publicações, mídia, formulários e modais.
- O novo sistema usa o wallpaper do Miraculous e os dois elementos decorativos fornecidos para compor o fundo e os cartões principais.
- A tela `page-holder-grid` permanece fora do redesign; o estilo e os elementos internos da grade não foram alterados.
- Reativado o Kwami como mascote arrastável por toque ou mouse. Agora pode ser posicionado por toda a área visível da tela, salva a posição localmente e a restaura ao abrir o app. Um arrasto não abre o menu; um toque/clique abre o menu do Kwami.
- O mascote tem animação leve de flutuação e aura; a interação de arrastar desativa temporariamente essas animações para não atrapalhar o gesto.
- Restaurado o fluxo de conexão mais familiar do beta 1.6: convite, um único campo de código recebido e resposta, com o diagnóstico de rede visível. QR segue disponível em uma seção opcional; TURN permanece avançado. O mecanismo WebRTC foi mantido, sem adicionar etapas artificiais.
- O motor de negociação P2P existente foi mantido sem troca de mecanismo; não foi introduzido Firebase nem outro backend.
- Atualizados manifesto e cache do service worker para 1.8.1.

## Limites conhecidos
- O pareamento continua exigindo troca de convite/resposta e manter ambos os aparelhos com a página aberta.
- Não foi adicionado serviço de sinalização, relay TURN próprio, push remoto, entrega offline ou sincronização de feed/comunidades.
- O QR é apenas um meio alternativo para transportar o convite/resposta; a leitura por câmera depende do suporte do navegador/WebView.
- O mascote é arrastável e tem animação visual leve; não executa comportamentos autônomos complexos de um Shimeji de desktop.
- Verificação estática e browser preview não substituem testes de P2P, câmera, microfone, chamadas e leitor QR em aparelhos Android reais.

- As perguntas pessoais cadastradas em um Kwami personalizado também são reconhecidas quando o portador digita uma pergunta semelhante no chat, e não apenas ao tocar no botão da pergunta.
