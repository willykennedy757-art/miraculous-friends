# Mirafriends Connect — WebRTC P2P (1.5.4)

## Arquitetura

- `RTCPeerConnection` negocia a conexão ponto a ponto.
- `RTCDataChannel` transmite mensagens, recibos, pacotes de mídia e sinalização interna de chamadas.
- A oferta e a resposta SDP com candidatos ICE são exportadas como códigos `MIRAFRIENDS-P2P2` (compactado quando o navegador suporta) e `MIRAFRIENDS-P2P1` (formato legado) e trocadas manualmente.
- O campo único de recebimento identifica automaticamente se o código colado é convite (`offer`) ou resposta (`answer`).
- STUN ajuda a descobrir caminhos de rede; TURN pode retransmitir pacotes quando a ligação direta é bloqueada.

## Troca de convite

1. A cria o convite e compartilha o bloco completo.
2. B cola no campo **Código recebido** e toca **Processar código automaticamente**; o aplicativo gera a resposta.
3. B envia a resposta para A.
4. A cola a resposta no mesmo campo e processa novamente.
5. Os dois mantêm a página aberta até o canal de dados abrir.

Códigos expiram em 2 horas. Confirme o nome/Miracode do interlocutor por um canal independente antes de aceitar.

## ICE, STUN e TURN

O cliente reúne candidatos ICE usando dois grupos de STUN públicos (Google e Cloudflare). O botão **Verificar minha rede** cria uma conexão de diagnóstico local e conta candidatos host, srflx e relay. A presença de um candidato srflx indica que STUN respondeu neste aparelho; não garante que o par remoto consiga se conectar.

O formulário TURN aceita JSON com a lista ICE e credenciais fornecidas por um serviço TURN. Exemplos de formato ficam no placeholder da interface. As credenciais são salvas em localStorage apenas no aparelho e a mesma configuração precisa estar nos dois clientes. O projeto não contém uma conta, chave ou servidor TURN próprio.

## Transporte e mídia

Texto é enviado como JSON pelo data channel. Imagens e áudios são enviados em chunks binários com limite de 1,4 MB por arquivo. Os dados locais são mantidos no IndexedDB e localStorage do próprio dispositivo.

## Chamadas

As chamadas de voz criam uma segunda conexão WebRTC usando a conexão de dados já emparelhada para trocar a oferta/resposta da chamada. A lista ICE configurada (STUN + TURN local) também é aplicada às chamadas. Permita acesso ao microfone quando o navegador solicitar.

## Segurança e privacidade

WebRTC cifra o transporte de mídia e dados em trânsito. O convite inclui identidade local e SDP/candidatos de rede; aceite apenas códigos esperados e confirme o interlocutor por canal separado. Não compartilhe convites publicamente. Credenciais TURN ficam no armazenamento local do aparelho e não entram em backups.

## Limitações

Não existe sinalização automática, procura por Miracode, caixa postal remota ou entrega a usuários offline. STUN não é relay e não atravessa todos os NATs/firewalls. Algumas redes precisam de TURN válido configurado nos dois aparelhos. A conexão precisa ser refeita após fechar/recarregar o navegador. Sem servidor de armazenamento/encaminhamento, contatos offline não recebem mensagens nem push remoto.


## Compactação dos códigos (1.5.4)

O Mirafriends tenta compactar o JSON da oferta/resposta com gzip e usa o prefixo `MIRAFRIENDS-P2P2`. Se o navegador não oferecer `CompressionStream`, usa o formato `MIRAFRIENDS-P2P1`. O leitor reconhece os dois formatos. A compactação diminui o tamanho do texto, mas não substitui o processo de troca manual dos dois códigos nem adiciona sinalização automática.

## Grupos P2P (1.5.4)

Os grupos são salvos localmente e os convites são enviados aos contatos com canal de dados aberto. O criador funciona como retransmissor simples de mensagens para os membros com conexão P2P direta com ele. Não há relay central: mantenha o criador conectado aos membros para que o encaminhamento funcione de forma mais consistente.
