# Kwamis companheiros

O Mirafriends associa o Miraculous selecionado ao PNG correspondente em `assets/kwamis/` e mostra o Kwami como um companheiro flutuante pela interface. Tocar no Kwami abre a conversa de ajuda local. Cada um dos 19 Kwamis possui nome, personalidade, saudação, poder e explicação do próprio Miraculous. As respostas usam uma base local de conhecimento e regras de intenção; não são geradas por um modelo de IA externo.

Os arquivos PNG originais dos 19 Kwamis foram integrados e são servidos pelo próprio site estático.
