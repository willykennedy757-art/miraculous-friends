# Menu de perguntas predefinidas dos Kwamis

Ao tocar no companheiro flutuante, o Mirafriends abre uma janela com a imagem, nome, Miraculous associado e saudação do Kwami atualmente selecionado. O usuário escolhe uma pergunta pronta e recebe a resposta sem sair do menu.

Perguntas incluídas:
- Como conectar dois celulares ou dispositivos pelo P2P?
- Como aceitar o convite e concluir o emparelhamento?
- Onde encontrar e compartilhar o Miracode?
- Como enviar mensagens, fotos e áudios?
- Como iniciar uma chamada de voz?
- Como usar a Central de Portadores?
- Como fazer backup e transferir os dados?
- Qual é o poder do Miraculous?
- Quem é o Kwami e qual sua personalidade?

As respostas são produzidas localmente pela base de conhecimento do Mirafriends, com mensagens introdutórias específicas de cada Kwami. Não há chamada a serviços de IA externos.

## Conexão entre dispositivos explicada pelo Kwami

1. Abra o Mirafriends em HTTPS nos dois aparelhos e mantenha as páginas abertas.
2. No aparelho A, entre em Portadores e toque em “Criar meu convite”. Copie ou compartilhe o bloco completo.
3. No aparelho B, cole o convite no campo único “Código recebido” e toque em “Processar código automaticamente”. O app detecta que é um convite e gera a resposta.
4. B envia a resposta para A.
5. A cola a resposta no mesmo campo “Código recebido” e toca em “Processar código automaticamente” novamente.
6. Aguarde aparecer “Conectado” nos dois aparelhos antes de abrir Mensagens.

O código vale por 2 horas. Miracode serve para conferir a identidade, não para descobrir usuários. STUN ajuda muitas redes; redes restritivas podem exigir TURN configurado nos dois aparelhos. O botão “Verificar minha rede” mostra os candidatos locais, mas não garante a conexão ponta a ponta.

## Perguntas individuais por Miraculous — versão 1.4.3
O menu agora separa as perguntas pessoais do Kwami das dúvidas gerais sobre o aplicativo. Cada um dos 19 Kwamis possui três perguntas e respostas próprias (57 no total), relacionadas ao conceito, ao funcionamento do poder e a um detalhe ou cuidado de uso. O conjunto exibido muda automaticamente conforme o Miraculous selecionado. As respostas são locais, com prefixos de fala próprios para cada Kwami.

As explicações são paráfrases resumidas da série e evitam apresentar os poderes como ilimitados.
