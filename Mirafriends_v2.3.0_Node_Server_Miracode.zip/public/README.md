# Mirafriends 2.2.1 Beta — ADM em retrato, controles e aparência

Mirafriends é uma PWA social temática de Miraculous. Esta edição apresenta uma identidade tecnológica holográfica azul e violeta, páginas compactas decoradas pelos temas de cada Miraculous, tela de abertura com os cinco símbolos principais e uma Central ADM em tela inteira. Inclui o santuário Guardião com Kwamis autônomos, balões de fala e memória local. Preserva os 19 símbolos de `assets/sigils/`, os 19 PNGs oficiais de Kwamis em `assets/kwamis/`, a grade de portadores, mensagens e chamadas diretas.

## Sem Firebase e sem backend próprio

Esta edição mantém a arquitetura local/P2P sem adicionar Firebase, Socket.IO, Node.js ou endpoints `/api`. A primeira conexão entre duas pessoas utiliza troca manual de convite e resposta WebRTC. Depois de emparelhados, mensagens, anexos e sinalização de voz são enviados pelo `RTCDataChannel` diretamente entre os navegadores.

## Publicação

Publique a pasta raiz em uma hospedagem estática com HTTPS. Não existe comando `npm start`, backend ou implantação de Functions. WebRTC e a Clipboard API exigem contexto seguro (HTTPS ou localhost).

## Primeiro emparelhamento (fluxo simplificado)

1. Os dois usuários abrem o Mirafriends em HTTPS e mantêm a página aberta.
2. A pessoa A toca em **Criar meu convite** e compartilha o bloco completo.
3. A pessoa B cola o bloco no campo único **Código recebido** e toca em **Processar código automaticamente**. O aplicativo reconhece o convite e gera a resposta.
4. A pessoa B compartilha a resposta. A pessoa A cola essa resposta no mesmo campo e toca em **Processar código automaticamente** novamente.
5. Aguarde o canal P2P mostrar **Conectado**. Não feche nem recarregue as páginas durante o processo.

Os códigos têm validade de 2 horas. O Miracode continua sendo apenas identificador visual; ele não localiza usuários nem conecta sozinho.

## STUN, TURN e conexão à distância

A conexão usa WebRTC/ICE com servidores STUN públicos para tentar descobrir caminhos entre redes diferentes. O botão **Verificar minha rede** conta os candidatos STUN/TURN encontrados localmente, mas não garante que a conexão com outro aparelho será possível.

STUN ajuda em muitas redes, mas não retransmite o tráfego. Alguns NATs e firewalls bloqueiam conexões diretas; nesses casos, é necessário TURN. A seção **Configuração avançada · TURN** aceita uma lista JSON de servidores TURN com as credenciais fornecidas pelo serviço. A mesma configuração deve estar nos dois aparelhos. As credenciais são salvas localmente e não entram no backup. Não cole chaves secretas de conta; use credenciais TURN próprias para clientes.

O projeto não inclui servidor TURN, credenciais de relay ou serviço de sinalização próprio. Portanto, a conexão à distância pode funcionar diretamente em várias redes, mas não pode ser garantida em todas as redes sem TURN válido.

## Dados locais

Identidade, contatos, mensagens recebidas/enviadas, fichas e notas da Central de Portadores são armazenados no navegador (localStorage/IndexedDB). Use **Perfil > Exportar backup local** para guardar uma cópia e **Importar backup local** para restaurar. Reinstalar ou limpar os dados do navegador sem backup pode apagar essas informações. Os contatos precisam ser emparelhados novamente após recarregar/fechar o aplicativo, pois objetos `RTCPeerConnection` não persistem.

## Limitações reais

- A troca manual de oferta/resposta substitui um servidor de sinalização. Não há descoberta automática por Miracode.
- STUN público ajuda a descobrir candidatos de rede, mas não retransmite dados. Em NATs/firewalls restritivos, TURN pode ser necessário; esta versão aceita TURN configurável, mas o usuário precisa fornecer credenciais válidas nos dois aparelhos.
- Mensagens pendentes ficam na fila do aparelho remetente e só serão enviadas quando ambos estiverem online, com a conexão P2P restabelecida. Não existe entrega a um contato offline.
- Notificações locais podem ser mostradas quando a página recebe um evento P2P e tem permissão. Push remoto e chamadas recebidas com o aplicativo encerrado não são possíveis sem infraestrutura externa de sinalização/push.
- O Android pode suspender páginas em segundo plano; mantenha o Mirafriends aberto durante chamadas e sessões diretas.
- A vibração depende de suporte do navegador e permissões do aparelho.

## Testes

A verificação estática cobre sintaxe JavaScript, HTML, JSON, arquivos locais e integridade do ZIP. Uma conexão real depende de dois dispositivos, HTTPS e suas redes; não é possível certificar conectividade universal apenas por inspeção de código.


## Menu de perguntas do Kwami (1.4.3)

Tocar no Kwami flutuante abre um menu próprio com perguntas predefinidas. Ao escolher uma pergunta, o Kwami responde com a sua personalidade e com informações do Miraculous associado. O menu inclui orientação detalhada para emparelhar dois aparelhos por P2P, encontrar o Miracode, enviar mensagens e mídia, fazer chamadas, usar a Central de Portadores e transferir dados por backup local. A ação “Abrir emparelhamento P2P” leva diretamente à área Portadores. O menu pode ser fechado pelo botão, tocando fora dele ou com Escape.

As respostas são locais e baseadas nas informações e fluxos existentes no aplicativo; não é uma IA generativa externa. A conexão usa WebRTC diretamente após a troca manual de convite e resposta, e pode falhar em redes que exijam TURN.


## Perguntas personalizadas dos Kwamis (1.4.3)
Cada um dos 19 Kwamis possui três perguntas exclusivas sobre o conceito, o poder e o uso do seu próprio Miraculous (57 perguntas específicas no total). As perguntas são renderizadas de acordo com o Miraculous ativo; perguntas gerais do Mirafriends continuam disponíveis em uma seção separada. As respostas são locais e usam a personalidade do Kwami selecionado.


## Versão 1.5.0

A primeira abertura não exibe mais o splash antigo. Usuários sem Miraculous veem diretamente a seleção; ao escolher, o símbolo aparece no centro com ondas durante 9 segundos. Cada Miraculous aplica seu próprio tema pastel ao aplicativo. A Central de Portadores tenta travar o dispositivo na horizontal e libera a trava ao sair, respeitando as limitações do navegador. Chamadas únicas e múltiplas têm animações dedicadas de emblemas e ondas.


### Orientação e chamadas
A Central de Portadores tenta travar a tela em paisagem ao entrar. O bloqueio é solicitado pela Screen Orientation API; quando o navegador não permite, a grade mostra uma alternativa responsiva e uma orientação para virar o aparelho. A chamada individual anima um emblema e ondas; a múltipla alinha os símbolos dos destinatários conectados.


## Interface 1.5.0
A abertura foi simplificada para começar na seleção do Miraculous. Após a escolha, o emblema central pulsa e envia ondas durante 9 segundos antes da Home. A paleta pastel agora alcança cabeçalho, navegação, cartões, grade, formulários, chamadas e o menu do Kwami. A Central de Portadores solicita tela cheia/orientação horizontal quando o navegador permite e oferece um aviso de rotação manual quando não permite.

## Beta 1.5.2 — contato e transformação dos Kwamis

- O Miraculous selecionado continua definindo automaticamente a paleta visual do aplicativo; não foi adicionado seletor manual de temas.
- O contato do Kwami aparece automaticamente no topo da lista Mensagens quando existe um Miraculous selecionado.
- A conversa individual do Kwami é local, possui histórico próprio salvo neste aparelho e reutiliza as respostas predefinidas e o conhecimento local já existente.
- Tocar no Kwami flutuante continua abrindo o menu de perguntas. O menu também oferece acesso direto à conversa individual.
- As respostas do Kwami na conversa e no menu exibem o emblema do Miraculous no canto superior do balão/cartão.
- A transformação é ativada pelo portador, somente na interface local. Usa o esquema de cores próprio do Miraculous, um efeito simples e um botão persistente de retorno enquanto a transformação estiver ativa. Tikki mantém “Spots On!” / “Spots Off!”; os demais Kwamis recebem comandos próprios do Mirafriends baseados no conceito de cada Miraculous.
- Correção na 1.5.4: a transformação continua ativa ao navegar entre abas e áreas; só termina quando o portador toca no botão de destransformar. O botão fica acessível fora do chat enquanto o modo estiver ativo.
- A transformação não é enviada pelo canal P2P, não altera o estado de outros participantes e não fica salva após fechar/recarregar o aplicativo.

### Limites que permanecem nesta beta

- A conversa do Kwami é um assistente local com respostas programadas; não é IA generativa online.
- O contato do Kwami é pessoal e não é um contato P2P remoto.
- Grupos P2P básicos e Momentos de texto foram adicionados na 1.5.4. Não há comunidades com feed central, links públicos/QR ou armazenamento em nuvem. Grupos usam conexões diretas: o criador retransmite mensagens para participantes emparelhados com ele; para alcançar todos, o criador precisa estar conectado aos participantes. Não existe servidor de relay.
- A fila de mensagens de pessoas continua sendo local: só pode entregar quando os dois portadores estiverem online e o canal P2P estiver conectado novamente.
- Áudio e chamadas de voz P2P já existiam na versão recebida e foram preservados; não foi adicionado servidor de chamada nem suporte a chamadas recebidas com o app fechado.


## Beta 1.5.3 — conexão P2P aprimorada

- Campo único para colar código, com identificação automática de convite ou resposta.
- Coleta ICE mais robusta, mensagens de progresso e validade de código de 2 horas.
- Diagnóstico local de candidatos de rede e configuração opcional de servidores TURN.
- Configuração TURN também é aplicada às chamadas de voz e fica salva localmente no aparelho.
- Não há garantia universal: algumas redes precisam de TURN e nenhum TURN está pré-configurado nesta edição.


## Beta 1.5.4 — atualização ampla

### Interface e navegação
- Interface redesenhada em preto/grafite, com o acento de cor definido automaticamente pelo Miraculous selecionado. Não há seletor manual de tema.
- Navegação principal reorganizada em oito áreas: Início, Mensagens, Grupos, Momentos, Câmera, Chamadas, Portadores e Perfil.
- O emblema do Miraculous aparece nos balões de resposta dos Kwamis.
- Transformação persiste ao trocar de aba ou entrar em outra área. O botão de destransformação fica fixo acima da navegação e a transformação continua local, sem alterar a interface dos outros participantes.

### Grupos e Momentos
- Criação de grupos com contatos P2P conectados, convites diretos, aceite e histórico local.
- Mensagens de grupo são retransmitidas pelo criador aos membros com conexão direta ativa. Sem um servidor de encaminhamento, membros que não estão conectados ao criador podem não receber mensagens.
- Momentos de texto com limite de 280 caracteres e expiração de 24 horas, enviados diretamente aos contatos P2P que estiverem conectados no momento da publicação.

### Câmera e álbum interno
- Câmera integrada com captura de fotos e alternância entre câmera frontal/traseira quando o dispositivo oferece ambas.
- Álbum interno em IndexedDB, com até 250 fotos, seleção para envio no chat e exclusão local.
- Fotos capturadas no app ficam no álbum interno. Para importar fotos antigas do telefone pela primeira vez, o navegador abre o seletor de arquivos/fotos; a aplicação web não pode explorar silenciosamente a galeria nem o Google Fotos. Depois da importação, as fotos podem ser reutilizadas pelo álbum do Mirafriends sem abrir novamente o seletor.
- A câmera requer HTTPS (ou localhost), permissão do navegador e dispositivo compatível.

### Portadores e Central de Chamadas
- O mesmo Miraculous pode aparecer em vários contatos. Os portadores recebem etiquetas por ordem local: “Universo original”, “Universo 1”, “Universo 2” e assim por diante.
- A Central de Chamadas lista os nomes dos perfis para o Miraculous escolhido e permite selecionar um portador específico ou vários. O botão envia alertas P2P; chamadas de voz continuam sendo iniciadas na conversa individual.

### P2P
- Novos códigos P2P2 usam compactação gzip quando suportada pelo navegador, reduzindo o tamanho do texto copiado. O leitor continua aceitando códigos P2P1 antigos.
- A troca manual de convite e resposta continua necessária: não existe servidor de sinalização nem busca automática pelo Miracode.
- STUN pode ajudar entre redes; TURN ainda precisa ser configurado com credenciais de um serviço. Não há promessa de atravessar todos os NATs/firewalls sem relay.

### Verificação desta edição
- Sintaxe JavaScript verificada com `node --check`.
- Estrutura HTML verificada: sem IDs duplicados e todos os oito itens da navegação apontam para páginas existentes.
- `manifest.webmanifest` validado como JSON.
- Codec P2P2 testado com compactação/descompactação e compatibilidade de leitura P2P1.
- A interface completa e câmera não foram validadas em um dispositivo físico nesta sessão. A conectividade P2P entre duas redes diferentes ainda precisa de teste com dois aparelhos reais.


## Beta 1.6.0 — atualização ampliada

Esta revisão amplia o beta 1.5.4 e prepara o escopo do Mirafriends 1.0. Ela não é a versão 1.0 final.

### Aparência e Kwamis
- A transformação recolore com mais força o fundo, cartões, navegação, botões e balões de conversa, preservando a grade dos portadores sem redesign.
- Há efeitos sutis de partículas/flash, transições entre áreas e sons opcionais da interface.
- A criação de Miraculous permite cadastrar um Kwami próprio opcional, com nome, personalidade, saudação, até três perguntas/respostas e frases próprias de transformação/destransformação.
- As respostas às perguntas cadastradas são usadas no menu pessoal do Kwami.

### Mensagens e chamadas
- Responder, editar/apagar mensagens próprias, reagir, fixar, indicador de digitação, confirmação de leitura e pesquisa. A bandeja inclui figurinhas temáticas e até 24 imagens adicionadas pelo usuário.
- Anexos P2P aceitos: imagens, áudios, vídeos MP4/WebM/MOV e alguns documentos leves, até 2 MB cada.
- Chamadas de vídeo P2P foram adicionadas ao fluxo de chamada de voz e exigem câmera/microfone nos dois aparelhos.

### Grupos e Momentos
- Um administrador cria grupo privado ou comunidade primeiro e envia convites depois; não precisa adicionar outros portadores durante a criação.
- Convites são entregues via P2P a contatos que já estão emparelhados e conectados.
- O administrador pode promover/rebaixar participantes como moderadores.
- Momentos de 24 horas aceitam texto, imagem comprimida (até 900 KB), vídeos MP4/WebM/MOV (até 700 KB), comentários e reações.

### Perfil, proteção e backup
- Campo opcional “Sobre mim” no perfil.
- Bloqueio local de contatos e registro local de denúncias (não enviado a uma equipe de moderação).
- PIN local de 6 a 12 dígitos para proteger a abertura do app; o PIN não criptografa o armazenamento.
- Backup manual v3 com perfil, contatos, grupos, Momentos, Miraculous personalizados, registros de portadores, mensagens, fotos do álbum e figurinhas pessoais, até 50 MB. A restauração aceita backups v1, v2 e v3.

### O que continua pendente para o Mirafriends 1.0
- QR Code gerador/leitor para emparelhamento.
- Sinalização automática e reconexão garantida depois de fechar/recarregar o app. O emparelhamento inicial ainda usa convite e resposta manuais.
- TURN fornecido pelo projeto para redes com NAT/firewall restritivos. O usuário pode configurar um serviço TURN próprio.
- Push confiável quando o app está encerrado; notificações atuais dependem da página ativa/conectada.
- Comunidades com diretório/feed global. O modo “comunidade” ainda usa o mesmo modelo P2P de grupo.
- Interação autônoma dos Kwamis entre si em conversas e sugestões/notificações proativas; o chat individual do Kwami continua sendo um assistente local de respostas programadas.
- Editor avançado de figurinhas (recorte/efeitos/pacotes sincronizados); a beta permite adicionar imagens personalizadas à bandeja local.
- Relay de grupos por servidor. No P2P atual, o criador precisa estar conectado diretamente aos membros para retransmitir mensagens.
- Ferramentas completas de moderação e permissões avançadas.
- Autenticação biométrica nativa no APK; nesta versão existe apenas PIN local.
- Backup automático/nuvem e sincronização contínua entre aparelhos.
- Limites maiores e mais formatos de arquivo; nesta beta os anexos P2P têm até 2 MB e vídeos de Momentos até 700 KB.
- Testes em aparelhos reais para conexão P2P, chamadas de voz/vídeo, câmera, permissões e instalação APK.

### Verificação desta revisão
- `node --check app.js` e `node --check service-worker.js` sem erros.
- HTML conferido: IDs únicos e referências internas existentes.
- `manifest.webmanifest` validado como JSON; CSS analisado sem erros sintáticos; referências locais de mídia encontradas.
- A interface não foi validada num navegador real nesta sessão e a conexão não foi testada entre dois aparelhos. Portanto, as validações acima são estáticas, não certificam funcionamento em todas as redes ou dispositivos.


## Revisão 1.6.0 Beta

Esta revisão amplia a interface, transformação, conversas, figurinhas personalizadas, mídia P2P, chamadas de vídeo, grupos por convite (incluindo link/código de convite), Momentos com mídia, proteção local por PIN, figurinhas locais removíveis e backup versão 3. Consulte `CHANGELOG_1.6.0_BETA.md`, `PENDENCIAS_MIRAFRIENDS_1.0.txt` e `VERIFICACAO_1.6.0_BETA.txt` para ver o que foi implementado, os limites técnicos e os itens que ainda dependem de infraestrutura/testes em aparelhos reais.


## Beta 1.8.1 — temas, redesign e recursos sociais

- Atualizados os PNGs dos 19 Kwamis e adicionados 57 imagens de tema (wallpaper + duas decorações por Miraculous).
- Redesenhadas as páginas e áreas comuns; a página `page-holder-grid` foi excluída do redesign para preservar a grade dos portadores.
- Adicionado QR local para gerar códigos P2P; leitura automática depende de `BarcodeDetector` suportado pelo navegador.
- Adicionado feed local de publicações visíveis apenas para amigos adicionados e não bloqueados, compartilhadas somente com contatos P2P conectados no momento.
- Comunidades agora aceitam pedido de entrada e decisão do administrador por conexão P2P ativa.
- Adicionada interação roteirizada local dos Kwamis presentes em grupos; não é conversa de IA nem é sincronizada com outros aparelhos.
- Backup manual atualizado para v4 com publicações.

Consulte `CHANGELOG_1.8.1_BETA.md` e `PENDENCIAS_MIRAFRIENDS_1.0.txt`. Sinalização automática, reconexão automática garantida, TURN próprio, push remoto, comunidades globais, relay de grupos offline, biometria e testes de campo permanecem pendentes.

- O Kwami fica como mascote flutuante na tela: é possível arrastá-lo por toque ou mouse, salvar sua posição e abrir o menu com um toque/clique. As sugestões continuam personalizadas pela personalidade.


## MiraGames e Central ADM 2.0.0

A versão 2.0.0 inclui uma área MiraGames com quatro minijogos controlados por Kwamis e uma Central ADM em layout paisagem. O símbolo da Borboleta abre os módulos secretos; o símbolo da Tartaruga abre a seleção de Miraculous. A barra inferior está fixa na viewport e o Kwami companheiro percorre posições seguras da tela, continuando arrastável. Consulte `CHANGELOG_2.0.0_BETA.md` para limites e testes.

## Novidades da revisão 2.0.0 Beta
- MiraGames inclui quatro jogos individuais controlados por Kwamis, com recordes salvos no aparelho.
- Central ADM em paisagem: Borboleta abre as funções secretas e Tartaruga abre o seletor de Miraculous.
- Guardião inclui santuário e Kwamis móveis sobre as páginas.
- A navegação inferior permanece fixa; o mascote Kwami volta a se mover e pode ser arrastado.
- Wallpapers e mini ícones dos 19 temas ficam mais visíveis.

A rotação real do Android depende do suporte do navegador/WebView à API de orientação e ao modo de tela cheia. Quando o bloqueio nativo não estiver disponível, o painel aplica um layout girado por CSS, mas isso não força o sensor físico do aparelho. A conexão P2P permanece no fluxo existente; os minijogos e o Guardião funcionam localmente.


## MiraGames 2.2.0
O MiraGames inclui sete jogos locais com Kwamis controláveis, mapas/minimapas, objetivos, estatísticas e personagens NPC: Voo dos Kwamis, Corrida Miraculosa, Caça aos Doces, Aventura dos Kwamis, Esconde-esconde, Pega-pega Miraculoso e Resgate dos Kwamis. Ao iniciar, o jogo tenta abrir em tela cheia e solicitar orientação paisagem; o comportamento final depende do navegador ou WebView.

A interface impede seleção e cópia acidental de texto por toque longo. Campos de texto continuam editáveis.
