# Mirafriends 2.0.0 Beta — MiraGames e Central ADM em Paisagem

## Atualizações
- Redesenho completo do painel ADM em modo horizontal, com layout de tela inteira.
- O símbolo da Borboleta abre o núcleo com as abas secretas.
- O símbolo da Tartaruga abre o seletor de Miraculous; as 19 opções e os Miraculous personalizados ficam disponíveis.
- O painel solicita tela cheia e `screen.orientation.lock('landscape')` durante a autenticação ADM. Se o navegador ou WebView não permitir, a própria interface é girada por CSS dentro da tela retrato. A orientação normal é restaurada ao sair.
- Temas e elementos decorativos mais visíveis; cabeçalhos e títulos receberam acabamento visual.
- Barra de navegação movida para fora do contêiner principal e fixada diretamente na viewport.
- Mascote do Kwami volta a passear entre posições seguras, além de continuar arrastável; o movimento é suspenso durante o arrasto e recomeça ao soltar.
- MiraGames adicionado com quatro jogos locais: Voo dos Kwamis, Corrida Miraculosa, Caça aos Doces e Aventura dos Kwamis. O jogador escolhe o Kwami; recordes ficam salvos no aparelho.
- Cache offline atualizado para os novos módulos e estilos.

## Limites e segurança
- A rotação real depende das permissões de tela cheia/orientação do navegador ou WebView. O fallback CSS gira o painel sem alterar a orientação física do sistema.
- Alteração de Miraculous na Central ADM continua local ao aparelho.
- MiraGames funciona localmente; não oferece partidas multiplayer.
- A autenticação ADM permanece local, sem servidor. A senha/hash dentro do cliente não é uma barreira segura contra alguém que tenha acesso técnico aos arquivos.
- O motor WebRTC/P2P não foi alterado nesta versão.

## Validação
- Validar sintaxe dos módulos JavaScript e integridade do ZIP.
- Testar a navegação, o painel ADM, o seletor de Miraculous, os quatro jogos, os controles de pausa/retorno, os caminhos de assets e o movimento do mascote em Chromium.
- Testes em aparelhos Android reais continuam necessários para confirmar bloqueio de orientação, WebView, câmera, P2P e rotação física.

### Correções adicionais de interface
- Removida a regra antiga que prendia o Kwami ao canto inferior direito e desativava seu movimento.
- Corrigido o botão de retorno à tela inicial do painel ADM e a atualização do seletor ao trocar o Miraculous.
- Aumentada a visibilidade dos wallpapers e dos dois elementos decorativos por tema.
- Removida a referência duplicada à folha de estilos do MiraGames.
- Atualizada a versão do cache local para forçar a leitura dos arquivos novos.

### MiraGames, temas, ADM e mascote — revisão final
- Adicionados quatro minijogos locais com controle direto de um Kwami: Voo dos Kwamis, Corrida Miraculosa, Caça aos Doces e Aventura dos Kwamis.
- Adicionado seletor de personagem entre os Kwamis disponíveis e salvamento local dos recordes.
- Painel ADM organizado em modo paisagem: o símbolo da Borboleta abre os módulos secretos e o símbolo da Tartaruga abre o catálogo de Miraculous.
- Abertura do aplicativo com os cinco símbolos principais.
- Reforçada a visibilidade dos wallpapers e dos dois elementos decorativos por tema; títulos e rótulos receberam decoração visual.
- Corrigido o retorno à tela principal do ADM e a atualização do seletor ao alterar a identidade local.
- Barra inferior movida para fora do contêiner rolável, ficando fixa na viewport.
- Removida a regra antiga que fixava o Kwami no canto e desativava o movimento; o mascote volta a passear e continua arrastável.
- Mantido o HTML da grade de portadores sem alterações.


# Mirafriends 2.1.0 Beta — MiraGames imersivo e painel ADM organizado

## MiraGames
- Partidas agora usam uma camada de tela cheia independente da navegação do aplicativo, com tentativa de Fullscreen API e bloqueio de orientação paisagem quando suportados.
- Catálogo ampliado de quatro para sete jogos: Voo dos Kwamis, Corrida Miraculosa, Caça aos Doces, Aventura dos Kwamis, Esconde-esconde, Pega-pega Miraculoso e Resgate dos Kwamis.
- Adicionado minimapa dinâmico, painel de objetivo, estatísticas e lista de NPCs Kwamis.
- Kwamis NPC acompanham o jogador, escondem-se, fogem, são marcados no pega-pega ou seguem o jogador após resgate, conforme a modalidade.
- Objetivos antigos foram melhorados: emblemas na Corrida, 18 estrelas e três portais no Voo, fragmentos e saída na Aventura.
- Recordes anteriores do MiraGames são migrados da chave local v1.

## Interface e acessibilidade
- Corrigida organização do painel ADM com trilho lateral, cartões em grade, painéis com espaçamento consistente e botões agrupados.
- Impedida seleção/cópia acidental de texto por toque longo na interface e no jogo. Campos de formulário continuam selecionáveis/editáveis. Menu de contexto foi desativado fora de campos editáveis.
- Cache do service worker atualizado para 2.1.0.

## Limites
- Fullscreen e orientação física paisagem dependem do suporte do navegador/WebView e de gesto do usuário; o layout imersivo em CSS é o fallback.
- NPCs e comportamentos são lógica local roteirizada, não multiplayer real nem IA conectada.
- Recordes e progresso ficam neste aparelho.
