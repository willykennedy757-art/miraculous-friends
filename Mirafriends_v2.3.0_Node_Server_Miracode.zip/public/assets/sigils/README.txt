EMBLEMAS EM PNG — MIRAFRIENDS

O aplicativo carrega os emblemas em arquivos PNG locais, sem depender de uma imagem externa.

Para substituir um emblema, troque o PNG correspondente mantendo exatamente o nome do arquivo (por exemplo, cat.png, ladybug.png, bee.png). Mantenha fundo transparente, formato PNG e proporção quadrada. Não altere os nomes dos arquivos.

Os ícones incluídos nesta versão foram recortados da prancha de emblemas que acompanha o projeto. Confira as associações visuais antes de publicar. Projeto de fã, não oficial.
