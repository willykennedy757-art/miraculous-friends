# Mirafriends 1.6.0 Beta — atualização ampliada

Esta é uma revisão incremental sobre o ZIP 1.5.4 enviado pelo usuário. O objetivo é aproximar o aplicativo do escopo aprovado para a versão 1.0, preservando a grade de portadores e o modelo P2P sem Firebase.

## Implementado ou ampliado nesta revisão

### Aparência e transformação
- Paleta de transformação mais forte, alcançando fundo, cartões, navegação, botões, cabeçalho e balões de conversa.
- Transformação continua ativa ao navegar entre abas; a tela de portadores não recebeu redesign.
- Efeitos sutis de partículas/flash, transições entre áreas e sons sintéticos opcionais, com controle no Perfil.
- O criador de Miraculous aceita, opcionalmente, nome do Kwami, personalidade, saudação, três pares de perguntas/respostas e frases próprias de transformação/destransformação.
- Perguntas de Kwamis personalizados agora usam as respostas cadastradas pelo criador, em vez de consultar apenas a lista oficial.

### Conversas
- Ações de resposta, edição e exclusão de mensagens próprias, reações, fixação, indicador de digitação, confirmação de leitura e pesquisa no chat. As figurinhas incluem opções temáticas e uma coleção local de até 24 imagens adicionadas pelo usuário, que podem ser removidas da coleção.
- Envio direto P2P de imagens, áudios, vídeos MP4/WebM/MOV e determinados documentos leves (PDF, TXT, ZIP e documentos Office Open XML), limitado a 2 MB por arquivo.
- Chamadas de vídeo P2P adicionadas ao fluxo existente de chamadas de voz; ambos os aparelhos precisam aceitar permissões de câmera e microfone.

### Grupos e Momentos
- Um administrador pode criar primeiro o grupo/comunidade e convidar participantes depois; não precisa adicionar portadores manualmente durante a criação.
- Convites diretos por P2P para contatos já emparelhados e conectados, além de link/código compartilhável de convite para importar o grupo. Depois de importar, o convidado ainda precisa emparelhar e conectar diretamente com o administrador para confirmar a entrada.
- Cargos básicos de administrador, moderador e participante; o administrador pode promover ou rebaixar participantes.
- Momentos de 24 horas podem conter texto, imagem comprimida (até 900 KB) ou vídeo MP4/WebM/MOV (até 700 KB nesta beta), além de comentários e reações.
- Grupo/comunidade permanece um rótulo/variante dentro do mesmo modelo P2P; não existe diretório nem feed comunitário global.

### Perfil, proteção e backup
- Campo opcional “Sobre mim” no perfil, compartilhado na identidade durante emparelhamento.
- Bloqueio local de contato e registro local de denúncia. A denúncia não é enviada para uma equipe de moderação.
- Proteção de abertura por PIN local de 6 a 12 dígitos, armazenado como hash PBKDF2-SHA-256 com salt aleatório.
- Backup local versão 3 com perfil, contatos, grupos, Momentos, Miraculous personalizados, registros de portadores, mensagens, fotos do álbum e figurinhas pessoais, com limite de 50 MB; restauração aceita backups v1, v2 e v3.

### Conexão P2P
- Configuração STUN simplificada para servidores públicos comuns e pool ICE restaurado para 6.
- O processo mantém o campo único de código, reconhecimento entre convite/resposta, coleta ICE e diagnóstico.
- Quando não há candidatos ICE, a criação do código apresenta erro explícito, em vez de declarar um código pronto sem caminhos de rede.
- A configuração TURN continua opcional e precisa ser preenchida com credenciais válidas pelo usuário nos dois aparelhos.

## Limitações e itens ainda pendentes para a versão 1.0

- QR Code gerador/leitor de pareamento não incluído nesta beta.
- Não há sinalização automática: o emparelhamento inicial ainda exige compartilhar manualmente convite e resposta; não há reconexão automática garantida depois de fechar ou recarregar o app.
- Não há servidor TURN incluído. Algumas combinações de NAT/firewall exigem TURN para conectar.
- Notificações podem ser locais quando a página permanece ativa e conectada; push confiável com o app encerrado exige infraestrutura externa de sinalização/push.
- Grupos dependem do criador/administrador como ponto de retransmissão P2P e de conexões diretas ativas com os participantes. Não são grupos de servidor.
- A interação autônoma entre dois Kwamis dentro da mesma conversa e as sugestões/notificações proativas dos Kwamis ainda não foram implementadas; o chat individual atual é um assistente local de respostas programadas.
- Figurinhas adicionadas pelo usuário são imagens locais enviadas como anexos P2P; não há editor avançado, recorte automático nem pacotes sincronizados em nuvem.
- “Comunidades” ainda não têm diretório, feed global, descoberta pública nem publicação persistente compartilhada globalmente. Momentos só chegam aos contatos P2P diretamente conectados no momento.
- Papéis de grupo são básicos; não há painel completo de moderação, banimento ou permissões granulares.
- Biometria não está disponível na camada web/PWA. O PIN protege apenas a abertura local e não criptografa os dados armazenados.
- O backup é manual/local; não existe sincronização em nuvem. Após restaurar em outro aparelho, os contatos precisam ser emparelhados novamente.
- Arquivos P2P têm limites baixos nesta beta (2 MB por anexo; vídeos de Momentos até 700 KB). Tipos de arquivo aceitos são restritos.
- Chamadas de voz/vídeo, câmera e P2P ainda precisam ser testados em dois aparelhos reais e redes externas.

A versão 1.6.0 Beta não deve ser descrita como Mirafriends 1.0 final. É uma atualização ampliada, com itens pendentes documentados para não anunciar como prontos recursos que ainda dependem de infraestrutura ou testes reais.
