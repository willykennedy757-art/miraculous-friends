# Mirafriends 1.5.2 Beta — contato e transformação dos Kwamis

## Implementado

- Contato pessoal do Kwami criado automaticamente na lista **Mensagens** para o Miraculous selecionado.
- Conversa individual do Kwami com histórico de até 200 mensagens salvo localmente no aparelho.
- O toque no Kwami flutuante continua abrindo o menu de perguntas predefinidas.
- A partir do menu, é possível abrir a conversa individual do Kwami.
- Respostas do Kwami na conversa exibem o símbolo do Miraculous no canto superior do balão. Respostas predefinidas do menu também exibem o símbolo.
- Botões de transformação disponíveis no menu do Kwami e na conversa individual.
- Enquanto transformado, um botão fixo apresenta a frase de destransformação; o estado fica somente no aparelho atual.
- Efeito visual simples, cor temporária própria para cada Miraculous e retorno à paleta predefinida ao destransformar ou sair da interação.
- Cache PWA atualizado para esta revisão.

## Preservado

- Temas predefinidos por Miraculous (sem seletor manual de tema).
- Menu de perguntas exclusivas de cada Kwami.
- Sistema de conexão WebRTC P2P e troca manual de convite/resposta.
- Mensagens, mídia, fila local pendente, chamadas de voz, Central de Portadores e grade holográfica.

## Limitações conhecidas

- Transformação local: não é propagada para outros participantes e não é persistida após fechar/recarregar.
- Histórico do Kwami é armazenado somente no aparelho atual.
- As respostas do Kwami são locais e programadas, não IA generativa.
- Grupos/comunidades, convites de grupo, Momentos e publicações não foram implementados; a versão recebida não possui backend/retransmissor para entrega remota desses recursos.
- A entrega de mensagens P2P pendentes ainda exige que os dois portadores se reconectem.
- Tikki usa as frases fornecidas no planejamento (“Spots On!” / “Spots Off!”); os demais Kwamis usam comandos próprios do Mirafriends, inspirados no conceito de cada Miraculous.
