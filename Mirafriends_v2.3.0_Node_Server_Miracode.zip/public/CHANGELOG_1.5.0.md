# Mirafriends 1.5.0 — temas pastel, despertar e chamadas em ondas

- Removida a tela antiga de abertura; quem ainda não escolheu Miraculous começa diretamente na seleção.
- Após selecionar, um despertar central mostra o símbolo escolhido e ondas contínuas durante 9 segundos antes de abrir a home.
- Paletas pastel exclusivas para os 19 Miraculous; fundo, superfícies, cartões, botões, seletores e modais acompanham o tema.
- Joaninha vermelho pastel; Gato verde pastel; Raposa laranja pastel, conforme solicitado.
- Chamada única: o emblema sobe e emite três ondas circulares pela tela.
- Chamada múltipla: os emblemas dos destinatários se alinham e disparam ondas em sequência sincronizada.
- Central de Portadores: círculo do núcleo centralizado e redimensionado; tentativa de travar orientação paisagem na entrada, com alternativa visual se o navegador negar.
- Ao sair da Central, o bloqueio de orientação é liberado quando havia sido aceito.
- P2P: STUN Cloudflare e Google, pool ICE, status por etapa e mensagens de conexão/falha mais claras. Continua sem Firebase, backend e TURN.

- Corrigida correspondência das cores dos 19 Kwamis com as 19 cores pastel dos seus Miraculous.
- Tema claro aplicado também a navegação inferior, cartões de chamada, botões do carrossel, campos, perfil, formulários e grade.
- Adicionado aviso de orientação persistente com botão para tentar novamente quando o lock for recusado.
- Ordem de orientação refinada: tenta fullscreen no navegador quando necessário e depois lock landscape; PWA standalone tenta lock diretamente.
- Cache PWA renovado para o acabamento visual e estado de orientação.
- Ondas de cada emblema de chamada agora usam a cor do próprio Miraculous destinatário; símbolos repetidos permanecem separados quando representam portadores diferentes; todos os destinatários ficam visíveis em fileiras responsivas.
- Corrigida a limpeza de estado quando a navegação muda durante a solicitação de orientação ou fullscreen.
