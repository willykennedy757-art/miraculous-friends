# Mirafriends 2.1.0 Beta — MiraGames imersivo e ADM organizado

## MiraGames
- Partidas em camada de tela cheia independente da navegação principal. O aplicativo chama Fullscreen API e tenta bloquear orientação paisagem; quando o navegador não autoriza, aplica o modo imersivo CSS que preenche a viewport.
- Catálogo ampliado para sete jogos: Voo dos Kwamis, Corrida Miraculosa, Caça aos Doces, Aventura dos Kwamis, Esconde-esconde, Pega-pega Miraculoso e Resgate dos Kwamis.
- Cada partida exibe minimapa dinâmico, objetivo, pontuação, status de vidas/tempo e lista de Kwamis NPC.
- NPCs seguem o jogador em jogos de exploração, escondem-se no Esconde-esconde, fogem e podem ser capturados no Pega-pega e seguem o jogador após serem resgatados.
- Objetivos revisados: 18 estrelas e três portais no Voo; 1.200 m e 10 emblemas na Corrida; 12 petiscos na Caça; cinco fragmentos e portal na Aventura.
- Migração automática dos recordes da chave local anterior do MiraGames.

## Interface e acessibilidade
- Painel ADM reorganizado em trilho lateral fixo, cartões alinhados em grade, painéis com largura completa e controles agrupados.
- Bloqueada a seleção/cópia acidental de textos por toque longo na interface. Campos editáveis continuam selecionáveis.
- Menu de contexto desativado fora de campos editáveis.
- Cache de service worker renovado e versão do manifesto alterada para 2.1.0.

## Validação
- Sete rotas de jogo iniciadas em teste de navegador com DOM isolado. Cada uma criou canvas, minimapa e lista de NPCs esperada, sem exceções JavaScript observadas.
- Sintaxe JavaScript e CSS, IDs HTML, caminhos locais e integridade do ZIP conferidos.
- A rotação física, Fullscreen API em WebView Android e aparência no aparelho real precisam de teste no dispositivo de destino.

## Limites
- Os NPCs são controlados por lógica local, não por multiplayer em tempo real nem por inteligência artificial conectada.
- Progresso e recordes permanecem no dispositivo.
- A orientação automática depende do suporte e das permissões do navegador/empacotador.
