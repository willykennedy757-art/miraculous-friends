# Mirafriends 1.5.3 Beta — conexão P2P simplificada e diagnóstico de rede

## Atualizações

- Fluxo de recebimento simplificado: um único campo aceita convite ou resposta e identifica automaticamente o tipo do código.
- Geração de convite/resposta com estados de progresso, mensagens de erro mais claras e botões temporariamente desativados durante o processo.
- Coleta ICE mais robusta: observa os eventos de ICE e também verifica periodicamente o estado de coleta, reduzindo a dependência de um único evento.
- O código é gerado mesmo quando a coleta ICE atinge o limite de espera, incluindo os candidatos disponíveis e informando a possível limitação.
- Validade dos códigos aumentada para 2 horas; limites de tamanho ampliados para SDP/códigos maiores.
- Diagnóstico “Verificar minha rede” mostra candidatos host, STUN/srflx e TURN/relay encontrados no aparelho. O texto explica que isso não garante uma conexão com o outro dispositivo.
- Configuração TURN opcional por JSON, salva no aparelho e aplicada tanto às conexões de mensagem quanto às chamadas de voz.
- O status de emparelhamento diferencia código aceito de canal de dados realmente conectado.
- Instruções atualizadas para HTTPS, troca dos códigos e configuração TURN.
- Service worker atualizado para evitar servir a versão P2P antiga do cache.

## Preservado

- Sem Firebase, sem servidor de sinalização próprio e sem backend novo.
- WebRTC P2P e troca manual de oferta/resposta.
- Kwamis, transformações, contatos pessoais, conversas, mensagens, mídia, chamadas, Central de Portadores e armazenamento local.

## Limite técnico importante

STUN pode permitir conexões entre muitas redes diferentes, mas não garante atravessar todos os NATs e firewalls. Para redes que bloqueiam a conexão direta, é necessário um serviço TURN. Esta versão permite configurar TURN, mas não inclui credenciais ou uma conta de relay. Portanto, a conexão universal entre quaisquer duas redes não pode ser prometida sem TURN válido configurado nos dois aparelhos.

## Testes realizados nesta entrega

- Sintaxe JavaScript validada por Node.js.
- HTML e JSON inspecionados; IDs do novo fluxo verificados.
- Integridade do ZIP será verificada após a montagem.
- Não foi possível certificar uma conexão real entre duas redes/dispositivos nesta sessão.
