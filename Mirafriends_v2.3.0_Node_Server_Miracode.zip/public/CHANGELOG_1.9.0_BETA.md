# Mirafriends 1.9.0 Beta — Central Secreta e Guardião

## Interface
- Nova identidade visual holográfica/tecnológica aplicada às páginas existentes, com layout responsivo e componentes compactos.
- Tela de abertura com o nome MIRAFRIENDS e cinco símbolos principais (Joaninha, Gato, Borboleta, Pavão e Tartaruga).
- Central ADM em tela inteira, com núcleo central clicável, troca do Miraculous deste aparelho e nove áreas: Comando Supremo, Laboratório, Portal dos Universos, Conselho dos Kwamis, Transformações, Trapaças, Visão do Sistema, Guardião e Protocolo Zero.
- Folha de estilos antiga `redesign-v1.8.css` removida do pacote; a folha nova `mf-command-center.css` contém o novo sistema visual. A estrutura funcional e os IDs de integração do app foram preservados para manter as funções existentes.
- A grade de portadores (`#page-holder-grid`) foi preservada sem alteração no HTML.

## Guardião
- Santuário exclusivo da Central ADM e opção de mostrar os Kwamis libertados por cima das páginas do aplicativo.
- 19 Kwamis oficiais e Kwamis personalizados que tenham nome cadastrado.
- Movimento autônomo, arrastar com mouse/toque, falas em balões, aproximação para interações, conversas espontâneas configuráveis, pausar/retomar, libertar/recolher e restaurar posições.
- Memória local das interações anteriores, limitada às últimas 40 entradas. Não sincroniza entre aparelhos.
- O Guardião é independente do Kwami principal do portador.

## Administração e ferramentas
- Autenticação local por senha com hash SHA-256 e bloqueio temporário após cinco tentativas incorretas.
- Diagnóstico local, exportação de relatório, prévias de temas, laboratório dos wallpapers/decorações, universos de demonstração locais, efeitos especiais e Protocolo Zero.
- O Protocolo Zero encerra efeitos temporários e restaura o tema/mascote sem apagar dados pessoais. Inclui encerramento da sessão ADM.
- Nenhum serviço remoto ou integração externa foi adicionado ao app.

## Limites conhecidos
- A senha protege a interface local, não constitui autenticação de servidor. Um aplicativo estático pode ser inspecionado/modificado por alguém com conhecimento técnico; não use esta senha como segurança de dados remotos.
- Falas e conversas dos Kwamis no Guardião são roteirizadas por personalidade; não são um modelo de IA nem conversas sincronizadas com outros aparelhos. A memória fica no armazenamento local.
- O mecanismo WebRTC/P2P existente não foi substituído. A conexão continua dependendo do fluxo manual de convite/resposta do projeto; sinalização automática, TURN gerenciado e reconexão confiável após fechar o app não foram adicionados.
- Chamadas, câmera, QR por câmera e conectividade real precisam de ensaios em aparelhos Android físicos.
