# Hospedar o Mirafriends 2.3.0 em Node.js

## Configuração da aplicação

- Runtime: **Node.js 26 LTS ou superior**.
- Comando de inicialização: `npm start`.
- A aplicação escuta `0.0.0.0` e usa a porta informada pela variável `PORT` (padrão 3000).
- Não há dependências npm externas; o banco usa `node:sqlite`.

## Variáveis de ambiente

Copie `.env.example` para `.env` em testes próprios. Em produção, configure as variáveis no painel da hospedagem:

- `NODE_ENV=production`
- `PORT` (normalmente fornecida automaticamente pelo host)
- `DATA_DIR=/caminho/do/volume/mirafriends`
- `UPLOAD_DIR=/caminho/do/volume/mirafriends/uploads`
- `DB_PATH=/caminho/do/volume/mirafriends/mirafriends.sqlite`

## Passos

1. Crie um serviço de aplicação Node.js e envie a pasta do projeto.
2. Escolha Node.js 26 LTS ou superior.
3. Configure o comando `npm start`.
4. Monte um disco/volume persistente e configure os caminhos acima.
5. Configure domínio e HTTPS no provedor.
6. Inicie o serviço e abra `/api/health` no domínio para confirmar que está online.
7. Faça backup periódico do banco SQLite e da pasta `uploads/`.

## Importante

- Não inclua `.env` nem a pasta `data/` em repositório público.
- Não use disco efêmero: contas, sessões, amizades, publicações e mídias estão no armazenamento do servidor.
- Esta edição foi projetada para uma instância do Node.js usando um único SQLite e volume persistente.
- Não exponha a pasta `data/` como conteúdo estático.
- A hospedagem precisa permitir que o processo Node permaneça em execução e aceite requisições HTTP/HTTPS.
