# Mirafriends 2.3.0 — Node.js Server

Esta edição mantém a interface e os recursos locais do Mirafriends 2.2.1 e acrescenta uma rede social hospedada por Node.js: contas protegidas por senha, identificação por Miracode, amizades públicas/privadas e publicações com fotos e vídeos.

## Requisitos

- **Node.js 26 LTS ou superior**.
- Um serviço de hospedagem que execute um processo Node.js continuamente.
- Armazenamento persistente para `data/` (banco SQLite e arquivos de mídia).
- HTTPS na URL pública, especialmente para câmera, microfone e cookies seguros.

A implementação usa módulos nativos do Node.js (`node:sqlite`, HTTP, crypto e filesystem); não precisa de Firebase nem de dependências npm de terceiros.

## Rodar localmente

1. Instale Node.js 26 LTS.
2. Copie `.env.example` para `.env`.
3. Deixe `NODE_ENV=development` para testes locais.
4. Execute:

```bash
npm start
```

5. Abra `http://localhost:3000`.

O banco e os uploads serão criados em `data/`. Para trocar a porta, configure `PORT` no `.env`.

## Hospedar

1. Envie a pasta inteira deste projeto para um host de Node.js.
2. Configure o runtime como Node.js 26 ou superior.
3. Configure `NODE_ENV=production` e `PORT` conforme a plataforma.
4. Configure um volume/disco persistente e defina `DATA_DIR`, `UPLOAD_DIR` e `DB_PATH` dentro dele.
5. Use `npm start` como comando de inicialização.
6. Ative HTTPS no domínio público.
7. Faça backup periódico do banco e da pasta de uploads.

**Importante:** o sistema usa SQLite e arquivos locais. Para esta edição, mantenha uma única instância do servidor usando o mesmo volume persistente. Não use armazenamento efêmero: ao apagar `data/`, as contas, sessões, amizades, publicações e mídias serão perdidas.

## Como a conexão social funciona

- Criar conta gera um **Miracode único** no servidor.
- Para encontrar alguém, informe o **Miracode completo** e toque em Adicionar. Não há busca por nome de usuário. O Miracode da sua conta pode ser copiado no painel da Rede Mirafriends.
- **Conta pública:** ao adicionar pelo Miracode, a amizade é criada imediatamente.
- **Conta privada:** é criada uma solicitação; a pessoa precisa aceitar antes de a amizade existir.
- Solicitações recebidas, enviadas e lista de amigos são sincronizadas pelo servidor.
- A privacidade padrão de uma conta nova é **privada**.
- Uma conta privada só publica para amigos aceitos.
- Uma conta pública pode escolher, em cada publicação, entre `Público` e `Amigos`.
- O feed mostra publicações públicas de contas públicas e publicações restritas dos amigos aceitos.
- Comentários e reações ficam restritos a amigos aceitos; em posts públicos, textos e contagens de comentários também ficam ocultos para não-amigos.
- Fotos: JPG, PNG e WebP até 12 MB. Vídeos: MP4, MOV e WebM até 80 MB.
- O servidor confere o tipo declarado e a assinatura básica do arquivo antes de guardar a mídia.

## Conta e segurança

- As senhas são derivadas com `scrypt` e salt individual; não são armazenadas em texto puro.
- A sessão usa cookie `HttpOnly`, `SameSite=Lax` e `Secure` em produção.
- Alterações de estado verificam a origem da requisição.
- Há limites de tentativa para cadastro/login, adição de amigos, publicações e uploads.
- O perfil não solicita e-mail, telefone ou localização. O Miracode identifica a conta; não é senha. A recuperação automática de senha não está incluída nesta beta, então guarde sua senha com segurança.
- Use senha exclusiva e não compartilhe seu Miracode em locais públicos se sua conta for privada.

## O que continua P2P nesta beta

A conta online, amizade por Miracode e feed de posts/fotos/vídeos passam pelo servidor. **Chamadas e mensagens privadas existentes continuam usando o mecanismo WebRTC P2P da versão 2.2.1**, com a tela de emparelhamento direto disponível em `Portadores > Conexão direta P2P`. Adicionar um amigo pelo Miracode não cria, por si só, um canal WebRTC. Push remoto, chamadas retransmitidas pelo servidor, sincronização de mensagens e grupos globais ainda não foram migrados nesta edição.

Momentos de 24 horas, comunidades/grupos, Guardião, MiraGames, Central ADM, temas e preferências locais continuam como na versão 2.2.1 e não passam automaticamente a ser globais.

## Armazenamento e rotas

- Banco: `DATA_DIR/mirafriends.sqlite`.
- Uploads: `UPLOAD_DIR/` (servidos em `/uploads/...` com suporte a solicitações HTTP Range para vídeos).
- Saúde do servidor: `GET /api/health`.
- API exige sessão para todas as rotas sociais, exceto `/api/health`.

## Recuperação

Para fazer backup, pare o processo e copie o arquivo SQLite junto com a pasta `uploads/`. Para restaurar, recoloque os dois no mesmo caminho persistente e reinicie o servidor.
