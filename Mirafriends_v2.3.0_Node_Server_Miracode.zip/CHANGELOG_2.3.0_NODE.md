# Mirafriends 2.3.0 — Node.js Server

## Novidades
- Servidor próprio em Node.js com SQLite persistente.
- Cadastro e login por Miracode + senha.
- Contas públicas e privadas.
- Adição por Miracode: conta pública adicionada imediatamente; conta privada recebe solicitação para aceitar.
- Lista de amigos e pedidos sincronizados.
- Feed hospedado com posts públicos e restritos a amigos.
- Upload/streaming de fotos e vídeos com suporte HTTP Range.
- Reações e comentários de amigos.
- Sessões por cookie HttpOnly e hash de senha scrypt.
- Cache PWA não intercepta API nem uploads.

## Mantido
- Temas dos Miraculous, Kwamis, Guardião, Central ADM, MiraGames, ajustes visuais e navegação da versão 2.2.1.
- Chats, áudio, chamadas, grupos e Momentos continuam no mecanismo local/P2P original.

## Limites
- O Miracode online não é sinalização WebRTC. Para abrir chamadas e mensagens P2P, os aparelhos ainda precisam usar o fluxo de emparelhamento disponível na tela de conexão.
- Feed e amizades exigem servidor em execução e armazenamento persistente.

## Ajustes finais de privacidade e interface
- Busca por Miracode, solicitações e lista online só aparecem após entrar na conta.
- Contas públicas iniciam a composição de posts com visibilidade pública; o portador pode trocar para Amigos.
- Comentários e suas contagens não aparecem a visitantes que não são amigos do autor.
- Mídias enviadas usam `Cache-Control: private, no-store` e acesso protegido pela privacidade do post.
- O formulário agora executa a adição diretamente após validar o Miracode; público é adicionado e privado recebe pedido pendente.
- Botão para copiar o Miracode próprio e exemplos completos no campo de login/adição.
